USB GPIB Interface

Disclaimers

This software is free and freely distributable on a non-commercial basis in the format ORIGINALLY RELEASED with the original Copyright clause.
The author expressly disclaims any warranty for this software. This software, other files and any related documentation are provided "as is" without warranty of any kind.

Redistribution and use in of the files, with or without modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the copyright notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

To the extent not prohibited by law, in no event will FEE be liable for any lost data, revenue or profit, or for special, indirect, consequential, incidental or punitive damages, regardless of the theory of liability (including negligence), arising out of or related to the use of or inability to use the product (including any software), even if FEE has been advised of the possibility of such damages. In no event will FEE� liability exceed the amount paid by you for the product.


University of Ljubljana
Faculty of Electrical Engineering
Tr�a�ka cesta 25, 1000 Ljubljana, Slovenia

Laboratory of semiconductor devices
http://lsd.fe.uni-lj.si
http://lsd.fe.uni-lj.si/gpib/

Bo�tjan Gla�ar, univ. dipl. ing.
E-mail: bostjan.glazar[at]fe.uni-lj.si
Phone: +386 1 4768 723
