using System;
using Microsoft.Win32.SafeHandles;
using System.Runtime.InteropServices;

namespace OscilloscopeDotNet1 {
	/// <summary>
	///  Routines for the WinUsb driver supported by Windows Vista and Windows XP.
	///  </summary>
	sealed internal partial class WinUsbDevice {
		internal struct devInfo {
			internal SafeFileHandle deviceHandle;
			internal IntPtr winUsbHandle;
			internal Byte bulkInPipe;
			internal Byte bulkOutPipe;
		}

		internal devInfo myDevInfo = new devInfo();

		///  <summary>
		///  Closes the device handle obtained with CreateFile and frees resources.
		///  </summary>
		internal void CloseDeviceHandle() {
			try {
                WinUsb_AbortPipe(myDevInfo.winUsbHandle, myDevInfo.bulkInPipe);
                WinUsb_Free(myDevInfo.winUsbHandle);
				if (!(myDevInfo.deviceHandle == null)) {
					if (!(myDevInfo.deviceHandle.IsInvalid)) {
						myDevInfo.deviceHandle.Close();
					}
				}
			}
			catch (Exception ex) {
				throw;
			}
		}

		///  <summary>
		///  Initiates a Control Read transfer. Data stage is device to host.
		///  </summary>
		/// 
		///  <param name="dataStage"> The received data. </param>
		///  
		///  <returns>
		///  True on success, False on failure.
		///  </returns>
		internal Boolean Do_Control_Read_Transfer(ref Byte[] dataIn, byte Request, UInt16 Value, UInt16 Index) {
			UInt32 bytesReturned = 0;
			WINUSB_SETUP_PACKET setupPacket;
			try {
                setupPacket.RequestType = 0XC0;     //  Vendor-specific request to an interface with device-to-host Data stage.
                setupPacket.Request     = Request;  //  The request number that identifies the specific request.
                setupPacket.Value       = Value;    //  Command-specific value to send to the device.
                setupPacket.Index       = Index;    //  Command-specific value to send to the device.
                setupPacket.Length      = System.Convert.ToUInt16(dataIn.Length); //  Number of bytes in the request's Data stage.
                //  Initiates a control transfer., returns True on success.         
                return WinUsb_ControlTransfer(myDevInfo.winUsbHandle, setupPacket, dataIn, System.Convert.ToUInt16(dataIn.Length), ref bytesReturned, IntPtr.Zero);
			}
			catch (Exception ex) {
				throw;
			}
		}

		///  <summary>
		///  Requests a handle with CreateFile.
		///  </summary>
		///  
		///  <param name="devicePathName"> Returned by SetupDiGetDeviceInterfaceDetail 
		///  in an SP_DEVICE_INTERFACE_DETAIL_DATA structure. </param>
		///  
		///  <returns>
		///  The handle.
		///  </returns>
		internal Boolean GetDeviceHandle(String devicePathName) {
			// *** API function
			//  summary
			//      Retrieves a handle to a device.
			//  parameters 
			//      Device path name returned by SetupDiGetDeviceInterfaceDetail
			//      Type of access requested (read/write).
			//      FILE_SHARE attributes to allow other processes to access the device while this handle is open.
			//      Security structure. Using Null for this may cause problems under Windows XP.
			//      Creation disposition value. Use OPEN_EXISTING for devices.
			//      Flags and attributes for files. The winsub driver requires FILE_FLAG_OVERLAPPED.
			//      Handle to a template file. Not used.
			//  Returns
			//      A handle or INVALID_HANDLE_VALUE.
			myDevInfo.deviceHandle = FileIO.CreateFile(
				devicePathName,
				(FileIO.GENERIC_WRITE | FileIO.GENERIC_READ),
				FileIO.FILE_SHARE_READ | FileIO.FILE_SHARE_WRITE,
				IntPtr.Zero,
				FileIO.OPEN_EXISTING,
				FileIO.FILE_ATTRIBUTE_NORMAL | FileIO.FILE_FLAG_OVERLAPPED,
				0);

			if (!(myDevInfo.deviceHandle.IsInvalid)) return true;
			return false;
		}

		///  <summary>
		///  Initializes a device interface and obtains information about it.
		///  Calls these winusb API functions:
		///    WinUsb_Initialize
		///    WinUsb_QueryInterfaceSettings
		///    WinUsb_QueryPipe
		///  </summary>
		///  
		///  <param name="deviceHandle"> A handle obtained in a call to winusb_initialize. </param>
		///  
		///  <returns>
		///  True on success, False on failure.
		///  </returns>
		internal Boolean InitializeDevice() {
			USB_INTERFACE_DESCRIPTOR ifaceDescriptor;
			WINUSB_PIPE_INFORMATION pipeInfo;
			Boolean success;

			try {
				ifaceDescriptor.bLength = 0;
				ifaceDescriptor.bDescriptorType = 0;
				ifaceDescriptor.bInterfaceNumber = 0;
				ifaceDescriptor.bAlternateSetting = 0;
				ifaceDescriptor.bNumEndpoints = 0;
				ifaceDescriptor.bInterfaceClass = 0;
				ifaceDescriptor.bInterfaceSubClass = 0;
				ifaceDescriptor.bInterfaceProtocol = 0;
				ifaceDescriptor.iInterface = 0;

				pipeInfo.PipeType = 0;
				pipeInfo.PipeId = 0;
				pipeInfo.MaximumPacketSize = 0;
				pipeInfo.Interval = 0;

				// *** winusb function 
				//  summary
				//      get a handle for communications with a winusb device        '
				//  parameters
				//      Handle returned by CreateFile.
				//      Device handle to be returned.
				//  returns True on success.
				success = WinUsb_Initialize(myDevInfo.deviceHandle,	ref myDevInfo.winUsbHandle);
				if (success) {
					// *** winusb function 
					//  summary
					//      Get a structure with information about the device interface.
					//  parameters
					//      handle returned by WinUsb_Initialize
					//      alternate interface setting number
					//      USB_INTERFACE_DESCRIPTOR structure to be returned.
					//  returns True on success.
					success = WinUsb_QueryInterfaceSettings(myDevInfo.winUsbHandle,	0, ref ifaceDescriptor);

					if (success) {
						//  Get the transfer type, endpoint number, and direction for the interface's
						//  bulk and interrupt endpoints. Set pipe policies.

						// *** winusb function 
						//  summary
						//      returns information about a USB pipe (endpoint address)
						//  parameters
						//      Handle returned by WinUsb_Initialize
						//      Alternate interface setting number
						//      Number of an endpoint address associated with the interface. 
						//      (The values count up from zero and are NOT the same as the endpoint address
						//      in the endpoint descriptor.)
						//      WINUSB_PIPE_INFORMATION structure to be returned
						//  returns True on success
						for (Int32 i = 0; i <= ifaceDescriptor.bNumEndpoints - 1; i++) {
							WinUsb_QueryPipe
								(myDevInfo.winUsbHandle,
								0,
								System.Convert.ToByte(i),
								ref pipeInfo);

							if (((pipeInfo.PipeType ==
								USBD_PIPE_TYPE.UsbdPipeTypeBulk) &
								UsbEndpointDirectionIn(pipeInfo.PipeId))) {
								myDevInfo.bulkInPipe = pipeInfo.PipeId;

								SetPipePolicy
									(myDevInfo.bulkInPipe,
									Convert.ToUInt32(POLICY_TYPE.IGNORE_SHORT_PACKETS),
									Convert.ToByte(false));

								SetPipePolicy
									(myDevInfo.bulkInPipe,
									Convert.ToUInt32(POLICY_TYPE.PIPE_TRANSFER_TIMEOUT),
									0); // Pipe does not timeout

							}
							else if (((pipeInfo.PipeType ==
								USBD_PIPE_TYPE.UsbdPipeTypeBulk) &
								UsbEndpointDirectionOut(pipeInfo.PipeId))) {

								myDevInfo.bulkOutPipe = pipeInfo.PipeId;

								SetPipePolicy
									(myDevInfo.bulkOutPipe,
									Convert.ToUInt32(POLICY_TYPE.IGNORE_SHORT_PACKETS),
									Convert.ToByte(false));

								SetPipePolicy
									(myDevInfo.bulkOutPipe,
									Convert.ToUInt32(POLICY_TYPE.PIPE_TRANSFER_TIMEOUT),
									2000);      // 2 second timeout

							}
						}
					}
					else success = false;
				}
				return success;
			}
			catch (Exception ex) {
				throw;
			}
		}

		///  <summary>
		///  Is the current operating system Windows XP or later?
		///  The WinUSB driver requires Windows XP or later.
		///  </summary>
		/// 
		///  <returns>
		///  True if Windows XP or later, False if not.
		///  </returns>
		internal Boolean IsWindowsXpOrLater() {
			try {
				OperatingSystem myEnvironment = Environment.OSVersion;

				//  Windows XP is version 5.1.
				System.Version versionXP = new System.Version(5, 1);

				if (myEnvironment.Version >= versionXP)	return true;
				return false;
			}
			catch (Exception ex) {
				throw;
			}
		}

		///  <summary>
		///  Attempts to read data from a bulk IN endpoint.
		///  </summary>
		///  
		///  <param name="InterfaceHandle"> Device interface handle. </param>
		///  <param name="PipeID"> Endpoint address. </param>
		///  <param name="bytesToRead"> Number of bytes to read. </param>
		///  <param name="Buffer"> Buffer for storing the bytes read. </param>
		///  <param name="bytesRead"> Number of bytes read. </param>
		///  <param name="success"> Success or failure status. </param>
		///  
		internal void ReadViaBulkTransfer(Byte pipeID, UInt32 bytesToRead, ref Byte[] buffer, ref UInt32 bytesRead, ref Boolean success) {
			try {
				// ***  winusb function 
				//  summary
				//      Attempts to read data from a device interface.
				//  parameters
				//      Device handle returned by WinUsb_Initialize.
				//      Endpoint address.
				//      Buffer to store the data.
				//      Maximum number of bytes to return.
				//      Number of bytes read.
				//      Null pointer for non-overlapped.
				//  Returns True on success.
				// ***
				success = WinUsb_ReadPipe(myDevInfo.winUsbHandle,pipeID,buffer,bytesToRead,ref bytesRead,IntPtr.Zero);
				if (!(success))	CloseDeviceHandle();
			}
			catch (Exception ex) {
				throw;
			}
		}

    	///  <summary>
		///  Attempts to send data via a bulk OUT endpoint.
		///  </summary>
		///  
		///  <param name="buffer"> Buffer containing the bytes to write. </param>
		///  <param name="bytesToWrite"> Number of bytes to write. </param>
		///  
		///  <returns>
		///  True on success, False on failure.
		///  </returns>
		internal Boolean SendViaBulkTransfer(ref Byte[] buffer, UInt32 bytesToWrite) {
			UInt32 bytesWritten = 0;
			Boolean success;
			try {
				// *** winusb function 
				//  summary
				//      Attempts to write data to a device interface.
				//  parameters
				//      Device handle returned by WinUsb_Initialize.
				//      Endpoint address.
				//      Buffer with data to write.
				//      Number of bytes to write.
				//      Number of bytes written.
				//      IntPtr.Zero for non-overlapped I/O.
				//  Returns True on success.
				success = WinUsb_WritePipe(
					myDevInfo.winUsbHandle,
					myDevInfo.bulkOutPipe,
					buffer,
					bytesToWrite,
					ref bytesWritten,
					IntPtr.Zero);

				if (!(success)) CloseDeviceHandle();
				return success;
			}
			catch (Exception ex) {
				throw;
			}
		}

		///  <summary>
		///  Sets pipe policy.
		///  Used when the value parameter is a Byte (all except PIPE_TRANSFER_TIMEOUT).
		///  </summary>
		///  
		///  <param name="pipeId"> Pipe to set a policy for. </param>
		///  <param name="policyType"> POLICY_TYPE member. </param>
		///  <param name="value"> Policy value. </param>
		///  
		///  <returns>
		///  True on success, False on failure.
		///  </returns>
		private Boolean SetPipePolicy(Byte pipeId, UInt32 policyType, Byte value) {
			try {
				// *** winusb function 
				//  summary
				//      sets a pipe policy 
				//  parameters
				//      handle returned by WinUsb_Initialize
				//      identifies the pipe
				//      POLICY_TYPE member.
				//      length of value in bytes
				//      value to set for the policy.
				//  returns True on success
				return WinUsb_SetPipePolicy(
					myDevInfo.winUsbHandle,
					pipeId,
					policyType,
					1,
					ref value);
			}
			catch (Exception ex) {
				throw;
			}
		}

		///  <summary>
		///  Sets pipe policy.
		///  Used when the value parameter is a UInt32 (PIPE_TRANSFER_TIMEOUT only).
		///  </summary>
		///  
		///  <param name="pipeId"> Pipe to set a policy for. </param>
		///  <param name="policyType"> POLICY_TYPE member. </param>
		///  <param name="value"> Policy value. </param>
		///  
		///  <returns>
		///  True on success, False on failure.
		///  </returns>
		private Boolean SetPipePolicy(Byte pipeId, UInt32 policyType, UInt32 value) {
			try {
				// *** winusb function 
				//  summary
				//      sets a pipe policy 
				//  parameters
				//      handle returned by WinUsb_Initialize
				//      identifies the pipe
				//      POLICY_TYPE member.
				//      length of value in bytes
				//      value to set for the policy.
				//  returns True on success 
				return WinUsb_SetPipePolicy1
					(myDevInfo.winUsbHandle,
					pipeId,
					policyType,
					4,
					ref value);
			}
			catch (Exception ex) {
				throw;
			}
		}

		///  <summary>
		///  Is the endpoint's direction IN (device to host)?
		///  </summary>
		///  
		///  <param name="addr"> The endpoint address. </param>
		///  <returns>
		///  True if IN (device to host), False if OUT (host to device)
		///  </returns> 
		private Boolean UsbEndpointDirectionIn(Int32 addr) {
			if (((addr & 0X80) == 0X80)) return true;
			else return false;
		}

		///  <summary>
		///  Is the endpoint's direction OUT (host to device)?
		///  </summary>
		///  
		///  <param name="addr"> The endpoint address. </param>
		///  
		///  <returns>
		///  True if OUT (host to device, False if IN (device to host)
		///  </returns>
		private Boolean UsbEndpointDirectionOut(Int32 addr) {
            if (((addr & 0X80) == 0)) return true;
            else return false;
		}
	}
}
