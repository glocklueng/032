﻿using System;
using System.Drawing;
using System.Windows.Forms;
using System.IO;
using System.IO.Ports;
using System.Threading;
using System.Runtime.InteropServices;

namespace OscilloscopeDotNet1 {
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form {
        private System.Windows.Forms.Timer timer1;
		private System.ComponentModel.IContainer components;
        private System.Windows.Forms.Button button_auto;
        private System.Windows.Forms.Button StorageButton;
        private System.IO.Ports.SerialPort serialPort1;
        private GroupBox groupBox1;
        private GroupBox groupBox2;
        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TabPage tabPage3;
        private TabPage tabPage4;
        private CheckBox checkBox2;
        private CheckBox checkBox1;
        private CheckBox checkBoxCH2Avrg;
        private CheckBox checkBoxCH2Inv;
        private GroupBox groupBox3;
        private GroupBox groupBox5;
        private GroupBox groupBox4;
        private RadioButton radioTrigNormal;
        private RadioButton radioTrigFree;
        private ComboBox comboBoxTSource;
        private Button button1;
        private CheckBox checkBoxCH1Avrg;
        private CheckBox checkBoxCH1Inv;
        private RadioButton radioTrigSingle;
        private RadioButton radioTrigAuto;
        private ColorDialog colorDialog1;
        private Label label1;
        private Label label2;
        private Button button2;
        private Button button3;
        private Label label3;
        private Label label4;
        private Button button4;
        private Label label6;
        private Label label5;
        private Button button7;
        private CheckBox checkBox9;
        private Button button6;
        private CheckBox checkBox8;
        private CheckBox checkBox7;
        private Button button5;
        private TabControl tabControl2;
        private TabPage tabPage5;
        private TabPage tabPage6;
        private Label label11;
        private Label label10;
        private Label label9;
        private CheckBox checkBoxSweepF;
        private TabPage tabPage7;
        private HScrollBar ScrollBarHPos;
        private TabPage tabPage8;
        private GroupBox groupBox7;
        private Label label23;
        private ComboBox comboBox2;
        private Label label22;
        private Button button15;
        private CheckBox checkBoxLines;
        private CheckBox checkBoxPersistence;
        private GroupBox groupBox6;
        private Button button12;
        private Button button11;
        private Button button10;
        private Button button9;
        private Button button13;
        private Button button14;
        private TrackBar trackBarCH1Gain;
        private TrackBar trackBarCH1Pos;
        private TrackBar trackBarZoom;
        private TrackBar trackBarSampling;
        private CheckBox checkBoxCH1On;
        private Label label28;
        private Label label27;
        private CheckBox checkBoxCH2On;
        private Label label29;
        private Label label30;
        private TrackBar trackBarCH2Gain;
        private TrackBar trackBarCH2Pos;
        private TrackBar trackBar9;
        private TabPage tabPage9;
        private Label label34;
        private Label label25;
        private TrackBar trackBar18;
        private TrackBar trackBarCHDPos;
        private CheckBox checkBoxCHDThick;
        private Button button8;
        private Label label7;
        private CheckBox checkBoxCHDInv;
        private CheckBox checkBoxCHDOn;
        private CheckBox checkBoxCHDSerial;
        private CheckBox checkBoxCHDParallel;
        private Label label33;
        private Label label32;
        private Label label26;
        private TrackBar trackBarCHDPull;
        private CheckBox checkBoxFFTOn;
        private CheckBox checkBoxCHD7;
        private CheckBox checkBoxCHD6;
        private CheckBox checkBoxCHD5;
        private CheckBox checkBoxCHD4;
        private CheckBox checkBoxCHD3;
        private CheckBox checkBoxCHD2;
        private CheckBox checkBoxCHD1;
        private CheckBox checkBoxCHD0;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private GroupBox groupBox8;
        private TextBox textBox6;
        private Label label21;
        private Button button16;
        private TextBox textBoxVersion;
        private Label label20;
        private Label label24;
        private GroupBox groupBox9;
        private PictureBox pictureBox1;
        private GroupBox groupBox10;
        private Button buttonForce;
        private RadioButton radioButtonCustom;
        private PictureBox pictureBox3;
        private RadioButton radioButtonTrian;
        private PictureBox pictureBox2;
        private RadioButton radioButtonSquare;
        private RadioButton radioButtonSine;
        private PictureBox pictureBox6;
        private PictureBox pictureBox5;
        private PictureBox pictureBox8;
        private PictureBox pictureBox7;
        private TrackBar trackBarOffset;
        private TrackBar trackBarDuty;
        private TrackBar trackBarFreq;
        private TrackBar trackBarAmp;
        private ComboBox comboBoxCOMS;
        private GroupBox groupBox11;
        private Button buttonConnect;
        private Label label31;
        private CheckBox checkBox31;

        // My Global variables
		byte[] CHData = new byte[256*3+2];
        byte[] AWGBuffer = new byte[256];
        byte[] USBDataIn = new byte[64];
        private static Mutex SerialBusy = new Mutex();
        byte ScopeMode = 1;
        byte DisplaySettings;
        byte TriggerLevel;
        string[] ratetxt = {    // Sampling rate 
            "8μs/div",   "16μs/div",  "32μs/div",  "64μs/div",
            "128μs/div", "256μs/div", "500μs/div", "1ms/div",
            "2ms/div",   "5ms/div",   "10ms/div",  "20ms/div",
            "50ms/div",  "0.1s/div",  "0.2s/div",  "0.5s/div",
            "1s/div",    "2s/div",    "5s/div",    "10s/div",
            "20s/div",   "50s/div" };

        string[] gaintxt = {        // Gain Text with x1 probe
		    "5.12V/div", "2.56V/div", "1.28V/div", "0.64V/div",
		    "0.32V/div", "0.16V/div", "80mV/div",  "----" };

        UInt32[] freqval = {
            // Kilo Hertz
            2000000,1000000,500000,250000,125000,62500,32000,
            // Hertz
            16000000,8000000,3200000,1600000,800000,320000,160000,80000,32000,16000,
               8000,   3200,   1600,   800,   320 };

        private PictureBox pictureBox9;
        private Label labelConnected;
        private RadioButton radioFalling;
        private RadioButton radioRising;
        private PictureBox pictureBox10;
        private PictureBox pictureBox11;
        private Label label35;
        private Label label37;
        private Label label38;
        private Label label39;
        private Label labelCH1Gain;
        private Label labelCH2Gain;
        private Label labelSRate;
        private Label labelTriggerLevel;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private Label label46;
        private Label label45;
        private Label label44;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private Label label47;
        private Label label48;
        private Label label49;
        private NumericUpDown numericUpDownOffset;
        private NumericUpDown numericUpDownDuty;
        private NumericUpDown numericUpDownFreq;
        private NumericUpDown numericUpDownAmp;
        private Label label40;
        private GroupBox groupBox12;
        private RadioButton radioButton100;
        private RadioButton radioButton10;
        private RadioButton radioButton100K;
        private RadioButton radioButton10K;
        private RadioButton radioButton1K;
        private RadioButton radioNegative;
        private RadioButton radioPositive;
        private PictureBox pictureBox4;
        private PictureBox pictureBox12;
        private GroupBox groupBox13;
        private CheckBox checkBox3;
        private RadioButton radioButtonFFTCH1;
        private TrackBar trackBar1;
        private GroupBox groupBox14;
        private RadioButton radioButtonRectangular;
        private TrackBar trackBar3;
        private TrackBar trackBar2;
        private Label label42;
        private RadioButton radioButtonBlackman;
        private RadioButton radioButtonHann;
        private RadioButton radioButtonHamming;
        private RadioButton radioButtonFFT;
        private RadioButton radioButtonFFTCH2;
        private TabControl tabControl3;
        private TabPage tabPage10;
        private Label label50;
        private Label label43;
        private TextBox textBox1;
        private TabPage tabPage11;
        private TextBox textBox3;
        private TextBox textBox2;
        private TabPage tabPage12;
        private GroupBox groupBox15;
        private RadioButton radioSniffSingle;
        private RadioButton radioSniffNormal;
        private ComboBox comboBoxStops;
        private ComboBox comboBoxParity;
        private Label label55;
        private Label label54;
        private Label label53;
        private ComboBox comboBoxBaud;
        private Button button20;
        private Label label51;
        private Label label52;
        private CheckBox checkBoxASCII;
        private Label label61;
        private Label label56;
        private ComboBox comboBoxCPHA;
        private Label label57;
        private Label label58;
        private ComboBox comboBoxCPOL;
        private Label label59;
        private Label label60;
        private TextBox textBox4;
        private TextBox textBox13;
        private ComboBox comboBox6;
        private Label label62;
        private Label label64;
        private Label label63;
        private TrackBar trackBar5;
        private TrackBar trackBar4;
        private PictureBox pictureBox14;
        private PictureBox pictureBox15;
        private PictureBox pictureBox17;
        private PictureBox pictureBox16;
        private CheckBox checkBox6;
        private PictureBox pictureBox18;
        private TabPage tabPage13;
        private Label labelVersion;
        private Label label65;
        private LinkLabel linkLabel1;
        private PictureBox pictureBox13;
        private Label label66;
        private TextBox textBox14;
        string COM_PORT;

        private IntPtr deviceNotificationHandle;
        private Boolean myDeviceDetected = false;
        private DeviceManagement myDeviceManagement = new DeviceManagement();
        private String myDevicePathName;
        private NumericUpDown numericUpDownTHold;
        private Label label36;
        private Label label67;
        private PictureBox pictureBox19;
        private CheckBox checkBoxRoll;
        private CheckBox checkBoxXY;
        private PictureBox pictureBox20;
        private CheckBox checkBoxLog;
        private TextBox textBoxF;
        private Label label68;
        private Label labelHz;
        private RadioButton radioButtonNoise;
        private Button buttonOpenCSV;
        private CheckBox checkBoxSweepO;
        private CheckBox checkBoxSweepD;
        private CheckBox checkBoxSweepA;
        private GroupBox groupBox18;
        private CheckBox checkBoxAccel;
        private CheckBox checkBoxPingPong;
        private RadioButton radioButtonExpo;
        private PictureBox pictureBox22;
        private PictureBox pictureBox21;
        private TrackBar trackBarSW2;
        private TrackBar trackBarSW1;
        private CheckBox checkBoxAccelDir;
        private Label label70;
        private Label label69;
        private TextBox textBoxSW2;
        private TextBox textBoxSW1;
        private CheckBox checkBoxIQFFT;
        private Label labelUnit2;
        private Label labelUnit1;
        private CheckBox checkBoxDirection;
        private Label label72;
        private TextBox textBoxSWSpeed;
        private TrackBar trackBarSWSpeed;
        private CheckBox checkBoxCH1Math;
        private GroupBox groupBox19;
        private RadioButton radioButtonCH2Add;
        private CheckBox checkBoxCH2Math;
        private GroupBox groupBox20;
        private RadioButton radioButtonCH1Mul;
        private RadioButton radioButtonCH1Add;
        private RadioButton radioButtonCH2Mul;
        private CheckBox checkBoxCircular;
        private PictureBox pictureBox23;
        private RadioButton radioWindow;
        private PictureBox pictureBox24;
        private RadioButton radioDual;
        private CheckBox checkBoxStop;
        private Label label8;
        private Label label41;
        private NumericUpDown numericUpTTimeout;
        private ToolTip toolTip1;
        private CheckBox checkBoxElastic;
        private PictureBox pictureBox25;
        private Button buttonSaveAWG;
        private RichTextBox richTextBox1;
        private WinUsbDevice myWinUsbDevice = new WinUsbDevice();

        ///  <summary>
        ///  Define a class of delegates with the same parameters as 
        ///  WinUsbDevice.ReadViaBulkTransfer and WinUsbDevice.ReadViaInterruptTransfer.
        ///  Used for asynchronous reads from the device.
        ///  </summary>
        private delegate void ReadFromDeviceDelegate
            (Byte pipeID,
            UInt32 bufferLength,
            ref Byte[] buffer,
            ref UInt32 lengthTransferred,
            ref Boolean success);

        ///  <summary>
        ///  Define a delegate with the same parameters as AccessForm.
        ///  Used in accessing the application's form from a different thread.
        ///  </summary>
        private delegate void MarshalToForm(String action, String textToAdd);

        ///  <summary>
        ///  If a device with the specified device interface GUID hasn't been previously detected,
        ///  look for it. If found, open a handle to the device.
        ///  </summary>
        ///  
        ///  <returns>
        ///  True if the device is detected, False if not detected.
        ///  </returns>
        private Boolean FindMyDevice() {
            String devicePathName = "";
            Boolean success=false;

            try {
                if(!(myDeviceDetected)) {
                    //  This GUID must match the GUID in the device's INF file.
                    //  Convert the device interface GUID String to a GUID object:
                    System.Guid winUsbDemoGuid = new System.Guid("{88BAE032-5A81-49f0-BC3D-A4FF138216D6}");

                    if(myDeviceManagement.FindDeviceFromGuid(winUsbDemoGuid, ref devicePathName)) {
                        success = myWinUsbDevice.GetDeviceHandle(devicePathName);
                        if(success) {
                            myDeviceDetected = true;
                            // Save DevicePathName so OnDeviceChange() knows which name is my device.
                            myDevicePathName = devicePathName;
                        }
                        else {
                            // There was a problem in retrieving the information.
                            myDeviceDetected = false;
                            myWinUsbDevice.CloseDeviceHandle();
                        }
                    }
                    if(myDeviceDetected) {
                        // The device was detected.
                        // Register to receive notifications if the device is removed or attached.
                        success = myDeviceManagement.RegisterForDeviceNotifications
                            (myDevicePathName,
                            this.Handle,
                            winUsbDemoGuid,
                            ref deviceNotificationHandle);

                        if(success) {
                            myWinUsbDevice.InitializeDevice();
                            //Commented out due to unreliable response from WinUsb_QueryDeviceInformation.                            
                            //DisplayDeviceSpeed(); 
                        }
                    }
                }
                return myDeviceDetected;
            }
            catch(Exception ex) {
                throw;
            }
        }

		public Form1() {
            int i=0;
			// Required for Windows Form Designer support
			InitializeComponent();

            // Find all COM ports and fill combo box
            COM_PORT = String.Copy(Xprotolab_interface.Properties.Settings.Default.COMPORT);
            this.comboBoxCOMS.Items.Clear();
            string[] thePortNames = System.IO.Ports.SerialPort.GetPortNames();
            foreach(string item in thePortNames) {
                this.comboBoxCOMS.Items.Add(item);
                if(item.Equals(COM_PORT)) {
                    comboBoxCOMS.SelectedIndex = i;
                }
                i++;
            }

            for (i = 0; i < CHData.Length; i++) CHData[i] = 0;
			// reduce flicker
			SetStyle(ControlStyles.UserPaint, true);
			SetStyle(ControlStyles.AllPaintingInWmPaint, true);
			SetStyle(ControlStyles.DoubleBuffer, true);

            linkLabel1.Links.Add(0, 11, "www.gabotronics.com");
            labelVersion.Text = Application.ProductVersion.ToString();

            // Check for USB device
            USBConnect();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing ) {
			if( disposing ) {
				if (components != null) components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent() {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button_auto = new System.Windows.Forms.Button();
            this.StorageButton = new System.Windows.Forms.Button();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pictureBox25 = new System.Windows.Forms.PictureBox();
            this.checkBoxElastic = new System.Windows.Forms.CheckBox();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.checkBoxRoll = new System.Windows.Forms.CheckBox();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.trackBarZoom = new System.Windows.Forms.TrackBar();
            this.trackBarSampling = new System.Windows.Forms.TrackBar();
            this.checkBoxXY = new System.Windows.Forms.CheckBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.radioButtonCH1Mul = new System.Windows.Forms.RadioButton();
            this.radioButtonCH1Add = new System.Windows.Forms.RadioButton();
            this.checkBoxCH1Math = new System.Windows.Forms.CheckBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label46 = new System.Windows.Forms.Label();
            this.label45 = new System.Windows.Forms.Label();
            this.label44 = new System.Windows.Forms.Label();
            this.checkBoxCH1On = new System.Windows.Forms.CheckBox();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.trackBarCH1Gain = new System.Windows.Forms.TrackBar();
            this.trackBarCH1Pos = new System.Windows.Forms.TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.checkBoxCH1Avrg = new System.Windows.Forms.CheckBox();
            this.checkBoxCH1Inv = new System.Windows.Forms.CheckBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.radioButtonCH2Mul = new System.Windows.Forms.RadioButton();
            this.radioButtonCH2Add = new System.Windows.Forms.RadioButton();
            this.checkBoxCH2Math = new System.Windows.Forms.CheckBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label47 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.checkBoxCH2On = new System.Windows.Forms.CheckBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.trackBarCH2Gain = new System.Windows.Forms.TrackBar();
            this.trackBarCH2Pos = new System.Windows.Forms.TrackBar();
            this.label2 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.checkBoxCH2Avrg = new System.Windows.Forms.CheckBox();
            this.checkBoxCH2Inv = new System.Windows.Forms.CheckBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBoxCHD7 = new System.Windows.Forms.CheckBox();
            this.checkBoxCHD6 = new System.Windows.Forms.CheckBox();
            this.checkBoxCHD5 = new System.Windows.Forms.CheckBox();
            this.checkBoxCHD4 = new System.Windows.Forms.CheckBox();
            this.checkBoxCHD3 = new System.Windows.Forms.CheckBox();
            this.checkBoxCHD2 = new System.Windows.Forms.CheckBox();
            this.checkBoxCHD1 = new System.Windows.Forms.CheckBox();
            this.checkBoxCHD0 = new System.Windows.Forms.CheckBox();
            this.checkBoxCHDSerial = new System.Windows.Forms.CheckBox();
            this.checkBoxCHDParallel = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.trackBarCHDPull = new System.Windows.Forms.TrackBar();
            this.label14 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.trackBar18 = new System.Windows.Forms.TrackBar();
            this.trackBarCHDPos = new System.Windows.Forms.TrackBar();
            this.checkBoxCHDThick = new System.Windows.Forms.CheckBox();
            this.button8 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.checkBoxCHDInv = new System.Windows.Forms.CheckBox();
            this.checkBoxCHDOn = new System.Windows.Forms.CheckBox();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.checkBoxIQFFT = new System.Windows.Forms.CheckBox();
            this.checkBoxLog = new System.Windows.Forms.CheckBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.radioButtonBlackman = new System.Windows.Forms.RadioButton();
            this.radioButtonHann = new System.Windows.Forms.RadioButton();
            this.radioButtonHamming = new System.Windows.Forms.RadioButton();
            this.radioButtonRectangular = new System.Windows.Forms.RadioButton();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.radioButtonFFT = new System.Windows.Forms.RadioButton();
            this.radioButtonFFTCH2 = new System.Windows.Forms.RadioButton();
            this.radioButtonFFTCH1 = new System.Windows.Forms.RadioButton();
            this.label24 = new System.Windows.Forms.Label();
            this.checkBoxFFTOn = new System.Windows.Forms.CheckBox();
            this.label3 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.trackBar9 = new System.Windows.Forms.TrackBar();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.trackBar3 = new System.Windows.Forms.TrackBar();
            this.trackBar2 = new System.Windows.Forms.TrackBar();
            this.label42 = new System.Windows.Forms.Label();
            this.trackBar1 = new System.Windows.Forms.TrackBar();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.button6 = new System.Windows.Forms.Button();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label41 = new System.Windows.Forms.Label();
            this.numericUpTTimeout = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.label67 = new System.Windows.Forms.Label();
            this.numericUpDownTHold = new System.Windows.Forms.NumericUpDown();
            this.label36 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.pictureBox24 = new System.Windows.Forms.PictureBox();
            this.radioDual = new System.Windows.Forms.RadioButton();
            this.pictureBox23 = new System.Windows.Forms.PictureBox();
            this.radioWindow = new System.Windows.Forms.RadioButton();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.radioNegative = new System.Windows.Forms.RadioButton();
            this.radioPositive = new System.Windows.Forms.RadioButton();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.radioFalling = new System.Windows.Forms.RadioButton();
            this.radioRising = new System.Windows.Forms.RadioButton();
            this.buttonForce = new System.Windows.Forms.Button();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radioTrigSingle = new System.Windows.Forms.RadioButton();
            this.radioTrigAuto = new System.Windows.Forms.RadioButton();
            this.radioTrigNormal = new System.Windows.Forms.RadioButton();
            this.radioTrigFree = new System.Windows.Forms.RadioButton();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.comboBoxTSource = new System.Windows.Forms.ComboBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.checkBoxStop = new System.Windows.Forms.CheckBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.checkBoxDirection = new System.Windows.Forms.CheckBox();
            this.label72 = new System.Windows.Forms.Label();
            this.labelUnit2 = new System.Windows.Forms.Label();
            this.textBoxSWSpeed = new System.Windows.Forms.TextBox();
            this.labelUnit1 = new System.Windows.Forms.Label();
            this.trackBarSWSpeed = new System.Windows.Forms.TrackBar();
            this.label69 = new System.Windows.Forms.Label();
            this.textBoxSW1 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.trackBarSW2 = new System.Windows.Forms.TrackBar();
            this.trackBarSW1 = new System.Windows.Forms.TrackBar();
            this.checkBoxAccelDir = new System.Windows.Forms.CheckBox();
            this.textBoxSW2 = new System.Windows.Forms.TextBox();
            this.checkBoxAccel = new System.Windows.Forms.CheckBox();
            this.checkBoxSweepF = new System.Windows.Forms.CheckBox();
            this.checkBoxPingPong = new System.Windows.Forms.CheckBox();
            this.checkBoxSweepA = new System.Windows.Forms.CheckBox();
            this.checkBoxSweepO = new System.Windows.Forms.CheckBox();
            this.checkBoxSweepD = new System.Windows.Forms.CheckBox();
            this.labelHz = new System.Windows.Forms.Label();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.radioButton100K = new System.Windows.Forms.RadioButton();
            this.radioButton10K = new System.Windows.Forms.RadioButton();
            this.radioButton1K = new System.Windows.Forms.RadioButton();
            this.radioButton100 = new System.Windows.Forms.RadioButton();
            this.radioButton10 = new System.Windows.Forms.RadioButton();
            this.numericUpDownOffset = new System.Windows.Forms.NumericUpDown();
            this.textBoxF = new System.Windows.Forms.TextBox();
            this.numericUpDownDuty = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownFreq = new System.Windows.Forms.NumericUpDown();
            this.label68 = new System.Windows.Forms.Label();
            this.numericUpDownAmp = new System.Windows.Forms.NumericUpDown();
            this.label40 = new System.Windows.Forms.Label();
            this.trackBarOffset = new System.Windows.Forms.TrackBar();
            this.trackBarDuty = new System.Windows.Forms.TrackBar();
            this.trackBarFreq = new System.Windows.Forms.TrackBar();
            this.trackBarAmp = new System.Windows.Forms.TrackBar();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.buttonSaveAWG = new System.Windows.Forms.Button();
            this.radioButtonExpo = new System.Windows.Forms.RadioButton();
            this.pictureBox22 = new System.Windows.Forms.PictureBox();
            this.radioButtonNoise = new System.Windows.Forms.RadioButton();
            this.buttonOpenCSV = new System.Windows.Forms.Button();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.radioButtonCustom = new System.Windows.Forms.RadioButton();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.radioButtonTrian = new System.Windows.Forms.RadioButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.radioButtonSquare = new System.Windows.Forms.RadioButton();
            this.radioButtonSine = new System.Windows.Forms.RadioButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.checkBoxASCII = new System.Windows.Forms.CheckBox();
            this.checkBoxCircular = new System.Windows.Forms.CheckBox();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.label50 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.comboBoxStops = new System.Windows.Forms.ComboBox();
            this.comboBoxParity = new System.Windows.Forms.ComboBox();
            this.label55 = new System.Windows.Forms.Label();
            this.label54 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.comboBoxBaud = new System.Windows.Forms.ComboBox();
            this.label51 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.tabPage12 = new System.Windows.Forms.TabPage();
            this.label61 = new System.Windows.Forms.Label();
            this.label56 = new System.Windows.Forms.Label();
            this.comboBoxCPHA = new System.Windows.Forms.ComboBox();
            this.label57 = new System.Windows.Forms.Label();
            this.label58 = new System.Windows.Forms.Label();
            this.comboBoxCPOL = new System.Windows.Forms.ComboBox();
            this.label59 = new System.Windows.Forms.Label();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.radioSniffSingle = new System.Windows.Forms.RadioButton();
            this.radioSniffNormal = new System.Windows.Forms.RadioButton();
            this.button20 = new System.Windows.Forms.Button();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.labelConnected = new System.Windows.Forms.Label();
            this.buttonConnect = new System.Windows.Forms.Button();
            this.label31 = new System.Windows.Forms.Label();
            this.checkBox31 = new System.Windows.Forms.CheckBox();
            this.comboBoxCOMS = new System.Windows.Forms.ComboBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button16 = new System.Windows.Forms.Button();
            this.textBoxVersion = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.label64 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.trackBar5 = new System.Windows.Forms.TrackBar();
            this.trackBar4 = new System.Windows.Forms.TrackBar();
            this.label62 = new System.Windows.Forms.Label();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label23 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.button15 = new System.Windows.Forms.Button();
            this.checkBoxLines = new System.Windows.Forms.CheckBox();
            this.checkBoxPersistence = new System.Windows.Forms.CheckBox();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.button12 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.tabPage13 = new System.Windows.Forms.TabPage();
            this.label66 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.labelVersion = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.ScrollBarHPos = new System.Windows.Forms.HScrollBar();
            this.label35 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.labelCH1Gain = new System.Windows.Forms.Label();
            this.labelCH2Gain = new System.Windows.Forms.Label();
            this.labelSRate = new System.Windows.Forms.Label();
            this.labelTriggerLevel = new System.Windows.Forms.Label();
            this.toolTip1 = new System.Windows.Forms.ToolTip(this.components);
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarZoom)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSampling)).BeginInit();
            this.groupBox2.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCH1Gain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCH1Pos)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox19.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCH2Gain)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCH2Pos)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCHDPull)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCHDPos)).BeginInit();
            this.tabPage3.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar9)).BeginInit();
            this.tabPage4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).BeginInit();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpTTimeout)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTHold)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSWSpeed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSW2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSW1)).BeginInit();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDuty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFreq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAmp)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarOffset)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarDuty)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarFreq)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAmp)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.tabPage7.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage10.SuspendLayout();
            this.tabPage11.SuspendLayout();
            this.tabPage12.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            this.groupBox8.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.tabPage13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            this.SuspendLayout();
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button_auto
            // 
            this.button_auto.Location = new System.Drawing.Point(290, 507);
            this.button_auto.Name = "button_auto";
            this.button_auto.Size = new System.Drawing.Size(50, 25);
            this.button_auto.TabIndex = 5;
            this.button_auto.Text = "AUTO";
            this.toolTip1.SetToolTip(this.button_auto, "Scope will try to find the optimum gain and time base for the signals being appli" +
        "ed on CH1 and CH2.");
            this.button_auto.Click += new System.EventHandler(this.button_Auto);
            // 
            // StorageButton
            // 
            this.StorageButton.Enabled = false;
            this.StorageButton.Location = new System.Drawing.Point(12, 507);
            this.StorageButton.Name = "StorageButton";
            this.StorageButton.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.StorageButton.Size = new System.Drawing.Size(50, 25);
            this.StorageButton.TabIndex = 16;
            this.StorageButton.Text = "Save";
            this.StorageButton.Click += new System.EventHandler(this.button5_storage);
            // 
            // serialPort1
            // 
            this.serialPort1.BaudRate = 115200;
            this.serialPort1.DiscardNull = true;
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pictureBox25);
            this.groupBox1.Controls.Add(this.checkBoxElastic);
            this.groupBox1.Controls.Add(this.pictureBox8);
            this.groupBox1.Controls.Add(this.pictureBox20);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.checkBoxRoll);
            this.groupBox1.Controls.Add(this.pictureBox19);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.trackBarZoom);
            this.groupBox1.Controls.Add(this.trackBarSampling);
            this.groupBox1.Controls.Add(this.checkBoxXY);
            this.groupBox1.Location = new System.Drawing.Point(5, 5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(395, 148);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Horizontal";
            // 
            // pictureBox25
            // 
            this.pictureBox25.Image = global::Xprotolab_interface.Properties.Resources.elastic;
            this.pictureBox25.Location = new System.Drawing.Point(249, 117);
            this.pictureBox25.Name = "pictureBox25";
            this.pictureBox25.Size = new System.Drawing.Size(23, 23);
            this.pictureBox25.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox25.TabIndex = 35;
            this.pictureBox25.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox25, resources.GetString("pictureBox25.ToolTip"));
            // 
            // checkBoxElastic
            // 
            this.checkBoxElastic.AutoSize = true;
            this.checkBoxElastic.Location = new System.Drawing.Point(278, 120);
            this.checkBoxElastic.Name = "checkBoxElastic";
            this.checkBoxElastic.Size = new System.Drawing.Size(90, 17);
            this.checkBoxElastic.TabIndex = 35;
            this.checkBoxElastic.Text = "Ellastic Trace";
            this.toolTip1.SetToolTip(this.checkBoxElastic, resources.GetString("checkBoxElastic.ToolTip"));
            this.checkBoxElastic.UseVisualStyleBackColor = true;
            // 
            // pictureBox8
            // 
            this.pictureBox8.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox8.Image")));
            this.pictureBox8.Location = new System.Drawing.Point(7, 28);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(22, 13);
            this.pictureBox8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox8.TabIndex = 5;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox20
            // 
            this.pictureBox20.Image = global::Xprotolab_interface.Properties.Resources.roll;
            this.pictureBox20.Location = new System.Drawing.Point(140, 120);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(23, 20);
            this.pictureBox20.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox20.TabIndex = 24;
            this.pictureBox20.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox20, "The data on the display is scrolled to the left as new data comes in. ");
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(370, 28);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(14, 14);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox7.TabIndex = 4;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(370, 75);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(18, 18);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox6.TabIndex = 3;
            this.pictureBox6.TabStop = false;
            // 
            // checkBoxRoll
            // 
            this.checkBoxRoll.AutoSize = true;
            this.checkBoxRoll.Location = new System.Drawing.Point(169, 120);
            this.checkBoxRoll.Name = "checkBoxRoll";
            this.checkBoxRoll.Size = new System.Drawing.Size(74, 17);
            this.checkBoxRoll.TabIndex = 22;
            this.checkBoxRoll.Text = "Roll Mode";
            this.toolTip1.SetToolTip(this.checkBoxRoll, "The data on the display is scrolled to the left as new data comes in. ");
            this.checkBoxRoll.UseVisualStyleBackColor = true;
            this.checkBoxRoll.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxRoll_MouseClick);
            // 
            // pictureBox19
            // 
            this.pictureBox19.Image = global::Xprotolab_interface.Properties.Resources.xy;
            this.pictureBox19.Location = new System.Drawing.Point(31, 117);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(23, 23);
            this.pictureBox19.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox19.TabIndex = 23;
            this.pictureBox19.TabStop = false;
            this.toolTip1.SetToolTip(this.pictureBox19, "Changes the display from volts vs. time display to volts vs. volts.");
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(11, 75);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(18, 18);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox5.TabIndex = 2;
            this.pictureBox5.TabStop = false;
            // 
            // trackBarZoom
            // 
            this.trackBarZoom.LargeChange = 16;
            this.trackBarZoom.Location = new System.Drawing.Point(28, 68);
            this.trackBarZoom.Maximum = 255;
            this.trackBarZoom.Name = "trackBarZoom";
            this.trackBarZoom.Size = new System.Drawing.Size(337, 45);
            this.trackBarZoom.TabIndex = 1;
            this.trackBarZoom.TickFrequency = 16;
            // 
            // trackBarSampling
            // 
            this.trackBarSampling.Location = new System.Drawing.Point(28, 20);
            this.trackBarSampling.Maximum = 21;
            this.trackBarSampling.Name = "trackBarSampling";
            this.trackBarSampling.Size = new System.Drawing.Size(337, 45);
            this.trackBarSampling.TabIndex = 0;
            this.trackBarSampling.Scroll += new System.EventHandler(this.trackBarSampling_Scroll);
            // 
            // checkBoxXY
            // 
            this.checkBoxXY.AutoSize = true;
            this.checkBoxXY.Location = new System.Drawing.Point(60, 120);
            this.checkBoxXY.Name = "checkBoxXY";
            this.checkBoxXY.Size = new System.Drawing.Size(70, 17);
            this.checkBoxXY.TabIndex = 21;
            this.checkBoxXY.Text = "XY Mode";
            this.toolTip1.SetToolTip(this.checkBoxXY, "Changes the display from volts vs. time display to volts vs. volts.");
            this.checkBoxXY.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.tabControl1);
            this.groupBox2.Location = new System.Drawing.Point(6, 156);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(230, 345);
            this.groupBox2.TabIndex = 19;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Vertical";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Location = new System.Drawing.Point(7, 19);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(217, 315);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.groupBox20);
            this.tabPage1.Controls.Add(this.checkBoxCH1Math);
            this.tabPage1.Controls.Add(this.textBox9);
            this.tabPage1.Controls.Add(this.textBox8);
            this.tabPage1.Controls.Add(this.textBox7);
            this.tabPage1.Controls.Add(this.label46);
            this.tabPage1.Controls.Add(this.label45);
            this.tabPage1.Controls.Add(this.label44);
            this.tabPage1.Controls.Add(this.checkBoxCH1On);
            this.tabPage1.Controls.Add(this.label28);
            this.tabPage1.Controls.Add(this.label27);
            this.tabPage1.Controls.Add(this.trackBarCH1Gain);
            this.tabPage1.Controls.Add(this.trackBarCH1Pos);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Controls.Add(this.button1);
            this.tabPage1.Controls.Add(this.checkBoxCH1Avrg);
            this.tabPage1.Controls.Add(this.checkBoxCH1Inv);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(209, 289);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "CH1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(this.radioButtonCH1Mul);
            this.groupBox20.Controls.Add(this.radioButtonCH1Add);
            this.groupBox20.Location = new System.Drawing.Point(73, 156);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(120, 38);
            this.groupBox20.TabIndex = 49;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Math";
            // 
            // radioButtonCH1Mul
            // 
            this.radioButtonCH1Mul.AutoSize = true;
            this.radioButtonCH1Mul.Location = new System.Drawing.Point(55, 14);
            this.radioButtonCH1Mul.Name = "radioButtonCH1Mul";
            this.radioButtonCH1Mul.Size = new System.Drawing.Size(60, 17);
            this.radioButtonCH1Mul.TabIndex = 1;
            this.radioButtonCH1Mul.TabStop = true;
            this.radioButtonCH1Mul.Text = "Multiply";
            this.toolTip1.SetToolTip(this.radioButtonCH1Mul, "The channel trace will be replaced with CH1xCH2.");
            this.radioButtonCH1Mul.UseVisualStyleBackColor = true;
            this.radioButtonCH1Mul.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonCH1Mul_MouseClick);
            // 
            // radioButtonCH1Add
            // 
            this.radioButtonCH1Add.AutoSize = true;
            this.radioButtonCH1Add.Location = new System.Drawing.Point(8, 14);
            this.radioButtonCH1Add.Name = "radioButtonCH1Add";
            this.radioButtonCH1Add.Size = new System.Drawing.Size(44, 17);
            this.radioButtonCH1Add.TabIndex = 0;
            this.radioButtonCH1Add.TabStop = true;
            this.radioButtonCH1Add.Text = "Sub";
            this.toolTip1.SetToolTip(this.radioButtonCH1Add, "The channel trace will be replaced with CH1-CH2.");
            this.radioButtonCH1Add.UseVisualStyleBackColor = true;
            this.radioButtonCH1Add.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonCH1Add_MouseClick);
            // 
            // checkBoxCH1Math
            // 
            this.checkBoxCH1Math.AutoSize = true;
            this.checkBoxCH1Math.Location = new System.Drawing.Point(137, 103);
            this.checkBoxCH1Math.Name = "checkBoxCH1Math";
            this.checkBoxCH1Math.Size = new System.Drawing.Size(50, 17);
            this.checkBoxCH1Math.TabIndex = 41;
            this.checkBoxCH1Math.Text = "Math";
            this.toolTip1.SetToolTip(this.checkBoxCH1Math, "The channel math will be enabled.");
            this.checkBoxCH1Math.UseVisualStyleBackColor = true;
            this.checkBoxCH1Math.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCH1Math_MouseClick);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(111, 205);
            this.textBox9.Name = "textBox9";
            this.textBox9.ReadOnly = true;
            this.textBox9.Size = new System.Drawing.Size(83, 20);
            this.textBox9.TabIndex = 40;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(111, 230);
            this.textBox8.Name = "textBox8";
            this.textBox8.ReadOnly = true;
            this.textBox8.Size = new System.Drawing.Size(83, 20);
            this.textBox8.TabIndex = 39;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(111, 254);
            this.textBox7.Name = "textBox7";
            this.textBox7.ReadOnly = true;
            this.textBox7.Size = new System.Drawing.Size(83, 20);
            this.textBox7.TabIndex = 38;
            // 
            // label46
            // 
            this.label46.AutoSize = true;
            this.label46.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label46.Location = new System.Drawing.Point(72, 256);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(32, 13);
            this.label46.TabIndex = 37;
            this.label46.Text = "Freq";
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label45.Location = new System.Drawing.Point(74, 234);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(31, 13);
            this.label45.TabIndex = 36;
            this.label45.Text = "VPP";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.Location = new System.Drawing.Point(73, 208);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(32, 13);
            this.label44.TabIndex = 35;
            this.label44.Text = "VDC";
            // 
            // checkBoxCH1On
            // 
            this.checkBoxCH1On.AutoSize = true;
            this.checkBoxCH1On.Checked = true;
            this.checkBoxCH1On.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCH1On.Location = new System.Drawing.Point(137, 22);
            this.checkBoxCH1On.Name = "checkBoxCH1On";
            this.checkBoxCH1On.Size = new System.Drawing.Size(54, 17);
            this.checkBoxCH1On.TabIndex = 8;
            this.checkBoxCH1On.Text = "Trace";
            this.toolTip1.SetToolTip(this.checkBoxCH1On, "Display CH1 trace.");
            this.checkBoxCH1On.UseVisualStyleBackColor = true;
            this.checkBoxCH1On.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCH1On_MouseClick);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(7, 8);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(44, 13);
            this.label28.TabIndex = 7;
            this.label28.Text = "Position";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(73, 8);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(29, 13);
            this.label27.TabIndex = 6;
            this.label27.Text = "Gain";
            // 
            // trackBarCH1Gain
            // 
            this.trackBarCH1Gain.Location = new System.Drawing.Point(73, 22);
            this.trackBarCH1Gain.Maximum = 6;
            this.trackBarCH1Gain.Name = "trackBarCH1Gain";
            this.trackBarCH1Gain.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarCH1Gain.Size = new System.Drawing.Size(45, 128);
            this.trackBarCH1Gain.TabIndex = 5;
            this.trackBarCH1Gain.Scroll += new System.EventHandler(this.trackBarCH1Gain_Scroll);
            // 
            // trackBarCH1Pos
            // 
            this.trackBarCH1Pos.Location = new System.Drawing.Point(16, 22);
            this.trackBarCH1Pos.Maximum = 0;
            this.trackBarCH1Pos.Minimum = -126;
            this.trackBarCH1Pos.Name = "trackBarCH1Pos";
            this.trackBarCH1Pos.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarCH1Pos.Size = new System.Drawing.Size(45, 256);
            this.trackBarCH1Pos.SmallChange = 2;
            this.trackBarCH1Pos.TabIndex = 4;
            this.trackBarCH1Pos.TickFrequency = 16;
            this.trackBarCH1Pos.Value = -64;
            this.trackBarCH1Pos.Scroll += new System.EventHandler(this.trackBarCH1Pos_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(154, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Color";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.Lime;
            this.button1.Location = new System.Drawing.Point(137, 130);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(13, 14);
            this.button1.TabIndex = 2;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // checkBoxCH1Avrg
            // 
            this.checkBoxCH1Avrg.AutoSize = true;
            this.checkBoxCH1Avrg.Location = new System.Drawing.Point(137, 76);
            this.checkBoxCH1Avrg.Name = "checkBoxCH1Avrg";
            this.checkBoxCH1Avrg.Size = new System.Drawing.Size(66, 17);
            this.checkBoxCH1Avrg.TabIndex = 1;
            this.checkBoxCH1Avrg.Text = "Average";
            this.toolTip1.SetToolTip(this.checkBoxCH1Avrg, "The channel samples will be averaged to reduce aliasing.");
            this.checkBoxCH1Avrg.UseVisualStyleBackColor = true;
            this.checkBoxCH1Avrg.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCH1Avrg_MouseClick);
            // 
            // checkBoxCH1Inv
            // 
            this.checkBoxCH1Inv.AutoSize = true;
            this.checkBoxCH1Inv.Location = new System.Drawing.Point(137, 49);
            this.checkBoxCH1Inv.Name = "checkBoxCH1Inv";
            this.checkBoxCH1Inv.Size = new System.Drawing.Size(53, 17);
            this.checkBoxCH1Inv.TabIndex = 0;
            this.checkBoxCH1Inv.Text = "Invert";
            this.toolTip1.SetToolTip(this.checkBoxCH1Inv, "The channel will be inverted. The displayed waveform and channel math will be aff" +
        "ected.");
            this.checkBoxCH1Inv.UseVisualStyleBackColor = true;
            this.checkBoxCH1Inv.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCH1Inv_MouseClick);
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.groupBox19);
            this.tabPage2.Controls.Add(this.checkBoxCH2Math);
            this.tabPage2.Controls.Add(this.textBox10);
            this.tabPage2.Controls.Add(this.textBox11);
            this.tabPage2.Controls.Add(this.textBox12);
            this.tabPage2.Controls.Add(this.label47);
            this.tabPage2.Controls.Add(this.label48);
            this.tabPage2.Controls.Add(this.label49);
            this.tabPage2.Controls.Add(this.checkBoxCH2On);
            this.tabPage2.Controls.Add(this.label29);
            this.tabPage2.Controls.Add(this.label30);
            this.tabPage2.Controls.Add(this.trackBarCH2Gain);
            this.tabPage2.Controls.Add(this.trackBarCH2Pos);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.checkBoxCH2Avrg);
            this.tabPage2.Controls.Add(this.checkBoxCH2Inv);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(209, 289);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "CH2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.radioButtonCH2Mul);
            this.groupBox19.Controls.Add(this.radioButtonCH2Add);
            this.groupBox19.Location = new System.Drawing.Point(73, 156);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(120, 38);
            this.groupBox19.TabIndex = 48;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Math";
            // 
            // radioButtonCH2Mul
            // 
            this.radioButtonCH2Mul.AutoSize = true;
            this.radioButtonCH2Mul.Location = new System.Drawing.Point(55, 14);
            this.radioButtonCH2Mul.Name = "radioButtonCH2Mul";
            this.radioButtonCH2Mul.Size = new System.Drawing.Size(60, 17);
            this.radioButtonCH2Mul.TabIndex = 1;
            this.radioButtonCH2Mul.TabStop = true;
            this.radioButtonCH2Mul.Text = "Multiply";
            this.toolTip1.SetToolTip(this.radioButtonCH2Mul, "The channel trace will be replaced with CH1xCH2.");
            this.radioButtonCH2Mul.UseVisualStyleBackColor = true;
            this.radioButtonCH2Mul.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonCH2Mul_MouseClick);
            // 
            // radioButtonCH2Add
            // 
            this.radioButtonCH2Add.AutoSize = true;
            this.radioButtonCH2Add.Location = new System.Drawing.Point(8, 14);
            this.radioButtonCH2Add.Name = "radioButtonCH2Add";
            this.radioButtonCH2Add.Size = new System.Drawing.Size(44, 17);
            this.radioButtonCH2Add.TabIndex = 0;
            this.radioButtonCH2Add.TabStop = true;
            this.radioButtonCH2Add.Text = "Sub";
            this.toolTip1.SetToolTip(this.radioButtonCH2Add, "The channel trace will be replaced with CH2-CH1.");
            this.radioButtonCH2Add.UseVisualStyleBackColor = true;
            this.radioButtonCH2Add.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonCH2Add_MouseClick);
            // 
            // checkBoxCH2Math
            // 
            this.checkBoxCH2Math.AutoSize = true;
            this.checkBoxCH2Math.Location = new System.Drawing.Point(137, 103);
            this.checkBoxCH2Math.Name = "checkBoxCH2Math";
            this.checkBoxCH2Math.Size = new System.Drawing.Size(50, 17);
            this.checkBoxCH2Math.TabIndex = 47;
            this.checkBoxCH2Math.Text = "Math";
            this.toolTip1.SetToolTip(this.checkBoxCH2Math, "The channel math will be enabled.");
            this.checkBoxCH2Math.UseVisualStyleBackColor = true;
            this.checkBoxCH2Math.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCH2Math_MouseClick);
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(111, 205);
            this.textBox10.Name = "textBox10";
            this.textBox10.ReadOnly = true;
            this.textBox10.Size = new System.Drawing.Size(83, 20);
            this.textBox10.TabIndex = 46;
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(111, 230);
            this.textBox11.Name = "textBox11";
            this.textBox11.ReadOnly = true;
            this.textBox11.Size = new System.Drawing.Size(83, 20);
            this.textBox11.TabIndex = 45;
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(111, 254);
            this.textBox12.Name = "textBox12";
            this.textBox12.ReadOnly = true;
            this.textBox12.Size = new System.Drawing.Size(83, 20);
            this.textBox12.TabIndex = 44;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label47.Location = new System.Drawing.Point(72, 256);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(32, 13);
            this.label47.TabIndex = 43;
            this.label47.Text = "Freq";
            // 
            // label48
            // 
            this.label48.AutoSize = true;
            this.label48.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label48.Location = new System.Drawing.Point(74, 234);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(31, 13);
            this.label48.TabIndex = 42;
            this.label48.Text = "VPP";
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(73, 208);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(32, 13);
            this.label49.TabIndex = 41;
            this.label49.Text = "VDC";
            // 
            // checkBoxCH2On
            // 
            this.checkBoxCH2On.AutoSize = true;
            this.checkBoxCH2On.Checked = true;
            this.checkBoxCH2On.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCH2On.Location = new System.Drawing.Point(137, 22);
            this.checkBoxCH2On.Name = "checkBoxCH2On";
            this.checkBoxCH2On.Size = new System.Drawing.Size(54, 17);
            this.checkBoxCH2On.TabIndex = 12;
            this.checkBoxCH2On.Text = "Trace";
            this.toolTip1.SetToolTip(this.checkBoxCH2On, "Display CH2 trace.");
            this.checkBoxCH2On.UseVisualStyleBackColor = true;
            this.checkBoxCH2On.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCH2On_MouseClick);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(7, 8);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(44, 13);
            this.label29.TabIndex = 11;
            this.label29.Text = "Position";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(73, 8);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(29, 13);
            this.label30.TabIndex = 10;
            this.label30.Text = "Gain";
            // 
            // trackBarCH2Gain
            // 
            this.trackBarCH2Gain.Location = new System.Drawing.Point(73, 22);
            this.trackBarCH2Gain.Maximum = 6;
            this.trackBarCH2Gain.Name = "trackBarCH2Gain";
            this.trackBarCH2Gain.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarCH2Gain.Size = new System.Drawing.Size(45, 128);
            this.trackBarCH2Gain.TabIndex = 9;
            this.trackBarCH2Gain.Scroll += new System.EventHandler(this.trackBarCH2Gain_Scroll);
            // 
            // trackBarCH2Pos
            // 
            this.trackBarCH2Pos.Location = new System.Drawing.Point(16, 22);
            this.trackBarCH2Pos.Maximum = 0;
            this.trackBarCH2Pos.Minimum = -126;
            this.trackBarCH2Pos.Name = "trackBarCH2Pos";
            this.trackBarCH2Pos.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarCH2Pos.Size = new System.Drawing.Size(45, 256);
            this.trackBarCH2Pos.SmallChange = 2;
            this.trackBarCH2Pos.TabIndex = 8;
            this.trackBarCH2Pos.TickFrequency = 16;
            this.trackBarCH2Pos.Value = -64;
            this.trackBarCH2Pos.Scroll += new System.EventHandler(this.trackBarCH2Pos_Scroll);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(154, 131);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Color";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.Red;
            this.button2.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button2.Location = new System.Drawing.Point(137, 130);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(13, 14);
            this.button2.TabIndex = 3;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // checkBoxCH2Avrg
            // 
            this.checkBoxCH2Avrg.AutoSize = true;
            this.checkBoxCH2Avrg.Location = new System.Drawing.Point(137, 76);
            this.checkBoxCH2Avrg.Name = "checkBoxCH2Avrg";
            this.checkBoxCH2Avrg.Size = new System.Drawing.Size(66, 17);
            this.checkBoxCH2Avrg.TabIndex = 1;
            this.checkBoxCH2Avrg.Text = "Average";
            this.toolTip1.SetToolTip(this.checkBoxCH2Avrg, "The channel samples will be averaged to reduce aliasing.");
            this.checkBoxCH2Avrg.UseVisualStyleBackColor = true;
            this.checkBoxCH2Avrg.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCH2Avrg_MouseClick);
            // 
            // checkBoxCH2Inv
            // 
            this.checkBoxCH2Inv.AutoSize = true;
            this.checkBoxCH2Inv.Location = new System.Drawing.Point(137, 49);
            this.checkBoxCH2Inv.Name = "checkBoxCH2Inv";
            this.checkBoxCH2Inv.Size = new System.Drawing.Size(53, 17);
            this.checkBoxCH2Inv.TabIndex = 0;
            this.checkBoxCH2Inv.Text = "Invert";
            this.toolTip1.SetToolTip(this.checkBoxCH2Inv, "The channel will be inverted. The displayed waveform and channel math will be aff" +
        "ected.");
            this.checkBoxCH2Inv.UseVisualStyleBackColor = true;
            this.checkBoxCH2Inv.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCH2Inv_MouseClick);
            // 
            // tabPage9
            // 
            this.tabPage9.Controls.Add(this.checkBox3);
            this.tabPage9.Controls.Add(this.checkBoxCHD7);
            this.tabPage9.Controls.Add(this.checkBoxCHD6);
            this.tabPage9.Controls.Add(this.checkBoxCHD5);
            this.tabPage9.Controls.Add(this.checkBoxCHD4);
            this.tabPage9.Controls.Add(this.checkBoxCHD3);
            this.tabPage9.Controls.Add(this.checkBoxCHD2);
            this.tabPage9.Controls.Add(this.checkBoxCHD1);
            this.tabPage9.Controls.Add(this.checkBoxCHD0);
            this.tabPage9.Controls.Add(this.checkBoxCHDSerial);
            this.tabPage9.Controls.Add(this.checkBoxCHDParallel);
            this.tabPage9.Controls.Add(this.label19);
            this.tabPage9.Controls.Add(this.label33);
            this.tabPage9.Controls.Add(this.label18);
            this.tabPage9.Controls.Add(this.label17);
            this.tabPage9.Controls.Add(this.label32);
            this.tabPage9.Controls.Add(this.label16);
            this.tabPage9.Controls.Add(this.label26);
            this.tabPage9.Controls.Add(this.label15);
            this.tabPage9.Controls.Add(this.trackBarCHDPull);
            this.tabPage9.Controls.Add(this.label14);
            this.tabPage9.Controls.Add(this.label34);
            this.tabPage9.Controls.Add(this.label13);
            this.tabPage9.Controls.Add(this.label25);
            this.tabPage9.Controls.Add(this.label12);
            this.tabPage9.Controls.Add(this.trackBar18);
            this.tabPage9.Controls.Add(this.trackBarCHDPos);
            this.tabPage9.Controls.Add(this.checkBoxCHDThick);
            this.tabPage9.Controls.Add(this.button8);
            this.tabPage9.Controls.Add(this.label7);
            this.tabPage9.Controls.Add(this.checkBoxCHDInv);
            this.tabPage9.Controls.Add(this.checkBoxCHDOn);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(209, 289);
            this.tabPage9.TabIndex = 4;
            this.tabPage9.Text = "LOGIC";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(137, 103);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(62, 17);
            this.checkBox3.TabIndex = 52;
            this.checkBox3.Text = "Thick 1";
            this.toolTip1.SetToolTip(this.checkBox3, "A thick line is drawn when the signal is at logic ‘1’. ");
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBoxCHD7
            // 
            this.checkBoxCHD7.AutoSize = true;
            this.checkBoxCHD7.Checked = true;
            this.checkBoxCHD7.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCHD7.Location = new System.Drawing.Point(18, 260);
            this.checkBoxCHD7.Name = "checkBoxCHD7";
            this.checkBoxCHD7.Size = new System.Drawing.Size(15, 14);
            this.checkBoxCHD7.TabIndex = 51;
            this.checkBoxCHD7.UseVisualStyleBackColor = true;
            this.checkBoxCHD7.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHD7_MouseClick);
            // 
            // checkBoxCHD6
            // 
            this.checkBoxCHD6.AutoSize = true;
            this.checkBoxCHD6.Checked = true;
            this.checkBoxCHD6.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCHD6.Location = new System.Drawing.Point(40, 260);
            this.checkBoxCHD6.Name = "checkBoxCHD6";
            this.checkBoxCHD6.Size = new System.Drawing.Size(15, 14);
            this.checkBoxCHD6.TabIndex = 50;
            this.checkBoxCHD6.UseVisualStyleBackColor = true;
            this.checkBoxCHD6.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHD6_MouseClick);
            // 
            // checkBoxCHD5
            // 
            this.checkBoxCHD5.AutoSize = true;
            this.checkBoxCHD5.Checked = true;
            this.checkBoxCHD5.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCHD5.Location = new System.Drawing.Point(62, 260);
            this.checkBoxCHD5.Name = "checkBoxCHD5";
            this.checkBoxCHD5.Size = new System.Drawing.Size(15, 14);
            this.checkBoxCHD5.TabIndex = 49;
            this.checkBoxCHD5.UseVisualStyleBackColor = true;
            this.checkBoxCHD5.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHD5_MouseClick);
            // 
            // checkBoxCHD4
            // 
            this.checkBoxCHD4.AutoSize = true;
            this.checkBoxCHD4.Checked = true;
            this.checkBoxCHD4.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCHD4.Location = new System.Drawing.Point(84, 260);
            this.checkBoxCHD4.Name = "checkBoxCHD4";
            this.checkBoxCHD4.Size = new System.Drawing.Size(15, 14);
            this.checkBoxCHD4.TabIndex = 48;
            this.checkBoxCHD4.UseVisualStyleBackColor = true;
            this.checkBoxCHD4.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHD4_MouseClick);
            // 
            // checkBoxCHD3
            // 
            this.checkBoxCHD3.AutoSize = true;
            this.checkBoxCHD3.Checked = true;
            this.checkBoxCHD3.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCHD3.Location = new System.Drawing.Point(106, 260);
            this.checkBoxCHD3.Name = "checkBoxCHD3";
            this.checkBoxCHD3.Size = new System.Drawing.Size(15, 14);
            this.checkBoxCHD3.TabIndex = 47;
            this.checkBoxCHD3.UseVisualStyleBackColor = true;
            this.checkBoxCHD3.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHD3_MouseClick);
            // 
            // checkBoxCHD2
            // 
            this.checkBoxCHD2.AutoSize = true;
            this.checkBoxCHD2.Checked = true;
            this.checkBoxCHD2.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCHD2.Location = new System.Drawing.Point(128, 260);
            this.checkBoxCHD2.Name = "checkBoxCHD2";
            this.checkBoxCHD2.Size = new System.Drawing.Size(15, 14);
            this.checkBoxCHD2.TabIndex = 46;
            this.checkBoxCHD2.UseVisualStyleBackColor = true;
            this.checkBoxCHD2.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHD2_MouseClick);
            // 
            // checkBoxCHD1
            // 
            this.checkBoxCHD1.AutoSize = true;
            this.checkBoxCHD1.Checked = true;
            this.checkBoxCHD1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCHD1.Location = new System.Drawing.Point(150, 260);
            this.checkBoxCHD1.Name = "checkBoxCHD1";
            this.checkBoxCHD1.Size = new System.Drawing.Size(15, 14);
            this.checkBoxCHD1.TabIndex = 45;
            this.checkBoxCHD1.UseVisualStyleBackColor = true;
            this.checkBoxCHD1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHD1_MouseClick);
            // 
            // checkBoxCHD0
            // 
            this.checkBoxCHD0.AutoSize = true;
            this.checkBoxCHD0.Checked = true;
            this.checkBoxCHD0.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxCHD0.Location = new System.Drawing.Point(172, 260);
            this.checkBoxCHD0.Name = "checkBoxCHD0";
            this.checkBoxCHD0.Size = new System.Drawing.Size(15, 14);
            this.checkBoxCHD0.TabIndex = 44;
            this.checkBoxCHD0.UseVisualStyleBackColor = true;
            this.checkBoxCHD0.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHD0_MouseClick);
            // 
            // checkBoxCHDSerial
            // 
            this.checkBoxCHDSerial.AutoSize = true;
            this.checkBoxCHDSerial.Location = new System.Drawing.Point(137, 205);
            this.checkBoxCHDSerial.Name = "checkBoxCHDSerial";
            this.checkBoxCHDSerial.Size = new System.Drawing.Size(52, 17);
            this.checkBoxCHDSerial.TabIndex = 43;
            this.checkBoxCHDSerial.Text = "Serial";
            this.toolTip1.SetToolTip(this.checkBoxCHDSerial, "Shows the hexadecimal value of the stream of bits on each channel. ");
            this.checkBoxCHDSerial.UseVisualStyleBackColor = true;
            // 
            // checkBoxCHDParallel
            // 
            this.checkBoxCHDParallel.AutoSize = true;
            this.checkBoxCHDParallel.Location = new System.Drawing.Point(137, 181);
            this.checkBoxCHDParallel.Name = "checkBoxCHDParallel";
            this.checkBoxCHDParallel.Size = new System.Drawing.Size(60, 17);
            this.checkBoxCHDParallel.TabIndex = 42;
            this.checkBoxCHDParallel.Text = "Parallel";
            this.toolTip1.SetToolTip(this.checkBoxCHDParallel, "Shows the hexadecimal value of the 8 bit digital input lines. ");
            this.checkBoxCHDParallel.UseVisualStyleBackColor = true;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(39, 242);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(15, 15);
            this.label19.TabIndex = 41;
            this.label19.Text = "6";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(10, 213);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(55, 13);
            this.label33.TabIndex = 41;
            this.label33.Text = "Pull Down";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(17, 242);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(15, 15);
            this.label18.TabIndex = 40;
            this.label18.Text = "7";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(61, 242);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(15, 15);
            this.label17.TabIndex = 39;
            this.label17.Text = "5";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(22, 198);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(41, 13);
            this.label32.TabIndex = 40;
            this.label32.Text = "No Pull";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(105, 242);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(15, 15);
            this.label16.TabIndex = 38;
            this.label16.Text = "3";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(23, 182);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(41, 13);
            this.label26.TabIndex = 39;
            this.label26.Text = "Pull Up";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(83, 242);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(15, 15);
            this.label15.TabIndex = 37;
            this.label15.Text = "4";
            // 
            // trackBarCHDPull
            // 
            this.trackBarCHDPull.Location = new System.Drawing.Point(73, 175);
            this.trackBarCHDPull.Maximum = 2;
            this.trackBarCHDPull.Name = "trackBarCHDPull";
            this.trackBarCHDPull.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarCHDPull.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBarCHDPull.Size = new System.Drawing.Size(45, 59);
            this.trackBarCHDPull.TabIndex = 38;
            this.trackBarCHDPull.TickStyle = System.Windows.Forms.TickStyle.None;
            this.trackBarCHDPull.Value = 1;
            this.trackBarCHDPull.Scroll += new System.EventHandler(this.trackBarCHDPull_Scroll);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(127, 242);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(15, 15);
            this.label14.TabIndex = 36;
            this.label14.Text = "2";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(73, 8);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(27, 13);
            this.label34.TabIndex = 37;
            this.label34.Text = "Size";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(149, 242);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(15, 15);
            this.label13.TabIndex = 35;
            this.label13.Text = "1";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(7, 8);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(44, 13);
            this.label25.TabIndex = 36;
            this.label25.Text = "Position";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(171, 242);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(15, 15);
            this.label12.TabIndex = 34;
            this.label12.Text = "0";
            // 
            // trackBar18
            // 
            this.trackBar18.Location = new System.Drawing.Point(73, 22);
            this.trackBar18.Maximum = 6;
            this.trackBar18.Name = "trackBar18";
            this.trackBar18.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar18.Size = new System.Drawing.Size(45, 128);
            this.trackBar18.TabIndex = 35;
            // 
            // trackBarCHDPos
            // 
            this.trackBarCHDPos.LargeChange = 1;
            this.trackBarCHDPos.Location = new System.Drawing.Point(16, 22);
            this.trackBarCHDPos.Maximum = 7;
            this.trackBarCHDPos.Name = "trackBarCHDPos";
            this.trackBarCHDPos.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBarCHDPos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.trackBarCHDPos.Size = new System.Drawing.Size(45, 128);
            this.trackBarCHDPos.TabIndex = 34;
            this.trackBarCHDPos.Scroll += new System.EventHandler(this.trackBarCHDPos_Scroll);
            // 
            // checkBoxCHDThick
            // 
            this.checkBoxCHDThick.AutoSize = true;
            this.checkBoxCHDThick.Location = new System.Drawing.Point(137, 76);
            this.checkBoxCHDThick.Name = "checkBoxCHDThick";
            this.checkBoxCHDThick.Size = new System.Drawing.Size(62, 17);
            this.checkBoxCHDThick.TabIndex = 33;
            this.checkBoxCHDThick.Text = "Thick 0";
            this.toolTip1.SetToolTip(this.checkBoxCHDThick, "A thick line is drawn when the signal is at logic ‘0’. ");
            this.checkBoxCHDThick.UseVisualStyleBackColor = true;
            this.checkBoxCHDThick.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHDThick_MouseClick);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.Color.Blue;
            this.button8.Location = new System.Drawing.Point(137, 130);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(13, 14);
            this.button8.TabIndex = 12;
            this.button8.UseVisualStyleBackColor = false;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(154, 131);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(31, 13);
            this.label7.TabIndex = 11;
            this.label7.Text = "Color";
            // 
            // checkBoxCHDInv
            // 
            this.checkBoxCHDInv.AutoSize = true;
            this.checkBoxCHDInv.Location = new System.Drawing.Point(137, 49);
            this.checkBoxCHDInv.Name = "checkBoxCHDInv";
            this.checkBoxCHDInv.Size = new System.Drawing.Size(53, 17);
            this.checkBoxCHDInv.TabIndex = 10;
            this.checkBoxCHDInv.Text = "Invert";
            this.toolTip1.SetToolTip(this.checkBoxCHDInv, "All digital channels are inverted.");
            this.checkBoxCHDInv.UseVisualStyleBackColor = true;
            this.checkBoxCHDInv.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHDInv_MouseClick);
            // 
            // checkBoxCHDOn
            // 
            this.checkBoxCHDOn.AutoSize = true;
            this.checkBoxCHDOn.Location = new System.Drawing.Point(137, 22);
            this.checkBoxCHDOn.Name = "checkBoxCHDOn";
            this.checkBoxCHDOn.Size = new System.Drawing.Size(54, 17);
            this.checkBoxCHDOn.TabIndex = 1;
            this.checkBoxCHDOn.Text = "Trace";
            this.toolTip1.SetToolTip(this.checkBoxCHDOn, "Display logic traces.");
            this.checkBoxCHDOn.UseVisualStyleBackColor = true;
            this.checkBoxCHDOn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCHDOn_MouseClick);
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.checkBoxIQFFT);
            this.tabPage3.Controls.Add(this.checkBoxLog);
            this.tabPage3.Controls.Add(this.groupBox14);
            this.tabPage3.Controls.Add(this.groupBox13);
            this.tabPage3.Controls.Add(this.label24);
            this.tabPage3.Controls.Add(this.checkBoxFFTOn);
            this.tabPage3.Controls.Add(this.label3);
            this.tabPage3.Controls.Add(this.button3);
            this.tabPage3.Controls.Add(this.trackBar9);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(209, 289);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "FFT";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // checkBoxIQFFT
            // 
            this.checkBoxIQFFT.AutoSize = true;
            this.checkBoxIQFFT.Location = new System.Drawing.Point(77, 49);
            this.checkBoxIQFFT.Name = "checkBoxIQFFT";
            this.checkBoxIQFFT.Size = new System.Drawing.Size(59, 17);
            this.checkBoxIQFFT.TabIndex = 42;
            this.checkBoxIQFFT.Text = "IQ FFT";
            this.checkBoxIQFFT.UseVisualStyleBackColor = true;
            this.checkBoxIQFFT.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxIQFFT_MouseClick);
            // 
            // checkBoxLog
            // 
            this.checkBoxLog.AutoSize = true;
            this.checkBoxLog.Location = new System.Drawing.Point(77, 22);
            this.checkBoxLog.Name = "checkBoxLog";
            this.checkBoxLog.Size = new System.Drawing.Size(54, 17);
            this.checkBoxLog.TabIndex = 41;
            this.checkBoxLog.Text = "Log Y";
            this.checkBoxLog.UseVisualStyleBackColor = true;
            this.checkBoxLog.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxLog_MouseClick);
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.radioButtonBlackman);
            this.groupBox14.Controls.Add(this.radioButtonHann);
            this.groupBox14.Controls.Add(this.radioButtonHamming);
            this.groupBox14.Controls.Add(this.radioButtonRectangular);
            this.groupBox14.Location = new System.Drawing.Point(77, 171);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(125, 112);
            this.groupBox14.TabIndex = 40;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "FFT Window";
            // 
            // radioButtonBlackman
            // 
            this.radioButtonBlackman.AutoSize = true;
            this.radioButtonBlackman.Location = new System.Drawing.Point(17, 82);
            this.radioButtonBlackman.Name = "radioButtonBlackman";
            this.radioButtonBlackman.Size = new System.Drawing.Size(72, 17);
            this.radioButtonBlackman.TabIndex = 3;
            this.radioButtonBlackman.TabStop = true;
            this.radioButtonBlackman.Text = "Blackman";
            this.radioButtonBlackman.UseVisualStyleBackColor = true;
            this.radioButtonBlackman.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonBlackman_MouseClick);
            // 
            // radioButtonHann
            // 
            this.radioButtonHann.AutoSize = true;
            this.radioButtonHann.Location = new System.Drawing.Point(17, 61);
            this.radioButtonHann.Name = "radioButtonHann";
            this.radioButtonHann.Size = new System.Drawing.Size(51, 17);
            this.radioButtonHann.TabIndex = 2;
            this.radioButtonHann.TabStop = true;
            this.radioButtonHann.Text = "Hann";
            this.radioButtonHann.UseVisualStyleBackColor = true;
            this.radioButtonHann.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonHann_MouseClick);
            // 
            // radioButtonHamming
            // 
            this.radioButtonHamming.AutoSize = true;
            this.radioButtonHamming.Location = new System.Drawing.Point(17, 40);
            this.radioButtonHamming.Name = "radioButtonHamming";
            this.radioButtonHamming.Size = new System.Drawing.Size(69, 17);
            this.radioButtonHamming.TabIndex = 1;
            this.radioButtonHamming.TabStop = true;
            this.radioButtonHamming.Text = "Hamming";
            this.radioButtonHamming.UseVisualStyleBackColor = true;
            this.radioButtonHamming.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonHamming_MouseClick);
            // 
            // radioButtonRectangular
            // 
            this.radioButtonRectangular.AutoSize = true;
            this.radioButtonRectangular.Location = new System.Drawing.Point(17, 19);
            this.radioButtonRectangular.Name = "radioButtonRectangular";
            this.radioButtonRectangular.Size = new System.Drawing.Size(83, 17);
            this.radioButtonRectangular.TabIndex = 0;
            this.radioButtonRectangular.TabStop = true;
            this.radioButtonRectangular.Text = "Rectangular";
            this.radioButtonRectangular.UseVisualStyleBackColor = true;
            this.radioButtonRectangular.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonRectangular_MouseClick);
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.radioButtonFFT);
            this.groupBox13.Controls.Add(this.radioButtonFFTCH2);
            this.groupBox13.Controls.Add(this.radioButtonFFTCH1);
            this.groupBox13.Location = new System.Drawing.Point(77, 77);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(125, 88);
            this.groupBox13.TabIndex = 38;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Plot";
            // 
            // radioButtonFFT
            // 
            this.radioButtonFFT.AutoSize = true;
            this.radioButtonFFT.Location = new System.Drawing.Point(17, 61);
            this.radioButtonFFT.Name = "radioButtonFFT";
            this.radioButtonFFT.Size = new System.Drawing.Size(79, 17);
            this.radioButtonFFT.TabIndex = 7;
            this.radioButtonFFT.TabStop = true;
            this.radioButtonFFT.Text = "CH1 && CH2";
            this.radioButtonFFT.UseVisualStyleBackColor = true;
            // 
            // radioButtonFFTCH2
            // 
            this.radioButtonFFTCH2.AutoSize = true;
            this.radioButtonFFTCH2.Location = new System.Drawing.Point(17, 40);
            this.radioButtonFFTCH2.Name = "radioButtonFFTCH2";
            this.radioButtonFFTCH2.Size = new System.Drawing.Size(46, 17);
            this.radioButtonFFTCH2.TabIndex = 6;
            this.radioButtonFFTCH2.TabStop = true;
            this.radioButtonFFTCH2.Text = "CH2";
            this.radioButtonFFTCH2.UseVisualStyleBackColor = true;
            // 
            // radioButtonFFTCH1
            // 
            this.radioButtonFFTCH1.AutoSize = true;
            this.radioButtonFFTCH1.Location = new System.Drawing.Point(17, 19);
            this.radioButtonFFTCH1.Name = "radioButtonFFTCH1";
            this.radioButtonFFTCH1.Size = new System.Drawing.Size(46, 17);
            this.radioButtonFFTCH1.TabIndex = 3;
            this.radioButtonFFTCH1.TabStop = true;
            this.radioButtonFFTCH1.Text = "CH1";
            this.radioButtonFFTCH1.UseVisualStyleBackColor = true;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(7, 8);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(44, 13);
            this.label24.TabIndex = 37;
            this.label24.Text = "Position";
            // 
            // checkBoxFFTOn
            // 
            this.checkBoxFFTOn.AutoSize = true;
            this.checkBoxFFTOn.Location = new System.Drawing.Point(137, 22);
            this.checkBoxFFTOn.Name = "checkBoxFFTOn";
            this.checkBoxFFTOn.Size = new System.Drawing.Size(54, 17);
            this.checkBoxFFTOn.TabIndex = 10;
            this.checkBoxFFTOn.Text = "Trace";
            this.checkBoxFFTOn.UseVisualStyleBackColor = true;
            this.checkBoxFFTOn.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxFFTOn_MouseClick);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(154, 50);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Color";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.Fuchsia;
            this.button3.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button3.Location = new System.Drawing.Point(137, 49);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(13, 14);
            this.button3.TabIndex = 4;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // trackBar9
            // 
            this.trackBar9.Location = new System.Drawing.Point(16, 22);
            this.trackBar9.Maximum = 0;
            this.trackBar9.Minimum = -127;
            this.trackBar9.Name = "trackBar9";
            this.trackBar9.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar9.Size = new System.Drawing.Size(45, 256);
            this.trackBar9.TabIndex = 9;
            this.trackBar9.TickFrequency = 16;
            this.trackBar9.Value = -64;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.trackBar3);
            this.tabPage4.Controls.Add(this.trackBar2);
            this.tabPage4.Controls.Add(this.label42);
            this.tabPage4.Controls.Add(this.trackBar1);
            this.tabPage4.Controls.Add(this.label6);
            this.tabPage4.Controls.Add(this.label5);
            this.tabPage4.Controls.Add(this.button7);
            this.tabPage4.Controls.Add(this.checkBox9);
            this.tabPage4.Controls.Add(this.button6);
            this.tabPage4.Controls.Add(this.checkBox8);
            this.tabPage4.Controls.Add(this.checkBox7);
            this.tabPage4.Controls.Add(this.button5);
            this.tabPage4.Controls.Add(this.label4);
            this.tabPage4.Controls.Add(this.button4);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(209, 289);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "REF";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // trackBar3
            // 
            this.trackBar3.Location = new System.Drawing.Point(147, 22);
            this.trackBar3.Maximum = 0;
            this.trackBar3.Minimum = -126;
            this.trackBar3.Name = "trackBar3";
            this.trackBar3.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar3.Size = new System.Drawing.Size(45, 128);
            this.trackBar3.TabIndex = 39;
            this.trackBar3.TickFrequency = 16;
            this.trackBar3.Value = -64;
            // 
            // trackBar2
            // 
            this.trackBar2.Location = new System.Drawing.Point(80, 22);
            this.trackBar2.Maximum = 0;
            this.trackBar2.Minimum = -126;
            this.trackBar2.Name = "trackBar2";
            this.trackBar2.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar2.Size = new System.Drawing.Size(45, 128);
            this.trackBar2.TabIndex = 38;
            this.trackBar2.TickFrequency = 16;
            this.trackBar2.Value = -64;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(7, 8);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(44, 13);
            this.label42.TabIndex = 37;
            this.label42.Text = "Position";
            // 
            // trackBar1
            // 
            this.trackBar1.Location = new System.Drawing.Point(16, 22);
            this.trackBar1.Maximum = 0;
            this.trackBar1.Minimum = -126;
            this.trackBar1.Name = "trackBar1";
            this.trackBar1.Orientation = System.Windows.Forms.Orientation.Vertical;
            this.trackBar1.Size = new System.Drawing.Size(45, 128);
            this.trackBar1.TabIndex = 15;
            this.trackBar1.TickFrequency = 16;
            this.trackBar1.Value = -64;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(161, 180);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(31, 13);
            this.label6.TabIndex = 14;
            this.label6.Text = "Color";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(96, 180);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(31, 13);
            this.label5.TabIndex = 13;
            this.label5.Text = "Color";
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.Color.Navy;
            this.button7.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button7.Location = new System.Drawing.Point(147, 180);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(14, 13);
            this.button7.TabIndex = 12;
            this.button7.UseVisualStyleBackColor = false;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(147, 156);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(52, 17);
            this.checkBox9.TabIndex = 11;
            this.checkBox9.Text = "Logic";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.Color.Maroon;
            this.button6.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button6.Location = new System.Drawing.Point(80, 179);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(14, 14);
            this.button6.TabIndex = 10;
            this.button6.UseVisualStyleBackColor = false;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(80, 155);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(47, 17);
            this.checkBox8.TabIndex = 9;
            this.checkBox8.Text = "CH2";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(16, 155);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(47, 17);
            this.checkBox7.TabIndex = 8;
            this.checkBox7.Text = "CH1";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(53, 231);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(108, 22);
            this.button5.TabIndex = 7;
            this.button5.Text = "Capture";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(32, 180);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Color";
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.Green;
            this.button4.ForeColor = System.Drawing.SystemColors.ControlText;
            this.button4.Location = new System.Drawing.Point(16, 179);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(14, 14);
            this.button4.TabIndex = 5;
            this.button4.UseVisualStyleBackColor = false;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(103, 105);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(83, 21);
            this.checkBox2.TabIndex = 11;
            this.checkBox2.Text = "Average";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(6, 105);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(65, 21);
            this.checkBox1.TabIndex = 10;
            this.checkBox1.Text = "Invert";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label41);
            this.groupBox3.Controls.Add(this.numericUpTTimeout);
            this.groupBox3.Controls.Add(this.label8);
            this.groupBox3.Controls.Add(this.label67);
            this.groupBox3.Controls.Add(this.numericUpDownTHold);
            this.groupBox3.Controls.Add(this.label36);
            this.groupBox3.Controls.Add(this.groupBox10);
            this.groupBox3.Controls.Add(this.buttonForce);
            this.groupBox3.Controls.Add(this.groupBox5);
            this.groupBox3.Controls.Add(this.groupBox4);
            this.groupBox3.Location = new System.Drawing.Point(240, 156);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(160, 345);
            this.groupBox3.TabIndex = 20;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Trigger";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(129, 289);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(22, 13);
            this.label41.TabIndex = 35;
            this.label41.Text = "mS";
            // 
            // numericUpTTimeout
            // 
            this.numericUpTTimeout.DecimalPlaces = 3;
            this.numericUpTTimeout.Increment = new decimal(new int[] {
            4096,
            0,
            0,
            131072});
            this.numericUpTTimeout.Location = new System.Drawing.Point(47, 285);
            this.numericUpTTimeout.Maximum = new decimal(new int[] {
            1048576,
            0,
            0,
            131072});
            this.numericUpTTimeout.Minimum = new decimal(new int[] {
            4096,
            0,
            0,
            131072});
            this.numericUpTTimeout.Name = "numericUpTTimeout";
            this.numericUpTTimeout.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.numericUpTTimeout.Size = new System.Drawing.Size(75, 20);
            this.numericUpTTimeout.TabIndex = 35;
            this.numericUpTTimeout.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpTTimeout, "Trigger Timeout: Delay before generating an automatic trigger, when the trigger T" +
        "ype is set to Auto.");
            this.numericUpTTimeout.Value = new decimal(new int[] {
            1024,
            0,
            0,
            0});
            this.numericUpTTimeout.ValueChanged += new System.EventHandler(this.numericUpTTimeout_ValueChanged);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 289);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(29, 13);
            this.label8.TabIndex = 35;
            this.label8.Text = "Auto";
            this.toolTip1.SetToolTip(this.label8, "Trigger Timeout: Delay before generating an automatic trigger, when the trigger T" +
        "ype is set to Auto.");
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(129, 318);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(22, 13);
            this.label67.TabIndex = 22;
            this.label67.Text = "mS";
            // 
            // numericUpDownTHold
            // 
            this.numericUpDownTHold.Location = new System.Drawing.Point(47, 314);
            this.numericUpDownTHold.Maximum = new decimal(new int[] {
            255,
            0,
            0,
            0});
            this.numericUpDownTHold.Name = "numericUpDownTHold";
            this.numericUpDownTHold.Size = new System.Drawing.Size(75, 20);
            this.numericUpDownTHold.TabIndex = 21;
            this.numericUpDownTHold.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.toolTip1.SetToolTip(this.numericUpDownTHold, "Time to wait before detecting the next trigger.");
            this.numericUpDownTHold.ValueChanged += new System.EventHandler(this.numericUpDownTHold_ValueChanged);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(12, 318);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(29, 13);
            this.label36.TabIndex = 5;
            this.label36.Text = "Hold";
            this.toolTip1.SetToolTip(this.label36, "Time to wait before detecting the next trigger.");
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.pictureBox24);
            this.groupBox10.Controls.Add(this.radioDual);
            this.groupBox10.Controls.Add(this.pictureBox23);
            this.groupBox10.Controls.Add(this.radioWindow);
            this.groupBox10.Controls.Add(this.pictureBox12);
            this.groupBox10.Controls.Add(this.pictureBox4);
            this.groupBox10.Controls.Add(this.radioNegative);
            this.groupBox10.Controls.Add(this.radioPositive);
            this.groupBox10.Controls.Add(this.pictureBox11);
            this.groupBox10.Controls.Add(this.pictureBox10);
            this.groupBox10.Controls.Add(this.radioFalling);
            this.groupBox10.Controls.Add(this.radioRising);
            this.groupBox10.Location = new System.Drawing.Point(11, 71);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(140, 140);
            this.groupBox10.TabIndex = 3;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Mode";
            // 
            // pictureBox24
            // 
            this.pictureBox24.Image = global::Xprotolab_interface.Properties.Resources.dual;
            this.pictureBox24.Location = new System.Drawing.Point(11, 58);
            this.pictureBox24.Name = "pictureBox24";
            this.pictureBox24.Size = new System.Drawing.Size(18, 15);
            this.pictureBox24.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox24.TabIndex = 38;
            this.pictureBox24.TabStop = false;
            // 
            // radioDual
            // 
            this.radioDual.AutoSize = true;
            this.radioDual.Location = new System.Drawing.Point(38, 57);
            this.radioDual.Name = "radioDual";
            this.radioDual.Size = new System.Drawing.Size(75, 17);
            this.radioDual.TabIndex = 37;
            this.radioDual.TabStop = true;
            this.radioDual.Text = "Dual Edge";
            this.toolTip1.SetToolTip(this.radioDual, "The trigger occurs when the signal crosses the trigger level in any direction.");
            this.radioDual.UseVisualStyleBackColor = true;
            this.radioDual.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioDual_MouseClick);
            // 
            // pictureBox23
            // 
            this.pictureBox23.Image = global::Xprotolab_interface.Properties.Resources.window;
            this.pictureBox23.Location = new System.Drawing.Point(11, 118);
            this.pictureBox23.Name = "pictureBox23";
            this.pictureBox23.Size = new System.Drawing.Size(18, 14);
            this.pictureBox23.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox23.TabIndex = 36;
            this.pictureBox23.TabStop = false;
            // 
            // radioWindow
            // 
            this.radioWindow.AutoSize = true;
            this.radioWindow.Location = new System.Drawing.Point(38, 117);
            this.radioWindow.Name = "radioWindow";
            this.radioWindow.Size = new System.Drawing.Size(64, 17);
            this.radioWindow.TabIndex = 35;
            this.radioWindow.TabStop = true;
            this.radioWindow.Text = "Window";
            this.toolTip1.SetToolTip(this.radioWindow, "The trigger occurs when the signal leaves a voltage range.");
            this.radioWindow.UseVisualStyleBackColor = true;
            this.radioWindow.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioWindow_MouseClick);
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = global::Xprotolab_interface.Properties.Resources.positive;
            this.pictureBox12.Location = new System.Drawing.Point(11, 78);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(18, 14);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox12.TabIndex = 11;
            this.pictureBox12.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Xprotolab_interface.Properties.Resources.negative;
            this.pictureBox4.Location = new System.Drawing.Point(11, 98);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(18, 14);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox4.TabIndex = 10;
            this.pictureBox4.TabStop = false;
            // 
            // radioNegative
            // 
            this.radioNegative.AutoSize = true;
            this.radioNegative.Location = new System.Drawing.Point(38, 97);
            this.radioNegative.Name = "radioNegative";
            this.radioNegative.Size = new System.Drawing.Size(98, 17);
            this.radioNegative.TabIndex = 0;
            this.radioNegative.TabStop = true;
            this.radioNegative.Text = "Negative Slope";
            this.toolTip1.SetToolTip(this.radioNegative, "The trigger occurs when the difference between two consecutive samples is greater" +
        " than the trigger value, negative slope.");
            this.radioNegative.UseVisualStyleBackColor = true;
            this.radioNegative.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioNegative_MouseClick);
            // 
            // radioPositive
            // 
            this.radioPositive.AutoSize = true;
            this.radioPositive.Location = new System.Drawing.Point(38, 77);
            this.radioPositive.Name = "radioPositive";
            this.radioPositive.Size = new System.Drawing.Size(92, 17);
            this.radioPositive.TabIndex = 0;
            this.radioPositive.TabStop = true;
            this.radioPositive.Text = "Positive Slope";
            this.toolTip1.SetToolTip(this.radioPositive, "The trigger occurs when the difference between two consecutive samples is greater" +
        " than the trigger value, positive slope.");
            this.radioPositive.UseVisualStyleBackColor = true;
            this.radioPositive.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioPositive_MouseClick);
            // 
            // pictureBox11
            // 
            this.pictureBox11.Image = global::Xprotolab_interface.Properties.Resources.falling;
            this.pictureBox11.Location = new System.Drawing.Point(11, 38);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(18, 14);
            this.pictureBox11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox11.TabIndex = 7;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox10
            // 
            this.pictureBox10.Image = global::Xprotolab_interface.Properties.Resources.rising;
            this.pictureBox10.Location = new System.Drawing.Point(11, 18);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(18, 14);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox10.TabIndex = 6;
            this.pictureBox10.TabStop = false;
            // 
            // radioFalling
            // 
            this.radioFalling.AutoSize = true;
            this.radioFalling.Location = new System.Drawing.Point(38, 37);
            this.radioFalling.Name = "radioFalling";
            this.radioFalling.Size = new System.Drawing.Size(83, 17);
            this.radioFalling.TabIndex = 1;
            this.radioFalling.TabStop = true;
            this.radioFalling.Text = "Falling Edge";
            this.toolTip1.SetToolTip(this.radioFalling, "The trigger occurs when the signal crosses the trigger level from above to below." +
        "");
            this.radioFalling.UseVisualStyleBackColor = true;
            this.radioFalling.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioFalling_MouseClick);
            // 
            // radioRising
            // 
            this.radioRising.AutoSize = true;
            this.radioRising.Location = new System.Drawing.Point(38, 17);
            this.radioRising.Name = "radioRising";
            this.radioRising.Size = new System.Drawing.Size(82, 17);
            this.radioRising.TabIndex = 0;
            this.radioRising.TabStop = true;
            this.radioRising.Text = "Rising Edge";
            this.toolTip1.SetToolTip(this.radioRising, "The trigger occurs when the signal crosses the trigger level from below to above." +
        "");
            this.radioRising.UseVisualStyleBackColor = true;
            this.radioRising.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioRising_MouseClick);
            // 
            // buttonForce
            // 
            this.buttonForce.Location = new System.Drawing.Point(107, 19);
            this.buttonForce.Name = "buttonForce";
            this.buttonForce.Size = new System.Drawing.Size(44, 49);
            this.buttonForce.TabIndex = 2;
            this.buttonForce.Text = "Force";
            this.toolTip1.SetToolTip(this.buttonForce, "Forces the trigger.");
            this.buttonForce.UseVisualStyleBackColor = true;
            this.buttonForce.Click += new System.EventHandler(this.buttonForce_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.radioTrigSingle);
            this.groupBox5.Controls.Add(this.radioTrigAuto);
            this.groupBox5.Controls.Add(this.radioTrigNormal);
            this.groupBox5.Controls.Add(this.radioTrigFree);
            this.groupBox5.Location = new System.Drawing.Point(11, 215);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(140, 61);
            this.groupBox5.TabIndex = 1;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Type";
            // 
            // radioTrigSingle
            // 
            this.radioTrigSingle.AutoSize = true;
            this.radioTrigSingle.Location = new System.Drawing.Point(73, 36);
            this.radioTrigSingle.Name = "radioTrigSingle";
            this.radioTrigSingle.Size = new System.Drawing.Size(54, 17);
            this.radioTrigSingle.TabIndex = 3;
            this.radioTrigSingle.TabStop = true;
            this.radioTrigSingle.Text = "Single";
            this.toolTip1.SetToolTip(this.radioTrigSingle, "Only one trace is displayed when the trigger event occurs.");
            this.radioTrigSingle.UseVisualStyleBackColor = true;
            this.radioTrigSingle.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioTrigSingle_MouseClick);
            // 
            // radioTrigAuto
            // 
            this.radioTrigAuto.AutoSize = true;
            this.radioTrigAuto.Location = new System.Drawing.Point(11, 36);
            this.radioTrigAuto.Name = "radioTrigAuto";
            this.radioTrigAuto.Size = new System.Drawing.Size(47, 17);
            this.radioTrigAuto.TabIndex = 2;
            this.radioTrigAuto.TabStop = true;
            this.radioTrigAuto.Text = "Auto";
            this.toolTip1.SetToolTip(this.radioTrigAuto, "Trace when the trigger event occurs, or after the Auto trigger timeout.");
            this.radioTrigAuto.UseVisualStyleBackColor = true;
            this.radioTrigAuto.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioTrigAuto_MouseClick);
            // 
            // radioTrigNormal
            // 
            this.radioTrigNormal.AutoSize = true;
            this.radioTrigNormal.Location = new System.Drawing.Point(73, 16);
            this.radioTrigNormal.Name = "radioTrigNormal";
            this.radioTrigNormal.Size = new System.Drawing.Size(58, 17);
            this.radioTrigNormal.TabIndex = 1;
            this.radioTrigNormal.TabStop = true;
            this.radioTrigNormal.Text = "Normal";
            this.toolTip1.SetToolTip(this.radioTrigNormal, "Trace only when the trigger event occurs.");
            this.radioTrigNormal.UseVisualStyleBackColor = true;
            this.radioTrigNormal.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioTrigNormal_MouseClick);
            // 
            // radioTrigFree
            // 
            this.radioTrigFree.AutoSize = true;
            this.radioTrigFree.Location = new System.Drawing.Point(11, 16);
            this.radioTrigFree.Name = "radioTrigFree";
            this.radioTrigFree.Size = new System.Drawing.Size(46, 17);
            this.radioTrigFree.TabIndex = 0;
            this.radioTrigFree.TabStop = true;
            this.radioTrigFree.Text = "Free";
            this.toolTip1.SetToolTip(this.radioTrigFree, "Trace continuously ignoring the trigger.");
            this.radioTrigFree.UseVisualStyleBackColor = true;
            this.radioTrigFree.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioTrigFree_MouseClick);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.comboBoxTSource);
            this.groupBox4.Location = new System.Drawing.Point(11, 14);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(85, 54);
            this.groupBox4.TabIndex = 0;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Source";
            // 
            // comboBoxTSource
            // 
            this.comboBoxTSource.DropDownHeight = 256;
            this.comboBoxTSource.FormattingEnabled = true;
            this.comboBoxTSource.IntegralHeight = false;
            this.comboBoxTSource.Items.AddRange(new object[] {
            "CH1",
            "CH2",
            "Bit 0",
            "Bit 1",
            "Bit 2",
            "Bit 3",
            "Bit 4",
            "Bit 5",
            "Bit 6",
            "Bit 7",
            "EXT"});
            this.comboBoxTSource.Location = new System.Drawing.Point(12, 19);
            this.comboBoxTSource.Name = "comboBoxTSource";
            this.comboBoxTSource.Size = new System.Drawing.Size(60, 21);
            this.comboBoxTSource.TabIndex = 4;
            this.comboBoxTSource.SelectedIndexChanged += new System.EventHandler(this.comboBoxTSource_SelectedIndexChanged);
            // 
            // tabControl2
            // 
            this.tabControl2.Controls.Add(this.tabPage5);
            this.tabControl2.Controls.Add(this.tabPage6);
            this.tabControl2.Controls.Add(this.tabPage7);
            this.tabControl2.Controls.Add(this.tabPage8);
            this.tabControl2.Controls.Add(this.tabPage13);
            this.tabControl2.Dock = System.Windows.Forms.DockStyle.Right;
            this.tabControl2.Location = new System.Drawing.Point(522, 0);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.Padding = new System.Drawing.Point(5, 3);
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(412, 568);
            this.tabControl2.TabIndex = 23;
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.checkBoxStop);
            this.tabPage5.Controls.Add(this.groupBox1);
            this.tabPage5.Controls.Add(this.groupBox3);
            this.tabPage5.Controls.Add(this.groupBox2);
            this.tabPage5.Controls.Add(this.button13);
            this.tabPage5.Controls.Add(this.button14);
            this.tabPage5.Controls.Add(this.StorageButton);
            this.tabPage5.Controls.Add(this.button_auto);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(404, 542);
            this.tabPage5.TabIndex = 0;
            this.tabPage5.Text = " Oscilloscope ";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // checkBoxStop
            // 
            this.checkBoxStop.Appearance = System.Windows.Forms.Appearance.Button;
            this.checkBoxStop.CheckAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBoxStop.Enabled = false;
            this.checkBoxStop.Location = new System.Drawing.Point(346, 507);
            this.checkBoxStop.Name = "checkBoxStop";
            this.checkBoxStop.Size = new System.Drawing.Size(50, 25);
            this.checkBoxStop.TabIndex = 35;
            this.checkBoxStop.Text = "STOP";
            this.checkBoxStop.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.checkBoxStop.UseVisualStyleBackColor = true;
            this.checkBoxStop.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxStop_MouseClick);
            // 
            // button13
            // 
            this.button13.Enabled = false;
            this.button13.Location = new System.Drawing.Point(72, 507);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(50, 25);
            this.button13.TabIndex = 25;
            this.button13.Text = "Record";
            // 
            // button14
            // 
            this.button14.Enabled = false;
            this.button14.Location = new System.Drawing.Point(128, 507);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(50, 25);
            this.button14.TabIndex = 26;
            this.button14.Text = "Play";
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.richTextBox1);
            this.tabPage6.Controls.Add(this.groupBox18);
            this.tabPage6.Controls.Add(this.labelHz);
            this.tabPage6.Controls.Add(this.groupBox12);
            this.tabPage6.Controls.Add(this.numericUpDownOffset);
            this.tabPage6.Controls.Add(this.textBoxF);
            this.tabPage6.Controls.Add(this.numericUpDownDuty);
            this.tabPage6.Controls.Add(this.numericUpDownFreq);
            this.tabPage6.Controls.Add(this.label68);
            this.tabPage6.Controls.Add(this.numericUpDownAmp);
            this.tabPage6.Controls.Add(this.label40);
            this.tabPage6.Controls.Add(this.trackBarOffset);
            this.tabPage6.Controls.Add(this.trackBarDuty);
            this.tabPage6.Controls.Add(this.trackBarFreq);
            this.tabPage6.Controls.Add(this.trackBarAmp);
            this.tabPage6.Controls.Add(this.groupBox9);
            this.tabPage6.Controls.Add(this.label11);
            this.tabPage6.Controls.Add(this.label10);
            this.tabPage6.Controls.Add(this.label9);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(404, 542);
            this.tabPage6.TabIndex = 1;
            this.tabPage6.Text = " Arbitrary Waveform Generator ";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(267, 5);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(128, 128);
            this.richTextBox1.TabIndex = 0;
            this.richTextBox1.Text = resources.GetString("richTextBox1.Text");
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.checkBoxDirection);
            this.groupBox18.Controls.Add(this.label72);
            this.groupBox18.Controls.Add(this.labelUnit2);
            this.groupBox18.Controls.Add(this.textBoxSWSpeed);
            this.groupBox18.Controls.Add(this.labelUnit1);
            this.groupBox18.Controls.Add(this.trackBarSWSpeed);
            this.groupBox18.Controls.Add(this.label69);
            this.groupBox18.Controls.Add(this.textBoxSW1);
            this.groupBox18.Controls.Add(this.label70);
            this.groupBox18.Controls.Add(this.trackBarSW2);
            this.groupBox18.Controls.Add(this.trackBarSW1);
            this.groupBox18.Controls.Add(this.checkBoxAccelDir);
            this.groupBox18.Controls.Add(this.textBoxSW2);
            this.groupBox18.Controls.Add(this.checkBoxAccel);
            this.groupBox18.Controls.Add(this.checkBoxSweepF);
            this.groupBox18.Controls.Add(this.checkBoxPingPong);
            this.groupBox18.Controls.Add(this.checkBoxSweepA);
            this.groupBox18.Controls.Add(this.checkBoxSweepO);
            this.groupBox18.Controls.Add(this.checkBoxSweepD);
            this.groupBox18.Location = new System.Drawing.Point(13, 361);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(383, 173);
            this.groupBox18.TabIndex = 30;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Sweep";
            // 
            // checkBoxDirection
            // 
            this.checkBoxDirection.AutoSize = true;
            this.checkBoxDirection.Location = new System.Drawing.Point(10, 67);
            this.checkBoxDirection.Name = "checkBoxDirection";
            this.checkBoxDirection.Size = new System.Drawing.Size(68, 17);
            this.checkBoxDirection.TabIndex = 37;
            this.checkBoxDirection.Text = "Direction";
            this.checkBoxDirection.UseVisualStyleBackColor = true;
            this.checkBoxDirection.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxDirection_MouseClick);
            // 
            // label72
            // 
            this.label72.AutoSize = true;
            this.label72.Location = new System.Drawing.Point(16, 112);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(38, 13);
            this.label72.TabIndex = 45;
            this.label72.Text = "Speed";
            // 
            // labelUnit2
            // 
            this.labelUnit2.AutoSize = true;
            this.labelUnit2.Location = new System.Drawing.Point(220, 142);
            this.labelUnit2.Name = "labelUnit2";
            this.labelUnit2.Size = new System.Drawing.Size(20, 13);
            this.labelUnit2.TabIndex = 43;
            this.labelUnit2.Text = "Hz";
            // 
            // textBoxSWSpeed
            // 
            this.textBoxSWSpeed.Location = new System.Drawing.Point(67, 109);
            this.textBoxSWSpeed.Name = "textBoxSWSpeed";
            this.textBoxSWSpeed.ReadOnly = true;
            this.textBoxSWSpeed.Size = new System.Drawing.Size(61, 20);
            this.textBoxSWSpeed.TabIndex = 44;
            // 
            // labelUnit1
            // 
            this.labelUnit1.AutoSize = true;
            this.labelUnit1.Location = new System.Drawing.Point(220, 112);
            this.labelUnit1.Name = "labelUnit1";
            this.labelUnit1.Size = new System.Drawing.Size(20, 13);
            this.labelUnit1.TabIndex = 42;
            this.labelUnit1.Text = "Hz";
            // 
            // trackBarSWSpeed
            // 
            this.trackBarSWSpeed.AutoSize = false;
            this.trackBarSWSpeed.Location = new System.Drawing.Point(5, 134);
            this.trackBarSWSpeed.Maximum = 127;
            this.trackBarSWSpeed.Minimum = 1;
            this.trackBarSWSpeed.Name = "trackBarSWSpeed";
            this.trackBarSWSpeed.Size = new System.Drawing.Size(128, 24);
            this.trackBarSWSpeed.TabIndex = 43;
            this.trackBarSWSpeed.TickFrequency = 16;
            this.trackBarSWSpeed.Value = 64;
            this.trackBarSWSpeed.Scroll += new System.EventHandler(this.trackBarSWSpeed_Scroll);
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(139, 112);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(16, 13);
            this.label69.TabIndex = 39;
            this.label69.Text = "1:";
            // 
            // textBoxSW1
            // 
            this.textBoxSW1.Location = new System.Drawing.Point(156, 109);
            this.textBoxSW1.Name = "textBoxSW1";
            this.textBoxSW1.ReadOnly = true;
            this.textBoxSW1.Size = new System.Drawing.Size(61, 20);
            this.textBoxSW1.TabIndex = 38;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(139, 141);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(16, 13);
            this.label70.TabIndex = 41;
            this.label70.Text = "2:";
            // 
            // trackBarSW2
            // 
            this.trackBarSW2.AutoSize = false;
            this.trackBarSW2.Location = new System.Drawing.Point(245, 135);
            this.trackBarSW2.Maximum = 255;
            this.trackBarSW2.Name = "trackBarSW2";
            this.trackBarSW2.Size = new System.Drawing.Size(128, 24);
            this.trackBarSW2.TabIndex = 36;
            this.trackBarSW2.TickFrequency = 16;
            this.trackBarSW2.Value = 64;
            this.trackBarSW2.Scroll += new System.EventHandler(this.trackBarSW2_Scroll);
            // 
            // trackBarSW1
            // 
            this.trackBarSW1.AutoSize = false;
            this.trackBarSW1.Location = new System.Drawing.Point(245, 105);
            this.trackBarSW1.Maximum = 255;
            this.trackBarSW1.Name = "trackBarSW1";
            this.trackBarSW1.Size = new System.Drawing.Size(128, 24);
            this.trackBarSW1.TabIndex = 35;
            this.trackBarSW1.TickFrequency = 16;
            this.trackBarSW1.Value = 64;
            this.trackBarSW1.Scroll += new System.EventHandler(this.trackBarSW1_Scroll);
            // 
            // checkBoxAccelDir
            // 
            this.checkBoxAccelDir.AutoSize = true;
            this.checkBoxAccelDir.Location = new System.Drawing.Point(278, 67);
            this.checkBoxAccelDir.Name = "checkBoxAccelDir";
            this.checkBoxAccelDir.Size = new System.Drawing.Size(99, 17);
            this.checkBoxAccelDir.TabIndex = 37;
            this.checkBoxAccelDir.Text = "Accel. direction";
            this.checkBoxAccelDir.UseVisualStyleBackColor = true;
            this.checkBoxAccelDir.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxAccelDir_MouseClick);
            // 
            // textBoxSW2
            // 
            this.textBoxSW2.Location = new System.Drawing.Point(156, 136);
            this.textBoxSW2.Name = "textBoxSW2";
            this.textBoxSW2.ReadOnly = true;
            this.textBoxSW2.Size = new System.Drawing.Size(61, 20);
            this.textBoxSW2.TabIndex = 40;
            // 
            // checkBoxAccel
            // 
            this.checkBoxAccel.AutoSize = true;
            this.checkBoxAccel.Location = new System.Drawing.Point(195, 67);
            this.checkBoxAccel.Name = "checkBoxAccel";
            this.checkBoxAccel.Size = new System.Drawing.Size(77, 17);
            this.checkBoxAccel.TabIndex = 36;
            this.checkBoxAccel.Text = "Accelerate";
            this.checkBoxAccel.UseVisualStyleBackColor = true;
            this.checkBoxAccel.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxAccel_MouseClick);
            // 
            // checkBoxSweepF
            // 
            this.checkBoxSweepF.AutoSize = true;
            this.checkBoxSweepF.Location = new System.Drawing.Point(10, 22);
            this.checkBoxSweepF.Name = "checkBoxSweepF";
            this.checkBoxSweepF.Size = new System.Drawing.Size(76, 17);
            this.checkBoxSweepF.TabIndex = 0;
            this.checkBoxSweepF.Text = "Frequency";
            this.checkBoxSweepF.UseVisualStyleBackColor = true;
            this.checkBoxSweepF.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxSweepF_MouseClick);
            // 
            // checkBoxPingPong
            // 
            this.checkBoxPingPong.AutoSize = true;
            this.checkBoxPingPong.Location = new System.Drawing.Point(102, 67);
            this.checkBoxPingPong.Name = "checkBoxPingPong";
            this.checkBoxPingPong.Size = new System.Drawing.Size(75, 17);
            this.checkBoxPingPong.TabIndex = 35;
            this.checkBoxPingPong.Text = "Ping Pong";
            this.checkBoxPingPong.UseVisualStyleBackColor = true;
            this.checkBoxPingPong.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxPingPong_MouseClick);
            // 
            // checkBoxSweepA
            // 
            this.checkBoxSweepA.AutoSize = true;
            this.checkBoxSweepA.Location = new System.Drawing.Point(102, 22);
            this.checkBoxSweepA.Name = "checkBoxSweepA";
            this.checkBoxSweepA.Size = new System.Drawing.Size(72, 17);
            this.checkBoxSweepA.TabIndex = 30;
            this.checkBoxSweepA.Text = "Amplitude";
            this.checkBoxSweepA.UseVisualStyleBackColor = true;
            this.checkBoxSweepA.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxSweepA_MouseClick);
            // 
            // checkBoxSweepO
            // 
            this.checkBoxSweepO.AutoSize = true;
            this.checkBoxSweepO.Location = new System.Drawing.Point(278, 22);
            this.checkBoxSweepO.Name = "checkBoxSweepO";
            this.checkBoxSweepO.Size = new System.Drawing.Size(54, 17);
            this.checkBoxSweepO.TabIndex = 32;
            this.checkBoxSweepO.Text = "Offset";
            this.checkBoxSweepO.UseVisualStyleBackColor = true;
            this.checkBoxSweepO.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxSweepO_MouseClick);
            // 
            // checkBoxSweepD
            // 
            this.checkBoxSweepD.AutoSize = true;
            this.checkBoxSweepD.Location = new System.Drawing.Point(195, 22);
            this.checkBoxSweepD.Name = "checkBoxSweepD";
            this.checkBoxSweepD.Size = new System.Drawing.Size(77, 17);
            this.checkBoxSweepD.TabIndex = 31;
            this.checkBoxSweepD.Text = "Duty Cycle";
            this.checkBoxSweepD.UseVisualStyleBackColor = true;
            this.checkBoxSweepD.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxSweepD_MouseClick);
            // 
            // labelHz
            // 
            this.labelHz.AutoSize = true;
            this.labelHz.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelHz.Location = new System.Drawing.Point(323, 222);
            this.labelHz.Name = "labelHz";
            this.labelHz.Size = new System.Drawing.Size(75, 37);
            this.labelHz.TabIndex = 28;
            this.labelHz.Text = "kHz";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.radioButton100K);
            this.groupBox12.Controls.Add(this.radioButton10K);
            this.groupBox12.Controls.Add(this.radioButton1K);
            this.groupBox12.Controls.Add(this.radioButton100);
            this.groupBox12.Controls.Add(this.radioButton10);
            this.groupBox12.Location = new System.Drawing.Point(13, 139);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(383, 44);
            this.groupBox12.TabIndex = 24;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Frequency Range";
            // 
            // radioButton100K
            // 
            this.radioButton100K.AutoSize = true;
            this.radioButton100K.Location = new System.Drawing.Point(316, 19);
            this.radioButton100K.Name = "radioButton100K";
            this.radioButton100K.Size = new System.Drawing.Size(50, 17);
            this.radioButton100K.TabIndex = 4;
            this.radioButton100K.Text = "100K";
            this.radioButton100K.UseVisualStyleBackColor = true;
            this.radioButton100K.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButton200K_MouseClick);
            // 
            // radioButton10K
            // 
            this.radioButton10K.AutoSize = true;
            this.radioButton10K.Location = new System.Drawing.Point(236, 19);
            this.radioButton10K.Name = "radioButton10K";
            this.radioButton10K.Size = new System.Drawing.Size(44, 17);
            this.radioButton10K.TabIndex = 3;
            this.radioButton10K.Text = "10K";
            this.radioButton10K.UseVisualStyleBackColor = true;
            this.radioButton10K.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButton20K_MouseClick);
            // 
            // radioButton1K
            // 
            this.radioButton1K.AutoSize = true;
            this.radioButton1K.Checked = true;
            this.radioButton1K.Location = new System.Drawing.Point(162, 19);
            this.radioButton1K.Name = "radioButton1K";
            this.radioButton1K.Size = new System.Drawing.Size(38, 17);
            this.radioButton1K.TabIndex = 2;
            this.radioButton1K.TabStop = true;
            this.radioButton1K.Text = "1K";
            this.radioButton1K.UseVisualStyleBackColor = true;
            this.radioButton1K.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButton2K_MouseClick);
            // 
            // radioButton100
            // 
            this.radioButton100.AutoSize = true;
            this.radioButton100.Location = new System.Drawing.Point(83, 19);
            this.radioButton100.Name = "radioButton100";
            this.radioButton100.Size = new System.Drawing.Size(43, 17);
            this.radioButton100.TabIndex = 1;
            this.radioButton100.Text = "100";
            this.radioButton100.UseVisualStyleBackColor = true;
            this.radioButton100.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButton200_MouseClick);
            // 
            // radioButton10
            // 
            this.radioButton10.AutoSize = true;
            this.radioButton10.Location = new System.Drawing.Point(10, 19);
            this.radioButton10.Name = "radioButton10";
            this.radioButton10.Size = new System.Drawing.Size(37, 17);
            this.radioButton10.TabIndex = 0;
            this.radioButton10.Text = "10";
            this.radioButton10.UseVisualStyleBackColor = true;
            this.radioButton10.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButton20_MouseClick);
            // 
            // numericUpDownOffset
            // 
            this.numericUpDownOffset.DecimalPlaces = 3;
            this.numericUpDownOffset.Increment = new decimal(new int[] {
            16,
            0,
            0,
            196608});
            this.numericUpDownOffset.Location = new System.Drawing.Point(61, 335);
            this.numericUpDownOffset.Maximum = new decimal(new int[] {
            200064,
            0,
            0,
            327680});
            this.numericUpDownOffset.Minimum = new decimal(new int[] {
            198501,
            0,
            0,
            -2147155968});
            this.numericUpDownOffset.Name = "numericUpDownOffset";
            this.numericUpDownOffset.Size = new System.Drawing.Size(56, 20);
            this.numericUpDownOffset.TabIndex = 22;
            this.numericUpDownOffset.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDownOffset.ValueChanged += new System.EventHandler(this.numericUpDownOffset_ValueChanged);
            // 
            // textBoxF
            // 
            this.textBoxF.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxF.Location = new System.Drawing.Point(183, 219);
            this.textBoxF.Name = "textBoxF";
            this.textBoxF.ReadOnly = true;
            this.textBoxF.Size = new System.Drawing.Size(140, 44);
            this.textBoxF.TabIndex = 27;
            this.textBoxF.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // numericUpDownDuty
            // 
            this.numericUpDownDuty.DecimalPlaces = 3;
            this.numericUpDownDuty.Increment = new decimal(new int[] {
            4,
            0,
            0,
            65536});
            this.numericUpDownDuty.Location = new System.Drawing.Point(61, 305);
            this.numericUpDownDuty.Maximum = new decimal(new int[] {
            9961065,
            0,
            0,
            327680});
            this.numericUpDownDuty.Minimum = new decimal(new int[] {
            39063,
            0,
            0,
            327680});
            this.numericUpDownDuty.Name = "numericUpDownDuty";
            this.numericUpDownDuty.Size = new System.Drawing.Size(56, 20);
            this.numericUpDownDuty.TabIndex = 21;
            this.numericUpDownDuty.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDownDuty.Value = new decimal(new int[] {
            50,
            0,
            0,
            0});
            this.numericUpDownDuty.ValueChanged += new System.EventHandler(this.numericUpDownDuty_ValueChanged);
            // 
            // numericUpDownFreq
            // 
            this.numericUpDownFreq.DecimalPlaces = 2;
            this.numericUpDownFreq.Location = new System.Drawing.Point(37, 245);
            this.numericUpDownFreq.Maximum = new decimal(new int[] {
            200000,
            0,
            0,
            0});
            this.numericUpDownFreq.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.numericUpDownFreq.Name = "numericUpDownFreq";
            this.numericUpDownFreq.Size = new System.Drawing.Size(79, 20);
            this.numericUpDownFreq.TabIndex = 20;
            this.numericUpDownFreq.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDownFreq.Value = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.numericUpDownFreq.ValueChanged += new System.EventHandler(this.numericUpDownFreq_ValueChanged);
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(122, 227);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(57, 26);
            this.label68.TabIndex = 26;
            this.label68.Text = "   Actual\r\nFrequency";
            // 
            // numericUpDownAmp
            // 
            this.numericUpDownAmp.DecimalPlaces = 3;
            this.numericUpDownAmp.Increment = new decimal(new int[] {
            3125,
            0,
            0,
            327680});
            this.numericUpDownAmp.Location = new System.Drawing.Point(61, 275);
            this.numericUpDownAmp.Maximum = new decimal(new int[] {
            4,
            0,
            0,
            0});
            this.numericUpDownAmp.Name = "numericUpDownAmp";
            this.numericUpDownAmp.Size = new System.Drawing.Size(55, 20);
            this.numericUpDownAmp.TabIndex = 19;
            this.numericUpDownAmp.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.numericUpDownAmp.ValueChanged += new System.EventHandler(this.numericUpDownAmp_ValueChanged);
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(16, 226);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(96, 13);
            this.label40.TabIndex = 18;
            this.label40.Text = "Desired Frequency";
            // 
            // trackBarOffset
            // 
            this.trackBarOffset.AutoSize = false;
            this.trackBarOffset.LargeChange = 8;
            this.trackBarOffset.Location = new System.Drawing.Point(142, 331);
            this.trackBarOffset.Maximum = 128;
            this.trackBarOffset.Minimum = -127;
            this.trackBarOffset.Name = "trackBarOffset";
            this.trackBarOffset.Size = new System.Drawing.Size(254, 24);
            this.trackBarOffset.TabIndex = 17;
            this.trackBarOffset.TickFrequency = 32;
            this.trackBarOffset.Scroll += new System.EventHandler(this.trackBarOffset_Scroll);
            // 
            // trackBarDuty
            // 
            this.trackBarDuty.AutoSize = false;
            this.trackBarDuty.Location = new System.Drawing.Point(142, 301);
            this.trackBarDuty.Maximum = 255;
            this.trackBarDuty.Minimum = 1;
            this.trackBarDuty.Name = "trackBarDuty";
            this.trackBarDuty.Size = new System.Drawing.Size(254, 24);
            this.trackBarDuty.TabIndex = 16;
            this.trackBarDuty.TickFrequency = 32;
            this.trackBarDuty.Value = 128;
            this.trackBarDuty.Scroll += new System.EventHandler(this.trackBarDuty_Scroll);
            // 
            // trackBarFreq
            // 
            this.trackBarFreq.AutoSize = false;
            this.trackBarFreq.LargeChange = 10;
            this.trackBarFreq.Location = new System.Drawing.Point(13, 189);
            this.trackBarFreq.Maximum = 100;
            this.trackBarFreq.Minimum = 10;
            this.trackBarFreq.Name = "trackBarFreq";
            this.trackBarFreq.Size = new System.Drawing.Size(383, 24);
            this.trackBarFreq.TabIndex = 15;
            this.trackBarFreq.TickFrequency = 10;
            this.trackBarFreq.Value = 10;
            this.trackBarFreq.Scroll += new System.EventHandler(this.trackBarFreq_Scroll);
            // 
            // trackBarAmp
            // 
            this.trackBarAmp.AutoSize = false;
            this.trackBarAmp.Location = new System.Drawing.Point(142, 271);
            this.trackBarAmp.Maximum = 128;
            this.trackBarAmp.Name = "trackBarAmp";
            this.trackBarAmp.Size = new System.Drawing.Size(254, 24);
            this.trackBarAmp.TabIndex = 14;
            this.trackBarAmp.TickFrequency = 16;
            this.trackBarAmp.Value = 64;
            this.trackBarAmp.Scroll += new System.EventHandler(this.trackBarAmp_Scroll);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.buttonSaveAWG);
            this.groupBox9.Controls.Add(this.radioButtonExpo);
            this.groupBox9.Controls.Add(this.pictureBox22);
            this.groupBox9.Controls.Add(this.radioButtonNoise);
            this.groupBox9.Controls.Add(this.buttonOpenCSV);
            this.groupBox9.Controls.Add(this.pictureBox21);
            this.groupBox9.Controls.Add(this.radioButtonCustom);
            this.groupBox9.Controls.Add(this.pictureBox3);
            this.groupBox9.Controls.Add(this.radioButtonTrian);
            this.groupBox9.Controls.Add(this.pictureBox2);
            this.groupBox9.Controls.Add(this.radioButtonSquare);
            this.groupBox9.Controls.Add(this.radioButtonSine);
            this.groupBox9.Controls.Add(this.pictureBox1);
            this.groupBox9.Location = new System.Drawing.Point(13, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(250, 127);
            this.groupBox9.TabIndex = 13;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Waveform";
            // 
            // buttonSaveAWG
            // 
            this.buttonSaveAWG.Location = new System.Drawing.Point(129, 92);
            this.buttonSaveAWG.Name = "buttonSaveAWG";
            this.buttonSaveAWG.Size = new System.Drawing.Size(111, 24);
            this.buttonSaveAWG.TabIndex = 30;
            this.buttonSaveAWG.Text = "Save as Custom";
            this.toolTip1.SetToolTip(this.buttonSaveAWG, "Data currently on the AWG RAM buffer will be saved to the EEPROM Custom wave");
            this.buttonSaveAWG.UseVisualStyleBackColor = true;
            this.buttonSaveAWG.Click += new System.EventHandler(this.buttonSaveAWG_Click);
            // 
            // radioButtonExpo
            // 
            this.radioButtonExpo.AutoSize = true;
            this.radioButtonExpo.Location = new System.Drawing.Point(66, 65);
            this.radioButtonExpo.Name = "radioButtonExpo";
            this.radioButtonExpo.Size = new System.Drawing.Size(14, 13);
            this.radioButtonExpo.TabIndex = 10;
            this.radioButtonExpo.TabStop = true;
            this.radioButtonExpo.UseVisualStyleBackColor = true;
            this.radioButtonExpo.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonExpo_MouseClick);
            // 
            // pictureBox22
            // 
            this.pictureBox22.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox22.Image")));
            this.pictureBox22.Location = new System.Drawing.Point(28, 93);
            this.pictureBox22.Name = "pictureBox22";
            this.pictureBox22.Size = new System.Drawing.Size(32, 32);
            this.pictureBox22.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox22.TabIndex = 9;
            this.pictureBox22.TabStop = false;
            // 
            // radioButtonNoise
            // 
            this.radioButtonNoise.AutoSize = true;
            this.radioButtonNoise.Location = new System.Drawing.Point(10, 101);
            this.radioButtonNoise.Name = "radioButtonNoise";
            this.radioButtonNoise.Size = new System.Drawing.Size(14, 13);
            this.radioButtonNoise.TabIndex = 7;
            this.radioButtonNoise.TabStop = true;
            this.radioButtonNoise.UseVisualStyleBackColor = true;
            this.radioButtonNoise.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonNoise_MouseClick);
            // 
            // buttonOpenCSV
            // 
            this.buttonOpenCSV.Location = new System.Drawing.Point(129, 19);
            this.buttonOpenCSV.Name = "buttonOpenCSV";
            this.buttonOpenCSV.Size = new System.Drawing.Size(111, 24);
            this.buttonOpenCSV.TabIndex = 29;
            this.buttonOpenCSV.Text = "Open CSV";
            this.toolTip1.SetToolTip(this.buttonOpenCSV, "Data must be integer, in the range of [-127, 127]");
            this.buttonOpenCSV.UseVisualStyleBackColor = true;
            this.buttonOpenCSV.Click += new System.EventHandler(this.buttonOpenCSV_Click);
            // 
            // pictureBox21
            // 
            this.pictureBox21.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox21.Image")));
            this.pictureBox21.Location = new System.Drawing.Point(85, 55);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(32, 32);
            this.pictureBox21.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox21.TabIndex = 8;
            this.pictureBox21.TabStop = false;
            // 
            // radioButtonCustom
            // 
            this.radioButtonCustom.AutoSize = true;
            this.radioButtonCustom.Location = new System.Drawing.Point(66, 99);
            this.radioButtonCustom.Name = "radioButtonCustom";
            this.radioButtonCustom.Size = new System.Drawing.Size(60, 17);
            this.radioButtonCustom.TabIndex = 6;
            this.radioButtonCustom.TabStop = true;
            this.radioButtonCustom.Text = "Custom";
            this.radioButtonCustom.UseVisualStyleBackColor = true;
            this.radioButtonCustom.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonCustom_MouseClick);
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(85, 17);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(32, 32);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox3.TabIndex = 5;
            this.pictureBox3.TabStop = false;
            // 
            // radioButtonTrian
            // 
            this.radioButtonTrian.AutoSize = true;
            this.radioButtonTrian.Location = new System.Drawing.Point(66, 28);
            this.radioButtonTrian.Name = "radioButtonTrian";
            this.radioButtonTrian.Size = new System.Drawing.Size(14, 13);
            this.radioButtonTrian.TabIndex = 4;
            this.radioButtonTrian.TabStop = true;
            this.radioButtonTrian.UseVisualStyleBackColor = true;
            this.radioButtonTrian.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonTrian_MouseClick);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(28, 55);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(32, 32);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // radioButtonSquare
            // 
            this.radioButtonSquare.AutoSize = true;
            this.radioButtonSquare.Location = new System.Drawing.Point(9, 65);
            this.radioButtonSquare.Name = "radioButtonSquare";
            this.radioButtonSquare.Size = new System.Drawing.Size(14, 13);
            this.radioButtonSquare.TabIndex = 2;
            this.radioButtonSquare.TabStop = true;
            this.radioButtonSquare.UseVisualStyleBackColor = true;
            this.radioButtonSquare.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonSquare_MouseClick);
            // 
            // radioButtonSine
            // 
            this.radioButtonSine.AutoSize = true;
            this.radioButtonSine.Location = new System.Drawing.Point(9, 28);
            this.radioButtonSine.Name = "radioButtonSine";
            this.radioButtonSine.Size = new System.Drawing.Size(14, 13);
            this.radioButtonSine.TabIndex = 1;
            this.radioButtonSine.TabStop = true;
            this.radioButtonSine.UseVisualStyleBackColor = true;
            this.radioButtonSine.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioButtonSine_MouseClick);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(28, 17);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(32, 32);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(21, 338);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 13);
            this.label11.TabIndex = 11;
            this.label11.Text = "Offset";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 299);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(33, 26);
            this.label10.TabIndex = 10;
            this.label10.Text = "Duty\r\nCycle";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(23, 277);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(28, 13);
            this.label9.TabIndex = 9;
            this.label9.Text = "Amp";
            // 
            // tabPage7
            // 
            this.tabPage7.Controls.Add(this.checkBoxASCII);
            this.tabPage7.Controls.Add(this.checkBoxCircular);
            this.tabPage7.Controls.Add(this.tabControl3);
            this.tabPage7.Controls.Add(this.groupBox15);
            this.tabPage7.Controls.Add(this.button20);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(404, 542);
            this.tabPage7.TabIndex = 2;
            this.tabPage7.Text = "Protocol Sniffer";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // checkBoxASCII
            // 
            this.checkBoxASCII.AutoSize = true;
            this.checkBoxASCII.Location = new System.Drawing.Point(247, 24);
            this.checkBoxASCII.Name = "checkBoxASCII";
            this.checkBoxASCII.Size = new System.Drawing.Size(53, 17);
            this.checkBoxASCII.TabIndex = 15;
            this.checkBoxASCII.Text = "ASCII";
            this.checkBoxASCII.UseVisualStyleBackColor = true;
            this.checkBoxASCII.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBox4_MouseClick);
            // 
            // checkBoxCircular
            // 
            this.checkBoxCircular.AutoSize = true;
            this.checkBoxCircular.Location = new System.Drawing.Point(180, 24);
            this.checkBoxCircular.Name = "checkBoxCircular";
            this.checkBoxCircular.Size = new System.Drawing.Size(61, 17);
            this.checkBoxCircular.TabIndex = 35;
            this.checkBoxCircular.Text = "Circular";
            this.toolTip1.SetToolTip(this.checkBoxCircular, "New data will be placed at the end, older data will be shifted towards the fbegin" +
        "ning.");
            this.checkBoxCircular.UseVisualStyleBackColor = true;
            this.checkBoxCircular.MouseClick += new System.Windows.Forms.MouseEventHandler(this.checkBoxCircular_MouseClick);
            // 
            // tabControl3
            // 
            this.tabControl3.Controls.Add(this.tabPage10);
            this.tabControl3.Controls.Add(this.tabPage11);
            this.tabControl3.Controls.Add(this.tabPage12);
            this.tabControl3.Location = new System.Drawing.Point(6, 52);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(394, 482);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage10
            // 
            this.tabPage10.Controls.Add(this.label50);
            this.tabPage10.Controls.Add(this.label43);
            this.tabPage10.Controls.Add(this.textBox1);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(386, 456);
            this.tabPage10.TabIndex = 0;
            this.tabPage10.Text = "I2C";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label50.Location = new System.Drawing.Point(103, 12);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(69, 13);
            this.label50.TabIndex = 2;
            this.label50.Text = "BIT 1: SCL";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.Location = new System.Drawing.Point(11, 12);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(71, 13);
            this.label43.TabIndex = 1;
            this.label43.Text = "BIT 0: SDA";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(14, 33);
            this.textBox1.MaxLength = 4096;
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox1.Size = new System.Drawing.Size(360, 410);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "12345678911234567892123456789312\r\n1\r\n";
            // 
            // tabPage11
            // 
            this.tabPage11.Controls.Add(this.comboBoxStops);
            this.tabPage11.Controls.Add(this.comboBoxParity);
            this.tabPage11.Controls.Add(this.label55);
            this.tabPage11.Controls.Add(this.label54);
            this.tabPage11.Controls.Add(this.label53);
            this.tabPage11.Controls.Add(this.comboBoxBaud);
            this.tabPage11.Controls.Add(this.label51);
            this.tabPage11.Controls.Add(this.label52);
            this.tabPage11.Controls.Add(this.textBox3);
            this.tabPage11.Controls.Add(this.textBox2);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(386, 456);
            this.tabPage11.TabIndex = 1;
            this.tabPage11.Text = "UART";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // comboBoxStops
            // 
            this.comboBoxStops.FormattingEnabled = true;
            this.comboBoxStops.Items.AddRange(new object[] {
            "1",
            "2"});
            this.comboBoxStops.Location = new System.Drawing.Point(349, 9);
            this.comboBoxStops.Name = "comboBoxStops";
            this.comboBoxStops.Size = new System.Drawing.Size(32, 21);
            this.comboBoxStops.TabIndex = 14;
            this.comboBoxStops.SelectedIndexChanged += new System.EventHandler(this.comboBoxStops_SelectedIndexChanged);
            // 
            // comboBoxParity
            // 
            this.comboBoxParity.FormattingEnabled = true;
            this.comboBoxParity.Items.AddRange(new object[] {
            "None",
            "Even",
            "Odd"});
            this.comboBoxParity.Location = new System.Drawing.Point(237, 8);
            this.comboBoxParity.Name = "comboBoxParity";
            this.comboBoxParity.Size = new System.Drawing.Size(53, 21);
            this.comboBoxParity.TabIndex = 13;
            this.comboBoxParity.SelectedIndexChanged += new System.EventHandler(this.comboBoxParity_SelectedIndexChanged);
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label55.Location = new System.Drawing.Point(295, 12);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(52, 13);
            this.label55.TabIndex = 12;
            this.label55.Text = "Stop Bits:";
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label54.Location = new System.Drawing.Point(199, 12);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(36, 13);
            this.label54.TabIndex = 11;
            this.label54.Text = "Parity:";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label53.Location = new System.Drawing.Point(67, 12);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(61, 13);
            this.label53.TabIndex = 10;
            this.label53.Text = "Baud Rate:";
            // 
            // comboBoxBaud
            // 
            this.comboBoxBaud.FormattingEnabled = true;
            this.comboBoxBaud.Items.AddRange(new object[] {
            "1200",
            "2400",
            "4800",
            "9600",
            "19200",
            "38400",
            "57600",
            "115200"});
            this.comboBoxBaud.Location = new System.Drawing.Point(130, 9);
            this.comboBoxBaud.Name = "comboBoxBaud";
            this.comboBoxBaud.Size = new System.Drawing.Size(64, 21);
            this.comboBoxBaud.TabIndex = 9;
            this.comboBoxBaud.SelectedIndexChanged += new System.EventHandler(this.comboBoxBaud_SelectedIndexChanged);
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label51.Location = new System.Drawing.Point(7, 28);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(62, 13);
            this.label51.TabIndex = 6;
            this.label51.Text = "BIT 3: TX";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label52.Location = new System.Drawing.Point(7, 12);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(63, 13);
            this.label52.TabIndex = 5;
            this.label52.Text = "BIT 2: RX";
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(200, 49);
            this.textBox3.MaxLength = 2560;
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.ReadOnly = true;
            this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox3.Size = new System.Drawing.Size(180, 386);
            this.textBox3.TabIndex = 2;
            this.textBox3.Text = "11 22 33 44 55\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(6, 49);
            this.textBox2.MaxLength = 2560;
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox2.Size = new System.Drawing.Size(180, 386);
            this.textBox2.TabIndex = 1;
            this.textBox2.Text = "11 22 33 44 55\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8";
            // 
            // tabPage12
            // 
            this.tabPage12.Controls.Add(this.label61);
            this.tabPage12.Controls.Add(this.label56);
            this.tabPage12.Controls.Add(this.comboBoxCPHA);
            this.tabPage12.Controls.Add(this.label57);
            this.tabPage12.Controls.Add(this.label58);
            this.tabPage12.Controls.Add(this.comboBoxCPOL);
            this.tabPage12.Controls.Add(this.label59);
            this.tabPage12.Controls.Add(this.label60);
            this.tabPage12.Controls.Add(this.textBox4);
            this.tabPage12.Controls.Add(this.textBox13);
            this.tabPage12.Location = new System.Drawing.Point(4, 22);
            this.tabPage12.Name = "tabPage12";
            this.tabPage12.Size = new System.Drawing.Size(386, 456);
            this.tabPage12.TabIndex = 2;
            this.tabPage12.Text = "SPI";
            this.tabPage12.UseVisualStyleBackColor = true;
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label61.Location = new System.Drawing.Point(94, 24);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(70, 13);
            this.label61.TabIndex = 30;
            this.label61.Text = "BIT 7: SCK";
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label56.Location = new System.Drawing.Point(94, 9);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(77, 13);
            this.label56.TabIndex = 29;
            this.label56.Text = "BIT 6: MISO";
            // 
            // comboBoxCPHA
            // 
            this.comboBoxCPHA.FormattingEnabled = true;
            this.comboBoxCPHA.Items.AddRange(new object[] {
            "0",
            "1"});
            this.comboBoxCPHA.Location = new System.Drawing.Point(328, 8);
            this.comboBoxCPHA.Name = "comboBoxCPHA";
            this.comboBoxCPHA.Size = new System.Drawing.Size(53, 21);
            this.comboBoxCPHA.TabIndex = 26;
            this.comboBoxCPHA.SelectedIndexChanged += new System.EventHandler(this.comboBoxCPHA_SelectedIndexChanged);
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label57.Location = new System.Drawing.Point(289, 12);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(39, 13);
            this.label57.TabIndex = 24;
            this.label57.Text = "CPHA:";
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label58.Location = new System.Drawing.Point(187, 12);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(38, 13);
            this.label58.TabIndex = 23;
            this.label58.Text = "CPOL:";
            // 
            // comboBoxCPOL
            // 
            this.comboBoxCPOL.FormattingEnabled = true;
            this.comboBoxCPOL.Items.AddRange(new object[] {
            "0",
            "1"});
            this.comboBoxCPOL.Location = new System.Drawing.Point(225, 9);
            this.comboBoxCPOL.Name = "comboBoxCPOL";
            this.comboBoxCPOL.Size = new System.Drawing.Size(53, 21);
            this.comboBoxCPOL.TabIndex = 22;
            this.comboBoxCPOL.SelectedIndexChanged += new System.EventHandler(this.comboBoxCPOL_SelectedIndexChanged);
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label59.Location = new System.Drawing.Point(11, 24);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(77, 13);
            this.label59.TabIndex = 19;
            this.label59.Text = "BIT 5: MOSI";
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label60.Location = new System.Drawing.Point(11, 9);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(62, 13);
            this.label60.TabIndex = 18;
            this.label60.Text = "BIT 4: SS";
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox4.Location = new System.Drawing.Point(200, 43);
            this.textBox4.MaxLength = 2560;
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ReadOnly = true;
            this.textBox4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox4.Size = new System.Drawing.Size(180, 392);
            this.textBox4.TabIndex = 17;
            this.textBox4.Text = "11 22 33 44 55\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8";
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox13.Location = new System.Drawing.Point(6, 43);
            this.textBox13.MaxLength = 2560;
            this.textBox13.Multiline = true;
            this.textBox13.Name = "textBox13";
            this.textBox13.ReadOnly = true;
            this.textBox13.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox13.Size = new System.Drawing.Size(180, 392);
            this.textBox13.TabIndex = 16;
            this.textBox13.Text = "11 22 33 44 55\r\n2\r\n3\r\n4\r\n5\r\n6\r\n7\r\n8";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.radioSniffSingle);
            this.groupBox15.Controls.Add(this.radioSniffNormal);
            this.groupBox15.Location = new System.Drawing.Point(14, 11);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(158, 35);
            this.groupBox15.TabIndex = 3;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Mode";
            // 
            // radioSniffSingle
            // 
            this.radioSniffSingle.AutoSize = true;
            this.radioSniffSingle.Location = new System.Drawing.Point(102, 12);
            this.radioSniffSingle.Name = "radioSniffSingle";
            this.radioSniffSingle.Size = new System.Drawing.Size(54, 17);
            this.radioSniffSingle.TabIndex = 1;
            this.radioSniffSingle.TabStop = true;
            this.radioSniffSingle.Text = "Single";
            this.toolTip1.SetToolTip(this.radioSniffSingle, "The sniffer will stop when the buffer is filled.");
            this.radioSniffSingle.UseVisualStyleBackColor = true;
            this.radioSniffSingle.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioSniffSingle_MouseClick);
            // 
            // radioSniffNormal
            // 
            this.radioSniffNormal.AutoSize = true;
            this.radioSniffNormal.Location = new System.Drawing.Point(38, 12);
            this.radioSniffNormal.Name = "radioSniffNormal";
            this.radioSniffNormal.Size = new System.Drawing.Size(58, 17);
            this.radioSniffNormal.TabIndex = 0;
            this.radioSniffNormal.TabStop = true;
            this.radioSniffNormal.Text = "Normal";
            this.toolTip1.SetToolTip(this.radioSniffNormal, "Continuous operation.");
            this.radioSniffNormal.UseVisualStyleBackColor = true;
            this.radioSniffNormal.MouseClick += new System.Windows.Forms.MouseEventHandler(this.radioSniffNormal_MouseClick);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(336, 17);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(54, 28);
            this.button20.TabIndex = 8;
            this.button20.Text = "Start";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // tabPage8
            // 
            this.tabPage8.Controls.Add(this.groupBox11);
            this.tabPage8.Controls.Add(this.groupBox8);
            this.tabPage8.Controls.Add(this.groupBox7);
            this.tabPage8.Controls.Add(this.groupBox6);
            this.tabPage8.Location = new System.Drawing.Point(4, 22);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage8.Size = new System.Drawing.Size(404, 542);
            this.tabPage8.TabIndex = 3;
            this.tabPage8.Text = " Options  ";
            this.tabPage8.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.pictureBox9);
            this.groupBox11.Controls.Add(this.labelConnected);
            this.groupBox11.Controls.Add(this.buttonConnect);
            this.groupBox11.Controls.Add(this.label31);
            this.groupBox11.Controls.Add(this.checkBox31);
            this.groupBox11.Controls.Add(this.comboBoxCOMS);
            this.groupBox11.Location = new System.Drawing.Point(12, 310);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(386, 77);
            this.groupBox11.TabIndex = 4;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Connection";
            // 
            // pictureBox9
            // 
            this.pictureBox9.Image = global::Xprotolab_interface.Properties.Resources.led_off;
            this.pictureBox9.Location = new System.Drawing.Point(211, 46);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(22, 22);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox9.TabIndex = 8;
            this.pictureBox9.TabStop = false;
            // 
            // labelConnected
            // 
            this.labelConnected.AutoSize = true;
            this.labelConnected.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelConnected.Location = new System.Drawing.Point(239, 50);
            this.labelConnected.Name = "labelConnected";
            this.labelConnected.Size = new System.Drawing.Size(115, 17);
            this.labelConnected.TabIndex = 7;
            this.labelConnected.Text = "Not Connected";
            // 
            // buttonConnect
            // 
            this.buttonConnect.Location = new System.Drawing.Point(12, 43);
            this.buttonConnect.Name = "buttonConnect";
            this.buttonConnect.Size = new System.Drawing.Size(72, 21);
            this.buttonConnect.TabIndex = 6;
            this.buttonConnect.Text = "Connect";
            this.buttonConnect.UseVisualStyleBackColor = true;
            this.buttonConnect.Click += new System.EventHandler(this.button21_Click);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(230, 21);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(56, 13);
            this.label31.TabIndex = 5;
            this.label31.Text = "COM Port:";
            // 
            // checkBox31
            // 
            this.checkBox31.AutoSize = true;
            this.checkBox31.Checked = global::Xprotolab_interface.Properties.Settings.Default.Connect_start;
            this.checkBox31.DataBindings.Add(new System.Windows.Forms.Binding("Checked", global::Xprotolab_interface.Properties.Settings.Default, "Connect_start", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged));
            this.checkBox31.Location = new System.Drawing.Point(15, 20);
            this.checkBox31.Name = "checkBox31";
            this.checkBox31.Size = new System.Drawing.Size(113, 17);
            this.checkBox31.TabIndex = 4;
            this.checkBox31.Text = "Connect at startup";
            this.checkBox31.UseVisualStyleBackColor = true;
            // 
            // comboBoxCOMS
            // 
            this.comboBoxCOMS.FormattingEnabled = true;
            this.comboBoxCOMS.Location = new System.Drawing.Point(292, 18);
            this.comboBoxCOMS.Name = "comboBoxCOMS";
            this.comboBoxCOMS.Size = new System.Drawing.Size(61, 21);
            this.comboBoxCOMS.TabIndex = 3;
            this.comboBoxCOMS.SelectedIndexChanged += new System.EventHandler(this.comboBox3_SelectedIndexChanged);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.textBox6);
            this.groupBox8.Controls.Add(this.label21);
            this.groupBox8.Controls.Add(this.button16);
            this.groupBox8.Controls.Add(this.textBoxVersion);
            this.groupBox8.Controls.Add(this.label20);
            this.groupBox8.Location = new System.Drawing.Point(12, 393);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(386, 87);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Device Firmware";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(287, 23);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(54, 20);
            this.textBox6.TabIndex = 4;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(196, 25);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(77, 13);
            this.label21.TabIndex = 3;
            this.label21.Text = "Latest Version:";
            // 
            // button16
            // 
            this.button16.Enabled = false;
            this.button16.Location = new System.Drawing.Point(22, 54);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(319, 23);
            this.button16.TabIndex = 2;
            this.button16.Text = "UPGRADE FIRMWARE";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // textBoxVersion
            // 
            this.textBoxVersion.Location = new System.Drawing.Point(118, 23);
            this.textBoxVersion.Name = "textBoxVersion";
            this.textBoxVersion.Size = new System.Drawing.Size(54, 20);
            this.textBoxVersion.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(21, 25);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(82, 13);
            this.label20.TabIndex = 0;
            this.label20.Text = "Current Version:";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.checkBox6);
            this.groupBox7.Controls.Add(this.pictureBox18);
            this.groupBox7.Controls.Add(this.pictureBox17);
            this.groupBox7.Controls.Add(this.pictureBox16);
            this.groupBox7.Controls.Add(this.pictureBox15);
            this.groupBox7.Controls.Add(this.pictureBox14);
            this.groupBox7.Controls.Add(this.label64);
            this.groupBox7.Controls.Add(this.label63);
            this.groupBox7.Controls.Add(this.trackBar5);
            this.groupBox7.Controls.Add(this.trackBar4);
            this.groupBox7.Controls.Add(this.label62);
            this.groupBox7.Controls.Add(this.comboBox6);
            this.groupBox7.Controls.Add(this.label23);
            this.groupBox7.Controls.Add(this.comboBox2);
            this.groupBox7.Controls.Add(this.label22);
            this.groupBox7.Controls.Add(this.button15);
            this.groupBox7.Controls.Add(this.checkBoxLines);
            this.groupBox7.Controls.Add(this.checkBoxPersistence);
            this.groupBox7.Location = new System.Drawing.Point(12, 82);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(386, 222);
            this.groupBox7.TabIndex = 1;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Display";
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(20, 147);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(93, 17);
            this.checkBox6.TabIndex = 104;
            this.checkBox6.Text = "Color Gradient";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // pictureBox18
            // 
            this.pictureBox18.Image = global::Xprotolab_interface.Properties.Resources.colorgradient;
            this.pictureBox18.Location = new System.Drawing.Point(118, 140);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(24, 24);
            this.pictureBox18.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox18.TabIndex = 103;
            this.pictureBox18.TabStop = false;
            // 
            // pictureBox17
            // 
            this.pictureBox17.Image = global::Xprotolab_interface.Properties.Resources.lowintense;
            this.pictureBox17.Location = new System.Drawing.Point(22, 36);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(24, 24);
            this.pictureBox17.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox17.TabIndex = 102;
            this.pictureBox17.TabStop = false;
            // 
            // pictureBox16
            // 
            this.pictureBox16.Image = global::Xprotolab_interface.Properties.Resources.veryintense;
            this.pictureBox16.Location = new System.Drawing.Point(349, 36);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(24, 24);
            this.pictureBox16.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox16.TabIndex = 101;
            this.pictureBox16.TabStop = false;
            // 
            // pictureBox15
            // 
            this.pictureBox15.Image = global::Xprotolab_interface.Properties.Resources.longdecay;
            this.pictureBox15.Location = new System.Drawing.Point(349, 88);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(24, 24);
            this.pictureBox15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox15.TabIndex = 20;
            this.pictureBox15.TabStop = false;
            // 
            // pictureBox14
            // 
            this.pictureBox14.Image = global::Xprotolab_interface.Properties.Resources.shortdecay;
            this.pictureBox14.Location = new System.Drawing.Point(22, 88);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(24, 24);
            this.pictureBox14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox14.TabIndex = 19;
            this.pictureBox14.TabStop = false;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(8, 71);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(38, 13);
            this.label64.TabIndex = 18;
            this.label64.Text = "Decay";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(3, 19);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(46, 13);
            this.label63.TabIndex = 17;
            this.label63.Text = "Intensity";
            // 
            // trackBar5
            // 
            this.trackBar5.LargeChange = 10;
            this.trackBar5.Location = new System.Drawing.Point(55, 75);
            this.trackBar5.Maximum = 100;
            this.trackBar5.Name = "trackBar5";
            this.trackBar5.Size = new System.Drawing.Size(288, 45);
            this.trackBar5.TabIndex = 100;
            this.trackBar5.TickFrequency = 10;
            this.trackBar5.Value = 50;
            // 
            // trackBar4
            // 
            this.trackBar4.LargeChange = 10;
            this.trackBar4.Location = new System.Drawing.Point(55, 23);
            this.trackBar4.Maximum = 100;
            this.trackBar4.Name = "trackBar4";
            this.trackBar4.Size = new System.Drawing.Size(288, 45);
            this.trackBar4.TabIndex = 16;
            this.trackBar4.TickFrequency = 10;
            this.trackBar4.Value = 50;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(213, 166);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(87, 13);
            this.label62.TabIndex = 8;
            this.label62.Text = "Display Average:";
            // 
            // comboBox6
            // 
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "1",
            "2",
            "4",
            "8",
            "16",
            "32",
            "64",
            "128",
            "256"});
            this.comboBox6.Location = new System.Drawing.Point(306, 163);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(61, 21);
            this.comboBox6.TabIndex = 7;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(274, 193);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(26, 13);
            this.label23.TabIndex = 6;
            this.label23.Text = "Grid";
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "Full",
            "Lines",
            "Dots",
            "No Grid"});
            this.comboBox2.Location = new System.Drawing.Point(306, 190);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(61, 21);
            this.comboBox2.TabIndex = 5;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(149, 193);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(92, 13);
            this.label22.TabIndex = 4;
            this.label22.Text = "Background Color";
            // 
            // button15
            // 
            this.button15.BackColor = global::Xprotolab_interface.Properties.Settings.Default.background_color;
            this.button15.Location = new System.Drawing.Point(130, 193);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(13, 14);
            this.button15.TabIndex = 3;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // checkBoxLines
            // 
            this.checkBoxLines.AutoSize = true;
            this.checkBoxLines.Checked = true;
            this.checkBoxLines.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBoxLines.Location = new System.Drawing.Point(20, 193);
            this.checkBoxLines.Name = "checkBoxLines";
            this.checkBoxLines.Size = new System.Drawing.Size(62, 17);
            this.checkBoxLines.TabIndex = 1;
            this.checkBoxLines.Text = "Vectors";
            this.checkBoxLines.UseVisualStyleBackColor = true;
            this.checkBoxLines.CheckedChanged += new System.EventHandler(this.checkBoxLines_CheckedChanged);
            // 
            // checkBoxPersistence
            // 
            this.checkBoxPersistence.AutoSize = true;
            this.checkBoxPersistence.Location = new System.Drawing.Point(20, 170);
            this.checkBoxPersistence.Name = "checkBoxPersistence";
            this.checkBoxPersistence.Size = new System.Drawing.Size(115, 17);
            this.checkBoxPersistence.TabIndex = 0;
            this.checkBoxPersistence.Text = "Infinite Persistence";
            this.checkBoxPersistence.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.button12);
            this.groupBox6.Controls.Add(this.button11);
            this.groupBox6.Controls.Add(this.button10);
            this.groupBox6.Controls.Add(this.button9);
            this.groupBox6.Location = new System.Drawing.Point(12, 17);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(386, 59);
            this.groupBox6.TabIndex = 0;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "File";
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(15, 19);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(79, 24);
            this.button12.TabIndex = 3;
            this.button12.Text = "Load Wave";
            this.button12.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(107, 19);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(79, 24);
            this.button11.TabIndex = 2;
            this.button11.Text = "Save Wave";
            this.button11.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(292, 19);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(79, 24);
            this.button10.TabIndex = 1;
            this.button10.Text = "Save CSV";
            this.button10.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(199, 19);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(80, 24);
            this.button9.TabIndex = 0;
            this.button9.Text = "Save BMP";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // tabPage13
            // 
            this.tabPage13.Controls.Add(this.label66);
            this.tabPage13.Controls.Add(this.textBox14);
            this.tabPage13.Controls.Add(this.linkLabel1);
            this.tabPage13.Controls.Add(this.labelVersion);
            this.tabPage13.Controls.Add(this.label65);
            this.tabPage13.Controls.Add(this.pictureBox13);
            this.tabPage13.Location = new System.Drawing.Point(4, 22);
            this.tabPage13.Name = "tabPage13";
            this.tabPage13.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage13.Size = new System.Drawing.Size(404, 542);
            this.tabPage13.TabIndex = 4;
            this.tabPage13.Text = "   ?";
            this.tabPage13.UseVisualStyleBackColor = true;
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(141, 169);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(94, 13);
            this.label66.TabIndex = 5;
            this.label66.Text = "(C) Copyright 2012";
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox14.Location = new System.Drawing.Point(16, 241);
            this.textBox14.Multiline = true;
            this.textBox14.Name = "textBox14";
            this.textBox14.ReadOnly = true;
            this.textBox14.Size = new System.Drawing.Size(373, 229);
            this.textBox14.TabIndex = 4;
            this.textBox14.Text = resources.GetString("textBox14.Text");
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Century Gothic", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.HoverUnderline;
            this.linkLabel1.Location = new System.Drawing.Point(50, 112);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(304, 56);
            this.linkLabel1.TabIndex = 2;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "gabotronics";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // labelVersion
            // 
            this.labelVersion.AutoSize = true;
            this.labelVersion.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelVersion.Location = new System.Drawing.Point(246, 207);
            this.labelVersion.Name = "labelVersion";
            this.labelVersion.Size = new System.Drawing.Size(18, 20);
            this.labelVersion.TabIndex = 1;
            this.labelVersion.Text = "1";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label65.Location = new System.Drawing.Point(44, 207);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(196, 20);
            this.label65.TabIndex = 0;
            this.label65.Text = "XScope Interface Version:";
            // 
            // pictureBox13
            // 
            this.pictureBox13.Image = global::Xprotolab_interface.Properties.Resources.GT_logo;
            this.pictureBox13.Location = new System.Drawing.Point(91, 6);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(200, 105);
            this.pictureBox13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pictureBox13.TabIndex = 3;
            this.pictureBox13.TabStop = false;
            // 
            // ScrollBarHPos
            // 
            this.ScrollBarHPos.LargeChange = 1;
            this.ScrollBarHPos.Location = new System.Drawing.Point(1, 539);
            this.ScrollBarHPos.Maximum = 127;
            this.ScrollBarHPos.Name = "ScrollBarHPos";
            this.ScrollBarHPos.Size = new System.Drawing.Size(512, 23);
            this.ScrollBarHPos.TabIndex = 24;
            this.ScrollBarHPos.Scroll += new System.Windows.Forms.ScrollEventHandler(this.ScrollBarHPos_Scroll);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(10, 516);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(31, 13);
            this.label35.TabIndex = 27;
            this.label35.Text = "CH1";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(117, 516);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(31, 13);
            this.label37.TabIndex = 28;
            this.label37.Text = "CH2";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(234, 516);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(34, 13);
            this.label38.TabIndex = 29;
            this.label38.Text = "Time";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.Location = new System.Drawing.Point(341, 516);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(47, 13);
            this.label39.TabIndex = 30;
            this.label39.Text = "Trigger";
            // 
            // labelCH1Gain
            // 
            this.labelCH1Gain.AutoSize = true;
            this.labelCH1Gain.Location = new System.Drawing.Point(40, 516);
            this.labelCH1Gain.Name = "labelCH1Gain";
            this.labelCH1Gain.Size = new System.Drawing.Size(0, 13);
            this.labelCH1Gain.TabIndex = 31;
            // 
            // labelCH2Gain
            // 
            this.labelCH2Gain.AutoSize = true;
            this.labelCH2Gain.Location = new System.Drawing.Point(147, 516);
            this.labelCH2Gain.Name = "labelCH2Gain";
            this.labelCH2Gain.Size = new System.Drawing.Size(0, 13);
            this.labelCH2Gain.TabIndex = 32;
            // 
            // labelSRate
            // 
            this.labelSRate.AutoSize = true;
            this.labelSRate.Location = new System.Drawing.Point(268, 516);
            this.labelSRate.Name = "labelSRate";
            this.labelSRate.Size = new System.Drawing.Size(0, 13);
            this.labelSRate.TabIndex = 33;
            // 
            // labelTriggerLevel
            // 
            this.labelTriggerLevel.AutoSize = true;
            this.labelTriggerLevel.Location = new System.Drawing.Point(390, 516);
            this.labelTriggerLevel.Name = "labelTriggerLevel";
            this.labelTriggerLevel.Size = new System.Drawing.Size(0, 13);
            this.labelTriggerLevel.TabIndex = 34;
            // 
            // Form1
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.ClientSize = new System.Drawing.Size(934, 568);
            this.Controls.Add(this.labelTriggerLevel);
            this.Controls.Add(this.labelSRate);
            this.Controls.Add(this.labelCH2Gain);
            this.Controls.Add(this.labelCH1Gain);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.ScrollBarHPos);
            this.Controls.Add(this.tabControl2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(950, 606);
            this.MinimumSize = new System.Drawing.Size(528, 550);
            this.Name = "Form1";
            this.Text = "Gabotronics XScopes Interface v0.26";
            this.Closing += new System.ComponentModel.CancelEventHandler(this.Form1_Closing);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.Form1_Paint);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox25)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarZoom)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSampling)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCH1Gain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCH1Pos)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCH2Gain)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCH2Pos)).EndInit();
            this.tabPage9.ResumeLayout(false);
            this.tabPage9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCHDPull)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarCHDPos)).EndInit();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar9)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar1)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpTTimeout)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownTHold)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox24)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox23)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage5.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSWSpeed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSW2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarSW1)).EndInit();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownOffset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDuty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownFreq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAmp)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarOffset)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarDuty)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarFreq)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarAmp)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox22)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabControl3.ResumeLayout(false);
            this.tabPage10.ResumeLayout(false);
            this.tabPage10.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            this.tabPage11.PerformLayout();
            this.tabPage12.ResumeLayout(false);
            this.tabPage12.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBar4)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.tabPage13.ResumeLayout(false);
            this.tabPage13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()  {
			Application.Run(new Form1());
		}

        private void USBScope(Graphics g) {
            int xmax = 512; // display size
            int xlast = 0;
            int ylast = 0;
            int yint;
            UInt16 i = 0, inc=2;
            if(trackBarSampling.Value < 11) {
                i = (UInt16)ScrollBarHPos.Value;
                inc = 4;
            }
            // Create pens.
            Pen CH1Pen = new Pen(button1.BackColor, 2);
            Pen CH2Pen = new Pen(button2.BackColor, 2);
            // read each value from the buffer and plot the sample on the scope		
            for(int xpos = 0; xpos < xmax; i++, xlast = xpos, xpos += inc, ylast = yint) {
                yint = ((64 + trackBarCH1Pos.Minimum - trackBarCH1Pos.Value) + CHData[i]) * 2;
                if(checkBoxCH1On.Checked) {
                    if(checkBoxLines.Checked) {
                        if(xpos == 0) continue;
                        g.DrawLine(CH1Pen, xlast, ylast, xpos, yint);
                    }
                    else
                        g.DrawLine(Pens.Blue, xpos, yint, xpos, yint);
                }
            }
            if(trackBarSampling.Value < 11) {
                i = (UInt16)(256 + ScrollBarHPos.Value);
                inc = 4;
            }
            // read each value from the buffer and plot the sample on the scope		
            for(int xpos = 0; xpos < xmax; i++, xlast = xpos, xpos += inc, ylast = yint) {
                yint = ((64 + trackBarCH2Pos.Minimum - trackBarCH2Pos.Value) + CHData[i]) * 2;
                if(checkBoxCH2On.Checked && trackBarSampling.Value>0) {
                    if(checkBoxLines.Checked) {
                        if(xpos == 0) continue;
                        g.DrawLine(CH2Pen, xlast, ylast, xpos, yint);
                    }
                    else
                        g.DrawLine(Pens.Blue, xpos, yint, xpos, yint);
                }
            }
        }

        private void UARTScope(Graphics g) {
			int xmax = 512; // number of sample points
			int xlast=0;
			int ylast=0;
            int yint;
            if(!serialPort1.IsOpen) return;
            if(!SerialBusy.WaitOne(1000)) return;

            if(checkBoxCH1On.Checked) { // Request data from Xprotolab CH1
                serialPort1.Write("r");
                Thread.Sleep(20);
                // read each value from the buffer and plot the sample on the scope		
                for(int xpos = 0; xpos < xmax; xlast = xpos, xpos += 2, ylast = yint) {
                    try {
                        yint = ((64 + trackBarCH1Pos.Minimum - trackBarCH1Pos.Value) + serialPort1.ReadByte()) * 2;
                    }
                    catch(TimeoutException) {
                        checkBoxStop.Checked = false;
                        checkBoxStop.Enabled = false;
                        SerialBusy.ReleaseMutex();
                        return;
                    }
                    if(checkBoxCH1On.Checked) {
                        // don't draw the first sample point, use it as a starting sample point
                        if(checkBoxLines.Checked) {
                            if(xpos == 0) continue;
                            g.DrawLine(Pens.LawnGreen, xlast, ylast, xpos, yint);
                        }
                        else
                            g.DrawLine(Pens.Blue, xpos, yint, xpos, yint);
                    }
                }
            }
        // Request data from Xprotolab CH2
            if(checkBoxCH2On.Checked) { // Request data from Xprotolab CH2
                serialPort1.Write("s");
                Thread.Sleep(20);
                // read each value from the buffer and plot the sample on the scope		
                for(int xpos = 0; xpos < xmax; xlast = xpos, xpos += 2, ylast = yint) {
                    try {
                        yint = ((64 + trackBarCH2Pos.Minimum - trackBarCH2Pos.Value) + serialPort1.ReadByte()) * 2;
                    }
                    catch(TimeoutException) {
                        checkBoxStop.Checked = false;
                        checkBoxStop.Enabled = false;
                        SerialBusy.ReleaseMutex();
                        return;
                    }
                    if(checkBoxCH2On.Checked && trackBarSampling.Value > 0) {
                        if(checkBoxLines.Checked) {
                            if(xpos == 0) continue;
                            g.DrawLine(Pens.Red, xlast, ylast, xpos, yint);
                        }
                        else
                            g.DrawLine(Pens.Blue, xpos, yint, xpos, yint);
                    }
                }
            }
            SerialBusy.ReleaseMutex();
        }

		const int kScopeWidth = 512;
		const int kScopeHeight = 512;
		Rectangle scopeRect = new Rectangle(0, 0, kScopeWidth, kScopeHeight);

		private void DrawGrid(Graphics g) {
			// Draw the background
            SolidBrush blueBrush = new SolidBrush(button15.BackColor);
            g.FillRectangle(blueBrush, scopeRect);

			const int kpadding = 0;
			const int tickheight = 4;
			const int tickheightLarge = 8;
			// draw the Grid Lines
			for (int i = 0; i < 512; i += 64) {
				// draw horizontal line
				g.DrawLine(Pens.DarkGray, 0, i + kpadding, kScopeWidth, i + kpadding);

				// draw vertical line
				g.DrawLine(Pens.DarkGray, i + kpadding, 0, i + kpadding, kScopeHeight );

				// draw ticks on each line
				if (i == 256) {
					for (int j = 0; j < kScopeWidth; j+= 8) {
						if (j % 32 != 0) {
							g.DrawLine(Pens.White, j, (i- tickheight/2),
								j, (i + tickheight/2 ));

							g.DrawLine(Pens.White, (i- tickheight/2), j,
								(i + tickheight/2 ), j);
						}
						else {
							g.DrawLine(Pens.White, j, (i- tickheightLarge/2) + kpadding,
								j, (i + tickheightLarge/2 ) + kpadding);

							g.DrawLine(Pens.White, (i- tickheightLarge/2), j,
								(i + tickheightLarge/2 ), j);
						}
					}
				}
			}
			// Draw Scope from a to d
            if(myDeviceDetected) this.USBScope(g);
            else this.UARTScope(g);
		}
						  
		private void Form1_Paint(object sender, System.Windows.Forms.PaintEventArgs e) {
		    Graphics g = e.Graphics;
            // Draw the scope Grid
			DrawGrid(g);
        }

		private void timer1_Tick(object sender, System.EventArgs e) {
            /*byte Channels, i = 0;
            if (serialPort1.IsOpen && serialPort1.BytesToRead>0) {
                Channels = (byte)serialPort1.ReadByte();
                if (trackBarSampling.Value < 11) {
                    try {
                        do {
                            CH1Data[i] = (byte)serialPort1.ReadByte();
                            CH2Data[i] = (byte)serialPort1.ReadByte();
                            CHDData[i] = (byte)serialPort1.ReadByte();
                        } while ((++i) != 0);
                    }
                    catch (TimeoutException) {
                        ScopeOn = false;
                        button_run.BackColor = Color.Gray;
                        button_run.Text = "Off";
                        return;
                    }
                }
            }*/
            Invalidate(new Rectangle(0, 0, 512, 512));      // Refresh Display area
		}

		private void button_Auto(object sender, System.EventArgs e) {
            checkBoxStop.Checked = false;
            if(myDeviceDetected) {
                myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('i'), 0, 0);
            }
            else if(serialPort1.IsOpen) {
                if(!SerialBusy.WaitOne(100)) return;
                serialPort1.Write("i");
                SerialBusy.ReleaseMutex();
            }
		}

        // Load CSV
        private void buttonOpenCSV_Click(object sender, EventArgs e) {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = "c:\\";
            openFileDialog1.Filter = "CSV files (*.csv)|*.txt|All files (*.*)|*.*";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            if(openFileDialog1.ShowDialog() == DialogResult.OK) {
                try {
                    if(openFileDialog1.OpenFile() != null) {
                        System.IO.StreamReader sr = new System.IO.StreamReader(openFileDialog1.FileName);
                        richTextBox1.Text = sr.ReadToEnd();
                        sr.Close();
                    }
                }
                catch(Exception ex) {
                    MessageBox.Show("Error: Could not read file from disk. Original error: " + ex.Message);
                }
            }
        }

        int comma_parse(string line, ref byte[] data, int size) {
            int n = 0, i = 0, j = 0;
            int max = line.Length;
            char c;
            while(i < max) {
                c = line[i];
                if(c == ',' || c == '\n' || c == '\r' || Char.IsLetter(c)) {
                    i++;
                    continue;
                }
                j = 0;
                while(Char.IsDigit(line[i + j]) || line[i + j] == '-') j++;
                data[n] = (byte)(/*(-trackBarAmp.Value / 128) **/ int.Parse(line.Substring(i, j)));   /* Save the number */
                if(data[n] == 128) data[n] = 129;   // Data of -128 is forbidden, write -127
                n++;
                if(n == size) break;
                i+=j;
            }
            return n;
        }

        private void buttonSaveAWG_Click(object sender, EventArgs e) {
            if(myDeviceDetected) {
                comma_parse(richTextBox1.Text, ref AWGBuffer, 256);
                myWinUsbDevice.SendViaBulkTransfer(ref AWGBuffer, 256);
            }
            myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('e'), 0, 0);
            radioButtonSine.Checked = false;
            radioButtonSquare.Checked = false;
            radioButtonTrian.Checked = false;
            radioButtonExpo.Checked = false;
            radioButtonNoise.Checked = false;
            radioButtonCustom.Checked = true;
            SelectWaveform();
        }

		private void Form1_Closing(object sender, System.ComponentModel.CancelEventArgs e) {
            // Save settings in device
            if(myDeviceDetected) {
                myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('d'), 0, 0);
            }
            else if(serialPort1.IsOpen) {
                if(!SerialBusy.WaitOne(100)) return;
                serialPort1.Write("d");
                SerialBusy.ReleaseMutex();
            }
            myDeviceDetected = false;
            Thread.Sleep(100);  // Allows the last USB transfer to complete (WinUsb_AbortPipe not working?)
            try {
                serialPort1.Close();
                myWinUsbDevice.CloseDeviceHandle();
                myDeviceManagement.StopReceivingDeviceNotifications(deviceNotificationHandle);
            }
            catch {
                throw;
            }
		}

		private bool StorageOn = false;
		private void button5_storage(object sender, System.EventArgs e) {
			StorageOn = !StorageOn;

			if (StorageOn == false) {
				StorageButton.ForeColor = Color.Black;
			}
			else {
				StorageButton.ForeColor = Color.Red;
			}
		}

        private void Form1_Load(object sender, EventArgs e) {
            if (Xprotolab_interface.Properties.Settings.Default.Connect_start) {
                Connect();
            }
        }

        private void button1_Click(object sender, EventArgs e) {
            ColorDialog MyDialog = new ColorDialog();
            // Keeps the user from selecting a custom color.
            MyDialog.AllowFullOpen = false;
            // Allows the user to get help. (The default is false.)
            MyDialog.ShowHelp = true;
            // Sets the initial color select to the current text color.
            MyDialog.Color = button1.BackColor;

            // Update the text box color if the user clicks OK 
            if (MyDialog.ShowDialog() == DialogResult.OK)
                button1.BackColor = MyDialog.Color;
        }

        private void button2_Click(object sender, EventArgs e) {
            ColorDialog MyDialog = new ColorDialog();
            // Keeps the user from selecting a custom color.
            MyDialog.AllowFullOpen = false;
            // Allows the user to get help. (The default is false.)
            MyDialog.ShowHelp = true;
            // Sets the initial color select to the current text color.
            MyDialog.Color = button2.BackColor;

            // Update the text box color if the user clicks OK 
            if (MyDialog.ShowDialog() == DialogResult.OK)
                button2.BackColor = MyDialog.Color;
        }

        private void button3_Click(object sender, EventArgs e) {
            ColorDialog MyDialog = new ColorDialog();
            // Keeps the user from selecting a custom color.
            MyDialog.AllowFullOpen = false;
            // Allows the user to get help. (The default is false.)
            MyDialog.ShowHelp = true;
            // Sets the initial color select to the current text color.
            MyDialog.Color = button3.BackColor;

            // Update the text box color if the user clicks OK 
            if (MyDialog.ShowDialog() == DialogResult.OK)
                button3.BackColor = MyDialog.Color;
        }

        private void button15_Click(object sender, EventArgs e) {
            ColorDialog MyDialog = new ColorDialog();
            // Keeps the user from selecting a custom color.
            MyDialog.AllowFullOpen = false;
            // Allows the user to get help. (The default is false.)
            MyDialog.ShowHelp = true;
            // Sets the initial color select to the current text color.
            MyDialog.Color = button15.BackColor;

            // Update the text box color if the user clicks OK 
            if (MyDialog.ShowDialog() == DialogResult.OK)
                button15.BackColor = MyDialog.Color;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e) {
            Xprotolab_interface.Properties.Settings.Default.background_color = button15.BackColor;
            Xprotolab_interface.Properties.Settings.Default.COMPORT = string.Copy(COM_PORT);
            Xprotolab_interface.Properties.Settings.Default.Save();
        }

        private void button21_Click(object sender, EventArgs e) {
            Connect();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e) {
            if(comboBoxCOMS.SelectedItem!=null) COM_PORT = String.Copy(comboBoxCOMS.SelectedItem.ToString());
            textBoxVersion.Text = "";
            pictureBox9.Image = Xprotolab_interface.Properties.Resources.led_off;
            labelConnected.Text = "Not Connected";
            checkBoxStop.Checked = false;
            checkBoxStop.Enabled = false;
            serialPort1.Close();
        }

        private void USBConnect() {
            UInt16 ver;
            if (myWinUsbDevice.IsWindowsXpOrLater()) FindMyDevice();
            if (myDeviceDetected == true) {
                comboBoxCOMS.Enabled = false;
                comboBoxCOMS.SelectedIndex = -1;
                buttonConnect.Enabled = false;
                labelConnected.Text = "USB Connected";
                myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('a'), 0, 0);
                USBDataIn[4] = 0;
                pictureBox9.Image = Xprotolab_interface.Properties.Resources.led_on;
                checkBoxStop.Enabled = true;
                string str = System.Text.Encoding.UTF8.GetString(USBDataIn);
                textBoxVersion.Text = str;
                str=str.Replace(",", ".");    // Different languages use different punctuation
                ver = (UInt16)(Convert.ToDecimal(str) * 100);
                if(ver < 212) MessageBox.Show("Update Device Firmware to 2.13");
                ReadSettings();
                ReadDataViaBulkTransfer(); // Begin automatic data transfers
            }
        }

        private void Connect() {
            UInt16 ver;
            // Check for USB device
            USBConnect();
            if(myDeviceDetected == false) {
                timer1.Interval = 62;
                timer1.Start();

                // Open port
                //configuring the serial port
                if(!serialPort1.IsOpen && COM_PORT.Length > 0) {
                    serialPort1.PortName = string.Copy(COM_PORT);
                    serialPort1.BaudRate = 115200;
                    serialPort1.DataBits = 8;
                    serialPort1.Parity = Parity.None;
                    serialPort1.StopBits = StopBits.One;
                    serialPort1.DiscardNull = false;
                    serialPort1.ReadTimeout = 1000;
                    try {
                        serialPort1.Open();
                        serialPort1.Write("a"); // Request Device version
                        USBDataIn[0] = (byte)(serialPort1.ReadByte());
                        USBDataIn[1] = (byte)(serialPort1.ReadByte());
                        USBDataIn[2] = (byte)(serialPort1.ReadByte());
                        USBDataIn[3] = (byte)(serialPort1.ReadByte());
                        USBDataIn[4] = 0;
                        labelConnected.Text = "Connected";
                        pictureBox9.Image = Xprotolab_interface.Properties.Resources.led_on;
                        checkBoxStop.Enabled = true;
                        string str = System.Text.Encoding.UTF8.GetString(USBDataIn);
                        textBoxVersion.Text = str;
                        str = str.Replace(",", ".");    // Different languages use different punctuation
                        ver = (UInt16)(Convert.ToDecimal(str) * 100);
                        if(ver < 212) MessageBox.Show("Update Device Firmware to 2.13");
                        ReadSettings();
                        // serialPort1.Write("q"); // Xprotolab autosend
                        // ready_for_data = true;
                    }
                    catch(TimeoutException) {
                        textBoxVersion.Text = "error";
                    }
                }
            }
        }

        private void ReadSettings() {
            byte data;
            decimal f=2;
            // Request settings from Xprotolab
            if(myDeviceDetected) {
                myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('u'), 0, 14);
            }
            else if(serialPort1.IsOpen) {
                // Request settings from Xprotolab
                if(!SerialBusy.WaitOne(100)) return;
                serialPort1.Write("u");
                for(data = 0; data < 43; data++) USBDataIn[data] = (byte)(serialPort1.ReadByte());
                SerialBusy.ReleaseMutex();
            }
            else return;
            try {
                // GPIO0 srate
                data = USBDataIn[0];   // Sampling rate
                if ((byte)data >= trackBarSampling.Minimum && (byte)data <= trackBarSampling.Maximum)
                    trackBarSampling.Value = (byte)data;
                // GPIO1 CH1 Option
                data = USBDataIn[1];
                radioButtonCH1Add.Checked = false;
                radioButtonCH1Mul.Checked = false;
                checkBoxCH1On.Checked = ((data & (byte)(1 << 0)) != 0);
                checkBoxCH1Inv.Checked = ((data & (byte)(1 << 4)) != 0);
                checkBoxCH1Avrg.Checked = ((data & (byte)(1 << 5)) != 0);
                checkBoxCH1Math.Checked = ((data & (byte)(1 << 6)) != 0);
                if((data & (byte)(1 << 7)) != 0) radioButtonCH1Add.Checked=true;
                else radioButtonCH1Mul.Checked=true;
                // GPIO2 CH2 Option
                data = USBDataIn[2];
                radioButtonCH2Add.Checked = false;
                radioButtonCH2Mul.Checked = false;
                checkBoxCH2On.Checked = ((data & (byte)(1 << 0)) != 0);
                checkBoxCH2Inv.Checked = ((data & (byte)(1 << 4)) != 0);
                checkBoxCH2Avrg.Checked = ((data & (byte)(1 << 5)) != 0);
                checkBoxCH2Math.Checked = ((data & (byte)(1 << 6)) != 0);
                if((data & (byte)(1 << 7)) != 0) radioButtonCH2Add.Checked = true;
                else radioButtonCH2Mul.Checked = true;
                // GPIO3 CHD Option
                data = USBDataIn[3]; // option
                checkBoxCHDOn.Checked = ((data & (byte)(1 << 0)) != 0);
                if((data & (byte)(1 << 1)) != 0) {
                    if((data & (byte)(1 << 2)) != 0) trackBarCHDPull.Value = 2;
                    else trackBarCHDPull.Value = 0;
                }
                else trackBarCHDPull.Value = 1;
                checkBoxCHDThick.Checked = ((data & (byte)(1 << 3)) != 0);
                checkBoxCHDInv.Checked = ((data & (byte)(1 << 4)) != 0);
                checkBoxASCII.Checked = ((data & (byte)(1 << 7)) != 0);
                // GPIO4 Mask
                data = USBDataIn[4]; // mask
                checkBoxCHD0.Checked = ((data & (byte)(1 << 0)) != 0);
                checkBoxCHD1.Checked = ((data & (byte)(1 << 1)) != 0);
                checkBoxCHD2.Checked = ((data & (byte)(1 << 2)) != 0);
                checkBoxCHD3.Checked = ((data & (byte)(1 << 3)) != 0);
                checkBoxCHD4.Checked = ((data & (byte)(1 << 4)) != 0);
                checkBoxCHD5.Checked = ((data & (byte)(1 << 5)) != 0);
                checkBoxCHD6.Checked = ((data & (byte)(1 << 6)) != 0);
                checkBoxCHD7.Checked = ((data & (byte)(1 << 7)) != 0);
                // GPIO5 Trigger
                data = USBDataIn[5];   // Trigger
                radioTrigFree.Checked = false;
                radioTrigNormal.Checked = false;
                radioTrigSingle.Checked = false;
                radioTrigAuto.Checked = false;
                radioPositive.Checked = false;
                radioNegative.Checked = false;
                radioRising.Checked = false;
                radioFalling.Checked = false;
                radioWindow.Checked = false;
                radioDual.Checked = false;
                if      ((data & (byte)(1 << 0)) != 0) radioTrigNormal.Checked = true;
                else if ((data & (byte)(1 << 1)) != 0) radioTrigSingle.Checked = true;
                else if ((data & (byte)(1 << 2)) != 0) radioTrigAuto.Checked = true;
                else radioTrigFree.Checked = true;
                checkBoxCircular.Checked = ((data & (byte)(1 << 4)) != 0);
                if((data & (byte)(1 << 7)) != 0) {      // edge
                    if((data & (byte)(1 << 3)) != 0) radioFalling.Checked = true;
                    else radioRising.Checked = true;
                }
                else if((data & (byte)(1 << 5)) != 0) { // slope
                    if((data & (byte)(1 << 3)) != 0) radioNegative.Checked = true;
                    else radioPositive.Checked = true;
                }
                else if((data & (byte)(1 << 6)) != 0) radioWindow.Checked = true;
                else radioDual.Checked = true;
                // GPIO6 Mcursors
                data=USBDataIn[6];
                radioSniffNormal.Checked = false;
                radioSniffSingle.Checked = false;
                checkBoxRoll.Checked = ((data & (byte)(1 << 0)) != 0);  // Roll scope on slow sampling rates
/*                  if ((data & (byte)(1 << 1)) != 0) radioTrigNormal.Checked = true;   // Auto cursors
                if ((data & (byte)(1 << 2)) != 0) radioTrigNormal.Checked = true;   // Track vertical with horizontal
                if ((data & (byte)(1 << 3)) != 0) radioTrigNormal.Checked = true;   // CH1 Horizontal Cursor on
                if ((data & (byte)(1 << 4)) != 0) radioTrigNormal.Checked = true;   // CH2 Horizontal Cursor on
                if ((data & (byte)(1 << 5)) != 0) radioTrigNormal.Checked = true;   // Vertical Cursor on
                if ((data & (byte)(1 << 6)) != 0) radioTrigNormal.Checked = true;   // Reference waveforms on*/
                if((data & (byte)(1 << 7)) != 0) radioSniffSingle.Checked = true;
                else radioSniffNormal.Checked = true;
                // GPIO7 display
                data = USBDataIn[7];
                checkBoxPersistence.Checked=((data & (byte)(1 << 5)) != 0);
                checkBoxLines.Checked = ((data & (byte)(1 << 6)) != 0);
                    // Grid settings (2 bits)
/*                    if ((data & (byte)(1 << 2)) != 0) radioTrigNormal.Checked = true;    // Average on successive traces
                if ((data & (byte)(1 << 3)) != 0) radioTrigNormal.Checked = true;    // Invert display
                if ((data & (byte)(1 << 4)) != 0) radioTrigNormal.Checked = true;    // Flip display
                if ((data & (byte)(1 << 5)) != 0) radioTrigNormal.Checked = true;    // Persistent Display
                if ((data & (byte)(1 << 6)) != 0) radioTrigNormal.Checked = true;    // Continuous Drawing
                if ((data & (byte)(1 << 7)) != 0) radioTrigNormal.Checked = true;    // Show scope settings (time/div volts/div)*/
                // GPIO8 MFFT
                data = USBDataIn[8];
                radioButtonRectangular.Checked = false;
                radioButtonHamming.Checked = false;
                radioButtonHann.Checked = false;
                radioButtonBlackman.Checked = false;
                if((data & (byte)(1 << 0)) != 0) radioButtonHamming.Checked = true;
                else if((data & (byte)(1 << 1)) != 0) radioButtonHann.Checked = true;
                else if((data & (byte)(1 << 2)) != 0) radioButtonBlackman.Checked = true;
                else radioButtonRectangular.Checked = true;
                checkBoxLog.Checked = ((data & (byte)(1 << 3)) != 0);
                checkBoxIQFFT.Checked = ((data & (byte)(1 << 4)) != 0);
                checkBoxXY.Checked = ((data & (byte)(1 << 6)) != 0);
                checkBoxFFTOn.Checked = ((data & (byte)(1 << 7)) != 0);
                // GPIO9 Sweep
                data = USBDataIn[9];
                checkBoxAccelDir.Checked    = ((data & (byte)(1 << 0)) != 0);
                checkBoxAccel.Checked       = ((data & (byte)(1 << 1)) != 0);
                checkBoxDirection.Checked   = ((data & (byte)(1 << 2)) != 0);
                checkBoxPingPong.Checked    = ((data & (byte)(1 << 3)) != 0);
                checkBoxSweepF.Checked      = ((data & (byte)(1 << 4)) != 0);
                checkBoxSweepA.Checked      = ((data & (byte)(1 << 5)) != 0);
                checkBoxSweepO.Checked      = ((data & (byte)(1 << 6)) != 0);
                checkBoxSweepD.Checked      = ((data & (byte)(1 << 7)) != 0);
                // GPIOA Sniffer Controls
                data = USBDataIn[10]; // param
                comboBoxBaud.SelectedIndex = data & 0x07;
                if((data & (byte)(1 << 3)) != 0) comboBoxCPOL.SelectedIndex = 1;
                else comboBoxCPOL.SelectedIndex = 0;
                if((data & (byte)(1 << 4)) != 0) comboBoxCPHA.SelectedIndex = 1;
                else comboBoxCPHA.SelectedIndex = 0;
                if((data & (byte)(1 << 5)) != 0) {
                    if((data & (byte)(1 << 6)) != 0) comboBoxParity.SelectedIndex = 1;
                    else comboBoxParity.SelectedIndex = 2;
                }
                else comboBoxParity.SelectedIndex = 0;
                if((data & (byte)(1 << 7)) != 0) comboBoxStops.SelectedIndex = 1;
                else comboBoxStops.SelectedIndex = 0;
                // GPIOB MStatus
                data = USBDataIn[11];
                checkBoxStop.Checked = ((data & (byte)(1 << 4)) != 0);
                // M 12 Gain CH1
                data = USBDataIn[12];
                if((byte)data >= trackBarCH1Gain.Minimum && (byte)data <= trackBarCH1Gain.Maximum)
                    trackBarCH1Gain.Value = (byte)data;
                // M 13 Gain CH2
                data = USBDataIn[13];
                if((byte)data >= trackBarCH2Gain.Minimum && (byte)data <= trackBarCH2Gain.Maximum)
                    trackBarCH2Gain.Value = (byte)data;
                // M 14 HPos
                data = USBDataIn[14];
                if((byte)data >= ScrollBarHPos.Minimum && (byte)data <= ScrollBarHPos.Maximum)
                    ScrollBarHPos.Value = (byte)data;
                // M 15 Vertical cursor A
                // M 16 Vertical cursor B
                // M 17 CH1 Horizontal cursor A
                // M 18 CH1 Horizontal cursor B
                // M 19 CH2 Horizontal cursor A
                // M 20 CH2 Horizontal cursor B
                // M 21 Trigger Hold
                numericUpDownTHold.Value = USBDataIn[21];
                // M 22 23 Post Trigger
                // M 24 Trigger source
                data = USBDataIn[24];   // Trigger source
                if (data <= 10) comboBoxTSource.SelectedIndex = data;
                // M 25 Trigger Level
                // M 26 Window Trigger level 1
                // M 27 Window Trigger level 2
                // M 28 Trigger Timeout
                numericUpTTimeout.Value = ((decimal)USBDataIn[28] + 1) * 40.96M;
                // M 29 Channel 1 position
                data = (byte)(trackBarCH1Pos.Minimum - (sbyte)USBDataIn[29]);
                if ((sbyte)data >= trackBarCH1Pos.Minimum && (sbyte)data <= trackBarCH1Pos.Maximum)
                    trackBarCH1Pos.Value = (sbyte)data;
                // M 30 Channel 2 position
                data = (byte)(trackBarCH2Pos.Minimum - (sbyte)USBDataIn[30]);
                if ((sbyte)data >= trackBarCH2Pos.Minimum && (sbyte)data <= trackBarCH2Pos.Maximum)
                    trackBarCH2Pos.Value = (sbyte)data;
                // M 31 Channel D position
                data = (byte)(trackBarCHDPos.Maximum - (USBDataIn[31] / 8));
                if ((sbyte)data >= trackBarCHDPos.Minimum && (sbyte)data <= trackBarCHDPos.Maximum)
                    trackBarCHDPos.Value = (sbyte)data;
                // M 32 Decode Protocol
                data = USBDataIn[32]; // decode
                // M 33 Sweep Start Frequency
                trackBarSW1.Value = USBDataIn[33];
                // M 34 Sweep End Frequency
                trackBarSW2.Value = USBDataIn[34];
                // M 35 Sweep Speed
                data = USBDataIn[35];
                if(data == 0) data = 1;
                trackBarSWSpeed.Value = data;
                textBoxSWSpeed.Text = (trackBarSWSpeed.Value).ToString();
                // M 36 Amplitude range: [-128,0]
                data = (byte)(-USBDataIn[36]);
                if (data >= trackBarAmp.Minimum && data <= trackBarAmp.Maximum)
                {
                    trackBarAmp.Value = data;
                    numericUpDownAmp.Value = (decimal)(trackBarAmp.Value) / 32;
                }
                // M 37 Waveform type
                data = USBDataIn[37];
                radioButtonSine.Checked = false;
                radioButtonSquare.Checked = false;
                radioButtonTrian.Checked = false;
                radioButtonCustom.Checked = false;
                radioButtonExpo.Checked = false;
                radioButtonNoise.Checked = false;
                if(data == 0) radioButtonNoise.Checked = true;
                else if(data == 1) radioButtonSine.Checked = true;
                else if(data == 2) radioButtonSquare.Checked = true;
                else if(data == 3) radioButtonTrian.Checked = true;
                else if(data==4) radioButtonExpo.Checked = true;
                else radioButtonCustom.Checked = true;
                // 38 Duty cycle range: [1,255]
                data = USBDataIn[38];
                if (data == 0) data++;
                trackBarDuty.Value = data;
                numericUpDownDuty.Value = (decimal)((trackBarDuty.Value) * (50.00064 / 128));
                // M 39 Offset
                data = USBDataIn[39];
                trackBarOffset.Value = -(sbyte)data;
                numericUpDownOffset.Value = (decimal)((-(sbyte)data) * 0.50016 / 32);
                // 40 Desired frequency
                f = (( 16777216 * ((UInt32)USBDataIn[43])) +
                        (    65536 * ((UInt32)USBDataIn[42])) +
                        (      256 * ((UInt32)USBDataIn[41])) +
                        (        1 * ((UInt32)USBDataIn[40]))   ) / 100;
            }
            catch (TimeoutException) {
                checkBoxStop.Checked = false;
                checkBoxStop.Enabled = false;
                return;
            }
            UpdateSWCursors();
            labelSRate.Text = ratetxt[trackBarSampling.Value];
            labelCH1Gain.Text = gaintxt[trackBarCH1Gain.Value];
            labelCH2Gain.Text = gaintxt[trackBarCH2Gain.Value];
            if(f < 1) f = 1;
            if(f > 100000) f = 100000;
            numericUpDownFreq.Value = f;
            if(f >= 10000) {
                radioButton100K.Checked = true;
                trackBarFreq.Value = (int)f / 1000;
            }
            else if(f >= 1000) {
                radioButton10K.Checked = true;
                trackBarFreq.Value = (int)f / 100;
            }
            else if(f >= 100) {
                radioButton1K.Checked = true;
                trackBarFreq.Value = (int)f / 10;
            }
            else if(f >= 10) {
                radioButton100.Checked = true;
                trackBarFreq.Value = (int)f;
            }
            else {
                radioButton10.Checked = true;
                trackBarFreq.Value = (int)f * 10;
            }

        }

        #region Scope_control

        private void WriteByte(byte index, byte data) {
            if(myDeviceDetected) {
                myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('b'), data, index);
            }
            if(serialPort1.IsOpen) {
                if(!SerialBusy.WaitOne(100)) return;
                serialPort1.Write(new byte[] { Convert.ToByte('b'), index, data }, 0, 3);
                SerialBusy.ReleaseMutex();
            }
        }

        // GPIO0 srate
        private void trackBarSampling_Scroll(object sender, EventArgs e) {
            WriteByte(0, (byte)(trackBarSampling.Value));
            labelSRate.Text = ratetxt[trackBarSampling.Value];
        }
        // GPIO1 CH1 controls
        private void checkBoxCH1On_MouseClick(object sender, MouseEventArgs e) {
            byte field = 0;
            if(checkBoxCH1On.Checked) field += (1 << 0);
            if(checkBoxCH1Inv.Checked) field += (1 << 4);
            if(checkBoxCH1Avrg.Checked) field += (1 << 5);
            if(checkBoxCH1Math.Checked) field += (1 << 6);
            if(radioButtonCH1Add.Checked) field += (1 << 7);
            WriteByte(1, field);
        }
        private void checkBoxCH1Inv_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH1On_MouseClick(sender, e);
        }
        private void checkBoxCH1Avrg_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH1On_MouseClick(sender, e);
        }
        private void checkBoxCH1Math_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH1On_MouseClick(sender, e);
        }
        private void radioButtonCH1Add_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH1On_MouseClick(sender, e);
        }
        private void radioButtonCH1Mul_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH1On_MouseClick(sender, e);
        }
        // GPIO2 CH2 controls
        private void checkBoxCH2On_MouseClick(object sender, MouseEventArgs e) {
            byte field = 0;
            if(checkBoxCH2On.Checked) field += (1 << 0);
            if(checkBoxCH2Inv.Checked) field += (1 << 4);
            if(checkBoxCH2Avrg.Checked) field += (1 << 5);
            if(checkBoxCH2Math.Checked) field += (1 << 6);
            if(radioButtonCH2Add.Checked) field += (1 << 7);
            WriteByte(2, field);
        }
        private void checkBoxCH2Inv_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH2On_MouseClick(sender, e);
        }
        private void checkBoxCH2Avrg_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH2On_MouseClick(sender, e);
        }
        private void checkBoxCH2Math_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH2On_MouseClick(sender, e);
        }
        private void radioButtonCH2Add_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH2On_MouseClick(sender, e);
        }
        private void radioButtonCH2Mul_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCH2On_MouseClick(sender, e);
        }
        // GPIO3 CHD controls
        private void SendCHDcontrols() {
            byte field = 0;
            if(checkBoxCHDOn.Checked) field += (1 << 0);    // CHD Option
            if(trackBarCHDPull.Value != 1) field += (1 << 1);
            if(trackBarCHDPull.Value == 2) field += (1 << 2);
            if(checkBoxCHDThick.Checked) field += (1 << 3);
            if(checkBoxCHDInv.Checked) field += (1 << 4);
            if(checkBoxASCII.Checked) field += (1 << 7);
            WriteByte(3, field);
        }
        private void checkBoxCHDOn_MouseClick(object sender, MouseEventArgs e) {
            SendCHDcontrols();
        }
        private void checkBoxCHDInv_MouseClick(object sender, MouseEventArgs e) {
            SendCHDcontrols();
        }
        private void checkBoxCHDThick_MouseClick(object sender, MouseEventArgs e) {
            SendCHDcontrols();
        }
        private void checkBox4_MouseClick(object sender, MouseEventArgs e) {
            SendCHDcontrols();
        }
        private void trackBarCHDPull_Scroll(object sender, EventArgs e) {
            SendCHDcontrols();
        }
        // GPIO4 CHD mask
        private void checkBoxCHD0_MouseClick(object sender, MouseEventArgs e) {
            byte field = 0;
            if(checkBoxCHD0.Checked) field += (1 << 0);    // CHD Mask
            if(checkBoxCHD1.Checked) field += (1 << 1);
            if(checkBoxCHD2.Checked) field += (1 << 2);
            if(checkBoxCHD3.Checked) field += (1 << 3);
            if(checkBoxCHD4.Checked) field += (1 << 4);
            if(checkBoxCHD5.Checked) field += (1 << 5);
            if(checkBoxCHD6.Checked) field += (1 << 6);
            if(checkBoxCHD7.Checked) field += (1 << 7);
            WriteByte(4, field);
        }
        private void checkBoxCHD1_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCHD0_MouseClick(sender, e);
        }
        private void checkBoxCHD2_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCHD0_MouseClick(sender, e);
        }
        private void checkBoxCHD3_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCHD0_MouseClick(sender, e);
        }
        private void checkBoxCHD4_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCHD0_MouseClick(sender, e);
        }
        private void checkBoxCHD5_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCHD0_MouseClick(sender, e);
        }
        private void checkBoxCHD6_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCHD0_MouseClick(sender, e);
        }
        private void checkBoxCHD7_MouseClick(object sender, MouseEventArgs e) {
            checkBoxCHD0_MouseClick(sender, e);
        }
        // GPIO5 Trigger bits
        private void radioRising_MouseClick(object sender, MouseEventArgs e) {
            byte field = 0;
            if(radioTrigNormal.Checked) field += (1 << 0);           // Trigger
            else if(radioTrigSingle.Checked) field += (1 << 1);
            else if(radioTrigAuto.Checked) field += (1 << 2);
            if(radioFalling.Checked || radioNegative.Checked) field += (1 << 3);    // Trigger direction
            if(checkBoxCircular.Checked) field += (1 << 4); // Sniffer circular buffer
            if(radioPositive.Checked || radioNegative.Checked) field += (1 << 5);   // Slope
            if(radioWindow.Checked) field += (1 << 6);   // Window
            if(radioRising.Checked || radioFalling.Checked) field += (1 << 7);   // Edge
            WriteByte(5, field);
        }
        private void radioFalling_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        private void radioPositive_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        private void radioNegative_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        private void radioTrigFree_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        private void radioTrigAuto_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        private void radioTrigNormal_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        private void radioTrigSingle_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        private void radioDual_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        private void radioWindow_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        private void checkBoxCircular_MouseClick(object sender, MouseEventArgs e) {
            radioRising_MouseClick(sender, e);
        }
        // GPIO6 Mcursors
        private void checkBoxRoll_MouseClick(object sender, MouseEventArgs e) {
            byte field = 0;
            if(checkBoxRoll.Checked) field += (1 << 0);     // Roll Mode
            if(radioSniffSingle.Checked) field+=(1 << 7);   // Single Sniffer
            WriteByte(6, field);
        }
        // GPIO7 display

        // GPIO8 MFFT
        private void radioButtonRectangular_MouseClick(object sender, MouseEventArgs e) {
            byte field = 0;
            if(radioButtonHamming.Checked) field += (1 << 0);
            if(radioButtonHann.Checked) field += (1 << 1);
            if(radioButtonBlackman.Checked) field += (1 << 2);
            if(checkBoxLog.Checked) field += (1 << 3);
            if(checkBoxIQFFT.Checked) field += (1 << 4);
            if(checkBoxXY.Checked) field += (1 << 6);       // XY Mode
            else field += (1 << 5);                         // Scope Mode
            if(checkBoxFFTOn.Checked) field += (1 << 7);    // FFT Mode
            WriteByte(8, field);
        }
        private void radioButtonHamming_MouseClick(object sender, MouseEventArgs e) {
            radioButtonRectangular_MouseClick(sender, e);
        }
        private void radioButtonHann_MouseClick(object sender, MouseEventArgs e) {
            radioButtonRectangular_MouseClick(sender, e);
        }
        private void radioButtonBlackman_MouseClick(object sender, MouseEventArgs e) {
            radioButtonRectangular_MouseClick(sender, e);
        }
        private void checkBoxLog_MouseClick(object sender, MouseEventArgs e) {
            radioButtonRectangular_MouseClick(sender, e);
        }
        private void checkBoxIQFFT_MouseClick(object sender, MouseEventArgs e) {
            radioButtonRectangular_MouseClick(sender, e);
        }
        private void checkBoxXY_MouseClick(object sender, MouseEventArgs e) {
            radioButtonRectangular_MouseClick(sender, e);
        }
        private void checkBoxFFTOn_MouseClick(object sender, MouseEventArgs e) {
            radioButtonRectangular_MouseClick(sender, e);
        }
        // GPIO9 Sweep
        private void checkBoxSweepF_MouseClick(object sender, MouseEventArgs e) {
            byte field = 0;
            UpdateSWCursors();
            if(checkBoxAccelDir.Checked)    field += (1 << 0);
            if(checkBoxAccel.Checked)       field += (1 << 1);
            if(checkBoxDirection.Checked)   field += (1 << 2);
            if(checkBoxPingPong.Checked)    field += (1 << 3);
            if(checkBoxSweepF.Checked)      field += (1 << 4);
            if(checkBoxSweepA.Checked)      field += (1 << 5);
            if(checkBoxSweepO.Checked)      field += (1 << 6);
            if(checkBoxSweepD.Checked)      field += (1 << 7);
            WriteByte(9, field);
        }
        private void checkBoxSweepA_MouseClick(object sender, MouseEventArgs e) {
            checkBoxSweepF_MouseClick(sender, e);
        }
        private void checkBoxSweepO_MouseClick(object sender, MouseEventArgs e) {
            checkBoxSweepF_MouseClick(sender, e);
        }
        private void checkBoxSweepD_MouseClick(object sender, MouseEventArgs e) {
            checkBoxSweepF_MouseClick(sender, e);
        }
        private void checkBoxPingPong_MouseClick(object sender, MouseEventArgs e) {
            checkBoxSweepF_MouseClick(sender, e);
        }
        private void checkBoxAccelDir_MouseClick(object sender, MouseEventArgs e) {
            checkBoxSweepF_MouseClick(sender, e);
        }
        private void checkBoxDirection_MouseClick(object sender, MouseEventArgs e) {
            checkBoxSweepF_MouseClick(sender, e);
        }
        private void checkBoxAccel_MouseClick(object sender, MouseEventArgs e) {
            checkBoxSweepF_MouseClick(sender, e);
        }
        // GPIOA
        private void SendSnifferSettings() {
            byte field = 0;
            field = (byte)comboBoxBaud.SelectedIndex;
            if(comboBoxCPOL.SelectedIndex == 1) field += (1 << 3);
            if(comboBoxCPHA.SelectedIndex == 1) field += (1 << 4);
            if(comboBoxParity.SelectedIndex == 1) field += (1 << 5);
            if(comboBoxParity.SelectedIndex == 2) { field += (1 << 5); field += (1 << 6); }
            if(comboBoxStops.SelectedIndex == 1) field += (1 << 7);
            WriteByte(10, field);
        }
        private void radioSniffNormal_MouseClick(object sender, MouseEventArgs e) {
            SendSnifferSettings();
        }
        private void radioSniffSingle_MouseClick(object sender, MouseEventArgs e) {
            SendSnifferSettings();
        }
        private void comboBoxBaud_SelectedIndexChanged(object sender, EventArgs e) {
            SendSnifferSettings();
        }
        private void comboBoxParity_SelectedIndexChanged(object sender, EventArgs e) {
            SendSnifferSettings();
        }
        private void comboBoxStops_SelectedIndexChanged(object sender, EventArgs e) {
            SendSnifferSettings();
        }
        private void comboBoxCPOL_SelectedIndexChanged(object sender, EventArgs e) {
            SendSnifferSettings();
        }
        private void comboBoxCPHA_SelectedIndexChanged(object sender, EventArgs e) {
            SendSnifferSettings();
        }
        // GPIOB MStatus
        private void checkBoxStop_MouseClick(object sender, MouseEventArgs e) {
            if(myDeviceDetected) {
                if(checkBoxStop.Checked) // Stop ?
                    myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('f'), 0, 0);
                else myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('g'), 0, 0);
            }
            else if(serialPort1.IsOpen) {
                if(!SerialBusy.WaitOne(100)) return;
                if(checkBoxStop.Checked) serialPort1.Write("f"); else serialPort1.Write("g");
                SerialBusy.ReleaseMutex();
            }
        }
        private void buttonForce_Click(object sender, EventArgs e) {
            if(myDeviceDetected) {
                myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('h'), 0, 0);
            }
            else if(serialPort1.IsOpen) {
                if(!SerialBusy.WaitOne(100)) return;
                serialPort1.Write("h");
                SerialBusy.ReleaseMutex();
            }
        }
        // M 12 Channel 1 gain
        private void trackBarCH1Gain_Scroll(object sender, EventArgs e) {
            WriteByte(12, (byte)(trackBarCH1Gain.Value));
            labelCH1Gain.Text = gaintxt[trackBarCH1Gain.Value];
        }
        // M 13 Channel 2 gain
        private void trackBarCH2Gain_Scroll(object sender, EventArgs e) {
            WriteByte(13, (byte)(trackBarCH2Gain.Value));
            labelCH2Gain.Text = gaintxt[trackBarCH2Gain.Value];
        }
        // M 14 Horizontal Position
        private void ScrollBarHPos_Scroll(object sender, ScrollEventArgs e) {
            WriteByte(14, (byte)(ScrollBarHPos.Value));
            if(checkBoxStop.Checked) {
                Invalidate(new Rectangle(0, 0, 512, 512));
            }
        }
        // M 15 Vertical cursor A
        // M 16 Vertical cursor B
        // M 17 CH1 Horizontal cursor A
        // M 18 CH1 Horizontal cursor B
        // M 19 CH2 Horizontal cursor A
        // M 20 CH2 Horizontal cursor B
        // M 21 Trigger Hold
        private void numericUpDownTHold_ValueChanged(object sender, EventArgs e) {
            WriteByte(21, (byte)(numericUpDownTHold.Value));
        }
        // M 22 23 Post Trigger
        // M 24 Trigger source
        private void comboBoxTSource_SelectedIndexChanged(object sender, EventArgs e) {
            WriteByte(24, (byte)(comboBoxTSource.SelectedIndex));
        }
        // M 25 Trigger Level
        // M 26 Window Trigger level 1
        // M 27 Window Trigger level 2
        // M 28 Trigger Timeout
        private void numericUpTTimeout_ValueChanged(object sender, EventArgs e) {
            byte data;
            data = (byte)((numericUpTTimeout.Value / 40.96M) - 1);
            numericUpTTimeout.Value = ((decimal)data + 1) * 40.96M;
            WriteByte(28, data);
        }
        // M 29 Channel 1 position
        private void trackBarCH1Pos_Scroll(object sender, EventArgs e) {
            WriteByte(29, (byte)(trackBarCH1Pos.Minimum - trackBarCH1Pos.Value));
            if(checkBoxStop.Checked) {
                Invalidate(new Rectangle(0, 0, 512, 512));
            }
        }
        // M 30 Channel 2 position
        private void trackBarCH2Pos_Scroll(object sender, EventArgs e) {
            WriteByte(30, (byte)(trackBarCH2Pos.Minimum - trackBarCH2Pos.Value));
            if(checkBoxStop.Checked) {
                Invalidate(new Rectangle(0, 0, 512, 512));
            }
        }
        // M 31 Channel position
        private void trackBarCHDPos_Scroll(object sender, EventArgs e) {
            byte count, temp2, CHPos;
            count = 0;
            if(checkBoxCHD0.Checked) count++;    // CHD Mask
            if(checkBoxCHD1.Checked) count++;
            if(checkBoxCHD2.Checked) count++;
            if(checkBoxCHD3.Checked) count++;
            if(checkBoxCHD4.Checked) count++;
            if(checkBoxCHD5.Checked) count++;
            if(checkBoxCHD6.Checked) count++;
            if(checkBoxCHD7.Checked) count++;

            // Count CHD enabled pins
            CHPos = (byte)((trackBarCHDPos.Maximum - trackBarCHDPos.Value) * 8);
            temp2 = (byte)((8 - count) * 8);    // Max position
            if(CHPos > temp2) CHPos = temp2;

            WriteByte(31, CHPos);
        }
        // M 32 Decode Protocol
        // M 33 Sweep Start Frequency
        private void UpdateSWCursors() {
            byte sweepmin, sweepmax;
            sweepmin = (byte)(trackBarSW1.Value);
            sweepmax = (byte)(trackBarSW2.Value);
            if(checkBoxSweepF.Checked) {
                decimal freqv;
                if(trackBarSampling.Value >= 11) freqv = freqval[trackBarSampling.Value] / 128;   // Slow sampling rate uses 2 samples per pixel
                else freqv = freqval[trackBarSampling.Value] / 256;
                if(trackBarSampling.Value <= 6) {
                    textBoxSW1.Text = (sweepmin * (freqv) / 2000).ToString("##.000");
                    textBoxSW2.Text = (sweepmax * (freqv) / 2000).ToString("##.000");
                    labelUnit1.Text = "kHz";
                    labelUnit2.Text = "kHz";
                }
                else {
                    textBoxSW1.Text = (sweepmin * (freqv) / 2000).ToString("##.000");
                    textBoxSW2.Text = (sweepmax * (freqv) / 2000).ToString("##.000");
                    labelUnit1.Text = "Hz";
                    labelUnit2.Text = "Hz";
                }
            }
            else if(checkBoxSweepA.Checked) {
                textBoxSW1.Text = ((decimal)sweepmin / 64).ToString("##.000");
                textBoxSW2.Text = ((decimal)sweepmax / 64).ToString("##.000");
                labelUnit1.Text = "V";
                labelUnit2.Text = "V";
            }
            else if(checkBoxSweepO.Checked) {
                textBoxSW1.Text = ((decimal)-((255 - sweepmin) * 0.50016 / 32) + 2).ToString("##.000");
                textBoxSW2.Text = ((decimal)-((255 - sweepmax) * 0.50016 / 32) + 2).ToString("##.000");
                labelUnit1.Text = "V";
                labelUnit2.Text = "V";
            }
            else if(checkBoxSweepD.Checked) {
                textBoxSW1.Text = ((decimal)(sweepmin * (50.00064 / 128))).ToString("##.000");
                textBoxSW2.Text = ((decimal)(sweepmax * (50.00064 / 128))).ToString("##.000");
                labelUnit1.Text = "%";
                labelUnit2.Text = "%";
            }
        }
        private void trackBarSW1_Scroll(object sender, EventArgs e) {
            if(trackBarSW1.Value > trackBarSW2.Value) trackBarSW1.Value = trackBarSW2.Value;
            UpdateSWCursors();
            WriteByte(33, (byte)(trackBarSW1.Value));
        }
        // M 34 Sweep End Frequency
        private void trackBarSW2_Scroll(object sender, EventArgs e) {
            if(trackBarSW2.Value < trackBarSW1.Value) trackBarSW2.Value = trackBarSW1.Value;
            UpdateSWCursors();
            WriteByte(34, (byte)(trackBarSW2.Value));
        }
        // M 35 Sweep Speed
        private void trackBarSWSpeed_Scroll(object sender, EventArgs e) {
            textBoxSWSpeed.Text = (trackBarSWSpeed.Value).ToString();
            WriteByte(35, (byte)(trackBarSWSpeed.Value));
        }
        // M 36 Amplitude range: [-128,0]
        private void numericUpDownAmp_ValueChanged(object sender, EventArgs e) {
            byte data;
            data = (byte)(numericUpDownAmp.Value * 32);       // Amplitude
            trackBarAmp.Value = data;
            numericUpDownAmp.Value = (decimal)(trackBarAmp.Value) / 32;
            data = (byte)(-data);
            WriteByte(36, data);
        }
        private void trackBarAmp_Scroll(object sender, EventArgs e) {
            numericUpDownAmp.Value = (decimal)(trackBarAmp.Value) / 32;
        }
        // M 37 Waveform type
        private void SelectWaveform() {
            byte data;
            if(radioButtonNoise.Checked) data = 0;
            else if(radioButtonSine.Checked) data = 1;
            else if(radioButtonSquare.Checked) data = 2;
            else if(radioButtonTrian.Checked) data = 3;
            else if(radioButtonExpo.Checked) data = 4;
            else data = 5;
            WriteByte(37, data);
        }
        private void radioButtonSquare_MouseClick(object sender, MouseEventArgs e) {
            SelectWaveform();
        }
        private void radioButtonCustom_MouseClick(object sender, MouseEventArgs e) {
            SelectWaveform();
        }
        private void radioButtonNoise_MouseClick(object sender, MouseEventArgs e) {
            SelectWaveform();
        }
        private void radioButtonExpo_MouseClick(object sender, MouseEventArgs e) {
            SelectWaveform();
        }
        private void radioButtonTrian_MouseClick(object sender, MouseEventArgs e) {
            SelectWaveform();
        }
        private void radioButtonSine_MouseClick(object sender, MouseEventArgs e) {
            SelectWaveform();
        }
        // M 38 Duty cycle range: [1,255]
        private void numericUpDownDuty_ValueChanged(object sender, EventArgs e) {
            byte data;
            data = (byte)(numericUpDownDuty.Value * 100000 * 128 / 5000064);       // Duty
            if(data == 0) data = 1;
            trackBarDuty.Value = data;
            numericUpDownDuty.Value = (decimal)((trackBarDuty.Value) * (50.00064 / 128));
            WriteByte(38, data);
        }
        private void trackBarDuty_Scroll(object sender, EventArgs e) {
            numericUpDownDuty.Value = (decimal)((trackBarDuty.Value) * (50.00064 / 128));
        }
        // M 39 Offset
        private void numericUpDownOffset_ValueChanged(object sender, EventArgs e) {
            sbyte data;
            data = (sbyte)(-numericUpDownOffset.Value * 100000 * 32 / 50016);       // Offset
            trackBarOffset.Value = -data;
            numericUpDownOffset.Value = (decimal)(trackBarOffset.Value * 0.50016 / 32);
            WriteByte(39, (byte)data);
        }
        private void trackBarOffset_Scroll(object sender, EventArgs e) {
            numericUpDownOffset.Value = (decimal)(trackBarOffset.Value * 0.50016 / 32);
        }
        // M 40 Desired frequency
        private void numericUpDownFreq_ValueChanged(object sender, EventArgs e) {
            byte i, cycles;
            UInt32 Flevel = 1600000;
            UInt16 period;
            UInt32 desiredF;
            decimal actualF;
            desiredF = (UInt32)(numericUpDownFreq.Value * 100);

            // Find Period and number of cycles depending on the desired frequency
            for(i = 0, cycles = 64; i < 6; i++) {
                if(desiredF > Flevel) break;
                Flevel = (UInt32)(Flevel >> 1);
                cycles = (byte)(cycles >> 1);
            }
            period = (UInt16)(((6250000 * cycles) / desiredF) - 1);
            if(period < 31) period = 31;
            actualF = (decimal)(cycles * 50 * (125000000L / (period + 1))) / 100000;
            if(desiredF < 100000) labelHz.Text = "Hz";
            else {
                actualF = actualF / 1000;
                labelHz.Text = "kHz";
            }
            textBoxF.Text = actualF.ToString("##.000");
            if(myDeviceDetected) {
                myWinUsbDevice.Do_Control_Read_Transfer(ref USBDataIn, Convert.ToByte('c'), (UInt16)(desiredF >> 16), (UInt16)(desiredF & 0x0000FFFF));
            }
            else if(serialPort1.IsOpen) {
                if(!SerialBusy.WaitOne(100)) return;
                serialPort1.Write(new byte[] { Convert.ToByte('c'),
                    (byte)(desiredF        & 0x000000FF),
                    (byte)((desiredF >> 8) & 0x000000FF),
                    (byte)((desiredF >> 16)& 0x000000FF),
                    (byte)((desiredF >> 24)& 0x000000FF),
                }, 0, 5);
                SerialBusy.ReleaseMutex();
            }
        }
        private void UpdateF() {
            decimal f;
            f = trackBarFreq.Value;
            if(radioButton10.Checked) numericUpDownFreq.Value = f / 10;
            else if(radioButton100.Checked) numericUpDownFreq.Value = f;
            else if(radioButton1K.Checked) numericUpDownFreq.Value = f * 10;
            else if(radioButton10K.Checked) numericUpDownFreq.Value = f * 100;
            else numericUpDownFreq.Value = f * 1000;
        }
        private void trackBarFreq_Scroll(object sender, EventArgs e) {
            UpdateF();
        }
        private void radioButton20_MouseClick(object sender, MouseEventArgs e) {
            UpdateF();
        }
        private void radioButton200_MouseClick(object sender, MouseEventArgs e) {
            UpdateF();
        }
        private void radioButton2K_MouseClick(object sender, MouseEventArgs e) {
            UpdateF();
        }
        private void radioButton20K_MouseClick(object sender, MouseEventArgs e) {
            UpdateF();
        }
        private void radioButton200K_MouseClick(object sender, MouseEventArgs e) {
            UpdateF();
        }
        #endregion

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e) {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e) {
            System.Diagnostics.Process.Start(e.Link.LinkData.ToString());
        }

        ///  <summary>
        ///  Retrieves received data from a bulk endpoint.
        ///  This routine is called automatically when myWinUsbDevice.ReadViaBulkTransfer
        ///  returns. The routine calls several marshaling routines to access the main form.       
        ///  </summary>
        ///  
        ///  <param name="ar"> An object containing status information about the 
        ///  asynchronous operation.</param>
        ///  
        private void GetReceivedBulkData(IAsyncResult ar) {
            Invalidate(new Rectangle(0, 0, 512, 512));      // Refresh Display area
            if(myDeviceDetected) ReadDataViaBulkTransfer();
/*            UInt32 bytesRead = 0;
            System.Text.ASCIIEncoding myEncoder = new System.Text.ASCIIEncoding();
            Byte[] receivedDataBuffer;
            String receivedtext = "";
            Boolean success = false;

            try {
                receivedDataBuffer = null;

                // Define a delegate using the IAsyncResult object.
                ReadFromDeviceDelegate deleg = ((ReadFromDeviceDelegate)(ar.AsyncState));

                // Get the IAsyncResult object and the values of other paramaters that the
                // BeginInvoke method passed ByRef.
                deleg.EndInvoke(ref receivedDataBuffer, ref bytesRead, ref success, ar);

                // Display the received data in the form's list box.
                if((ar.IsCompleted && success)) {
                    //  Convert the received bytes to a String for display.
                    receivedtext = myEncoder.GetString(receivedDataBuffer);
                }
                else {
                    myDeviceDetected = false;
                }
            }
            catch(Exception ex) {
                throw;
            }*/
        }

        ///  <summary>
        ///  Initiates a read operation from a bulk IN endpoint.
        ///  To enable reading without blocking the main thread, uses an asynchronous delegate.
        ///  </summary>
        ///  
        ///  <remarks>
        ///  To enable reading more than 64 bytes (with device firmware support), increase bytesToRead.
        ///  </remarks> 
        private void ReadDataViaBulkTransfer() {

            IAsyncResult ar = null;
            UInt32 bytesRead = 0;
            UInt32 bytesToRead = (256*3)+2;     // CH1+CH2+CHD+frame number
            Boolean success = false;

            //  Define a delegate for the ReadViaBulkTransfer method of WinUsbDevice.
            ReadFromDeviceDelegate MyReadFromDeviceDelegate =
                new ReadFromDeviceDelegate(myWinUsbDevice.ReadViaBulkTransfer);

            try {
                //  The BeginInvoke method calls MyWinUsbDevice.ReadViaBulkTransfer to attempt 
                //  to read data. The method has the same parameters as ReadViaBulkTransfer,
                //  plus two additional parameters:
                //  GetReceivedBulkData is the callback routine that executes when 
                //  ReadViaBulkTransfer returns.
                //  MyReadFromDeviceDelegate is the asynchronous delegate object.

                ar = MyReadFromDeviceDelegate.BeginInvoke(
                    System.Convert.ToByte(myWinUsbDevice.myDevInfo.bulkInPipe),
                    bytesToRead,
                    ref CHData,
                    ref bytesRead,
                    ref success,
                    new AsyncCallback(GetReceivedBulkData),
                    MyReadFromDeviceDelegate);
            }
            catch(Exception ex) {
                throw;
            }
        }

        ///  <summary>
        ///  Called when a WM_DEVICECHANGE message has arrived,
        ///  indicating that a device has been attached or removed.
        ///  </summary>
        ///  
        ///  <param name="m"> A message with information about the device. </param>
        internal void OnDeviceChange(Message m) {
            try {
                if((m.WParam.ToInt32() == DeviceManagement.DBT_DEVICEARRIVAL)) {
                    //  If WParam contains DBT_DEVICEARRIVAL, a device has been attached.
                    //  Find out if it's the device we're communicating with.
                    if(myDeviceManagement.DeviceNameMatch(m, myDevicePathName)) {
                        buttonConnect.Enabled = true;
                        comboBoxCOMS.Enabled = false;
                        comboBoxCOMS.SelectedIndex = -1;
                    }
                }
                else if((m.WParam.ToInt32() == DeviceManagement.DBT_DEVICEREMOVECOMPLETE)) {
                    //  If WParam contains DBT_DEVICEREMOVAL, a device has been removed.
                    //  Find out if it's the device we're communicating with.
                    if(myDeviceManagement.DeviceNameMatch(m, myDevicePathName)) {
                        pictureBox9.Image = Xprotolab_interface.Properties.Resources.led_off;
                        labelConnected.Text = "NOT Connected";
                        buttonConnect.Enabled = true;
                        comboBoxCOMS.Enabled = true;

                        //  Set MyDeviceDetected False so on the next data-transfer attempt,
                        //  FindMyDevice() will be called to look for the device 
                        //  and get a new handle.
                        myDeviceDetected = false;
                    }
                }
            }
            catch(Exception ex) {
                throw;
            }
        }

        ///  <summary>
        ///  Overrides WndProc to enable checking for and handling
        ///  WM_DEVICECHANGE messages.
        ///  </summary>
        ///  
        ///  <param name="m"> A Windows message.
        ///  </param> 
        ///  
        protected override void WndProc(ref Message m) {
            try {
                // The OnDeviceChange routine processes WM_DEVICECHANGE messages.
                if(m.Msg == DeviceManagement.WM_DEVICECHANGE) OnDeviceChange(m);
                // Let the base form process the message.
                base.WndProc(ref m);
            }
            catch(Exception ex) {
                throw;
            }
        }

        private void checkBoxLines_CheckedChanged(object sender, EventArgs e) {

        }

        private void button14_Click(object sender, EventArgs e) {
            for(int i=0; i<512; i++) CHData[i] = 0;
        }

    }
}
