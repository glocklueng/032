


		///  <summary>
		///  Initiates sending data via a bulk transfer, then receiving data via a bulk transfer.
		///  </summary>
		private void SendAndReceiveViaBulkTransfers() {
			try {
				Boolean success;
				UInt32 bytesToSend;
				String dataToSend = "";
				Byte[] databuffer;
				String formText = "";
				System.Text.ASCIIEncoding myEncoder = new System.Text.ASCIIEncoding();

				//  Get data to send from the textbox.
				dataToSend = txtBulkDataToSend.Text;

				//  Convert the String to a byte array.
				databuffer = myEncoder.GetBytes(dataToSend);
				bytesToSend = Convert.ToUInt32(databuffer.Length);

				// If the device hasn't been detected, was removed, or timed out on a previous attempt
				// to access it, look for the device.
				myDeviceDetected = FindMyDevice();

				if (myDeviceDetected) {
					success = myWinUsbDevice.SendViaBulkTransfer
						(ref databuffer,
						bytesToSend);

					if (success) formText = "Data sent via bulk transfer.";
					else         formText = "Bulk OUT transfer failed.";

					AccessForm("AddItemToListBox", formText);
					ReadDataViaBulkTransfer();
				}
			}
			catch (Exception ex) {
				throw;
			}
		}


