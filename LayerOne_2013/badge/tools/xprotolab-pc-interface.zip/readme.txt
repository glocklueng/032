
Xprotolab PC Interface
for Hardware version 1.4 and up

Gabotronics - April 2011

www.gabotronics.com
email me at: gabriel@gabotronics.com

The included CSV files can be used for the Custom AWG waveform

Version History:
0.27	- Improved parsing of the CSV file
0.26	- Send new custom waveform working
		- Properly scaled the horizontal axis
		- The horizontal scroll bar is working
0.25	- Updated protocol.
        - Added trigger timeout control.
        - Added tooltips
0.24	- Updated GUID, DRIVER NEEDS TO BE REINSTALLED
0.23	- Fixed bug when using non-english languages
0.22	- Fixed bug at startup
0.21	- UART 'Kinda' working, but I'll need to rewrite the program soon
0.20	- Recovering UART interface
0.19	- Compatibility with firmware 1.87
0.18	- Compatibility with firmware 1.85
0.17	- Doesn't hang (as often!)
		- More controls are working
0.16	- Compatibility with firmware 1.79
0.15	- New AWG Sweep options
0.14	- Most USB controls for the AWG working
0.13	- More USB controls working
0.12	- More USB controls working
0.11	- Very basic USB functionality
0.10	- Added more GUI interface, however, they are not acrive yet.
0.09	- Fixed incompatibility with previous xprotolab revision
0.08    - Added more controls to the AWG
0.07    - Fixed direction of the channel position controls
0.06    - Changed AWG layout
        - Added CH1, CH2, and time settings display under the scope window
        - AWG send and receive settings working
0.05    - Added more functionality
0.04    - Basic PC display and control working
0.03    - User can select any serial port available, serial port settings are saved
0.02    - Reading data from both channels
        - Program doesn't hang anymore if no serial data is received
0.01    - Laying out the controls

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE

In no event shall Gabotronics be liable for any special, indirect, incidential
or concequential damages resulting from the use or inability to use this software.
