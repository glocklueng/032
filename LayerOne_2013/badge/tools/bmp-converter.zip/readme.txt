Gabotronics
Bitmap Converter with Run Length Encoding

More information can be found here:
http://www.gabotronics.com/tutorials/run-length-encoding-for-lcd.htm

Version History

1.03: Fixed bug with index
1.02: Resized windows
1.01: Fixed bug with horizontal conversion
1.0: Initial release
